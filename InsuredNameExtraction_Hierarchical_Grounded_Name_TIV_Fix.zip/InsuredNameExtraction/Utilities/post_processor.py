import re
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, Optional, Tuple

try:
    from dateutil.relativedelta import relativedelta
except Exception:  # pragma: no cover
    relativedelta = None


MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2,
    "mar": 3, "march": 3, "apr": 4, "april": 4, "may": 5,
    "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10, "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

CURRENCY_PATTERNS = [
    (r"\bUSD\b|\bUS\s*Dollars?\b|\bUnited\s+States\s+Dollars?\b|\$", "USD"),
    (r"\bGBP\b|\bPounds?\b|\bSterling\b|£", "GBP"),
    (r"\bEUR\b|\bEuros?\b|€", "EUR"),
    (r"\bCAD\b|\bCanadian\s+Dollars?\b", "CAD"),
    (r"\bAUD\b|\bAustralian\s+Dollars?\b", "AUD"),
    (r"\bINR\b|\bIndian\s+Rupees?\b|₹", "INR"),
]

# A monetary candidate may be written as USD 3,356,843,132, $3.3 billion, 8MM, etc.
_AMOUNT_RE = re.compile(
    r"(?:USD|US\s*Dollars?|GBP|EUR|CAD|AUD|INR|[$£€₹])?\s*"
    r"(?P<number>\d{1,3}(?:[ ,]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*"
    r"(?P<scale>bn|billion|mm|million|m)?\b",
    flags=re.IGNORECASE,
)

_DIRECT_TIV_LABEL_RE = re.compile(
    r"\b(?:TIV|total\s+insur(?:able|ed)\s+values?|total\s+insured\s+values?|"
    r"total\s+values?|total\s+property\s+values?)\b",
    flags=re.IGNORECASE,
)

_NON_TIV_RE = re.compile(
    r"\b(?:per\s+occ(?:urrence)?|deductible|sublimit|sub-limit|annual\s+aggregate|"
    r"limit\s+of\s+liability|policy\s+limit|named\s+windstorm|flood\s+limit|premium)\b",
    flags=re.IGNORECASE,
)

_INSURED_LABEL_RE = re.compile(
    r"\b(?:insured\s+name|name(?:d)?\s+insured|first\s+named\s+insured|"
    r"primary\s+named\s+insured)\b\s*[:\-]?\s*(?P<value>[^\n\r]+)",
    flags=re.IGNORECASE,
)

_INSURED_SUFFIX_PATTERNS = [
    r"\s+and\s+all\s+affiliated\b.*$",
    r"\s+and/or\s+affiliated\b.*$",
    r"\s+and\s+all\s+subsidiar(?:y|ies)\b.*$",
    r"\s+including\s+(?:all\s+)?subsidiar(?:y|ies)\b.*$",
    r"\s+together\s+with\b.*$",
    r"\s+and\s+all\s+associated\b.*$",
    r"\s+and\s+all\s+allied\b.*$",
    r"\s+as\s+now\s+exist\b.*$",
    r"\s+now\s+existing\s+or\s+hereafter\b.*$",
    r"\s+or\s+may\s+hereafter\b.*$",
    r"\s+for\s+which\s+the\s+named\s+insured\b.*$",
]


def _strip_ordinal(day_text: str) -> str:
    return re.sub(r"(?<=\d)(st|nd|rd|th)\b", "", day_text, flags=re.IGNORECASE)


def _format_date(year: int, month: int, day: int) -> Optional[str]:
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return None


def normalize_date_value(value: Any) -> Any:
    if value is None or not isinstance(value, str):
        return value
    text = _strip_ordinal(value.strip())
    if not text:
        return value
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text
    patterns = [
        r"\b(?P<day>\d{1,2})[-\s/]+(?P<month>[A-Za-z]{3,9})[-,\s/]+(?P<year>\d{4})\b",
        r"\b(?P<month>[A-Za-z]{3,9})[-\s]+(?P<day>\d{1,2}),?[-\s]+(?P<year>\d{4})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            month = MONTHS.get(match.group("month").lower())
            if month:
                normalized = _format_date(int(match.group("year")), month, int(match.group("day")))
                if normalized:
                    return normalized
    match = re.search(r"\b(?P<m>\d{1,2})[/-](?P<d>\d{1,2})[/-](?P<y>\d{2,4})\b", text)
    if match:
        year = int(match.group("y"))
        if year < 100:
            year += 2000
        normalized = _format_date(year, int(match.group("m")), int(match.group("d")))
        if normalized:
            return normalized
    return value


def normalize_currency_value(value: Any, evidence: Any = None) -> Any:
    text = " ".join(x for x in [value, evidence] if isinstance(x, str))
    if not text.strip():
        return value
    for pattern, code in CURRENCY_PATTERNS:
        if re.search(pattern, text, flags=re.IGNORECASE):
            return code
    upper_value = value.strip().upper() if isinstance(value, str) else value
    return upper_value if upper_value in {"USD", "GBP", "EUR", "CAD", "AUD", "INR"} else value


def calculate_expiration_from_duration(value: Any, evidence: Any) -> Any:
    if relativedelta is None:
        return value
    text = " ".join(part for part in [str(value or ""), str(evidence or "")] if part).strip()
    duration_match = re.search(r"\b(?P<num>\d{1,2})\s*months?\b", text, flags=re.IGNORECASE)
    if not duration_match:
        return value
    date_candidate = text
    at_match = re.search(r"@\s*(.+)$", text)
    if at_match:
        date_candidate = at_match.group(1)
    inception = normalize_date_value(date_candidate)
    if not isinstance(inception, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", inception):
        return value
    start = datetime.strptime(inception, "%Y-%m-%d")
    return (start + relativedelta(months=int(duration_match.group("num")))).strftime("%Y-%m-%d")


def calculate_expiration_from_inception(inception_value: Any, days: int = 364) -> Optional[str]:
    normalized = normalize_date_value(inception_value)
    if not isinstance(normalized, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return None
    try:
        inception_date = datetime.strptime(normalized, "%Y-%m-%d")
    except ValueError:
        return None
    return (inception_date + timedelta(days=days)).strftime("%Y-%m-%d")


def normalize_monetary_amount(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)
    if not isinstance(value, str) or not value.strip():
        return value
    parsed = _parse_amount(value)
    return parsed[0] if parsed else value


def _parse_amount(text: str) -> Optional[Tuple[str, int, int]]:
    """Return normalized amount plus start/end offsets for the first valid amount."""
    if not isinstance(text, str):
        return None
    for match in _AMOUNT_RE.finditer(text):
        raw_number = match.group("number").replace(",", "").replace(" ", "")
        try:
            amount = Decimal(raw_number)
        except InvalidOperation:
            continue
        scale = (match.group("scale") or "").lower()
        if scale in {"m", "mm", "million"}:
            amount *= Decimal("1000000")
        elif scale in {"bn", "billion"}:
            amount *= Decimal("1000000000")
        if amount <= 0:
            continue
        normalized = format(amount.quantize(Decimal("1")), "f") if amount == amount.to_integral() else format(amount, "f")
        return normalized, match.start(), match.end()
    return None


def clean_insured_name(value: Any) -> Any:
    """Keep only the principal named-insured entity, not the extension clause."""
    if not isinstance(value, str):
        return value
    cleaned = re.sub(r"\s+", " ", value).strip(" ,;:-")
    cleaned = re.sub(
        r"^(?:insured\s+name|name(?:d)?\s+insured|first\s+named\s+insured|primary\s+named\s+insured)\s*[:\-]\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    for pattern in _INSURED_SUFFIX_PATTERNS:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE).strip(" ,;:-")
    # A principal insured name should not be a full policy paragraph.
    if len(cleaned) > 180:
        cleaned = re.split(r"[.;]", cleaned, maxsplit=1)[0].strip(" ,;:-")
    return cleaned or None


def _chunk_original_text(chunk: Any) -> str:
    metadata = getattr(chunk, "metadata", {}) or {}
    return str(metadata.get("original_text") or getattr(chunk, "page_content", "") or "")


def recover_insured_name_from_chunks(chunks: Iterable[Any]) -> Optional[Dict[str, Any]]:
    """Deterministic fallback for obvious labels such as 'Insured Name: Sutter Health'."""
    for chunk in chunks:
        text = _chunk_original_text(chunk)
        for match in _INSURED_LABEL_RE.finditer(text):
            candidate = clean_insured_name(match.group("value"))
            if not candidate or len(candidate) < 2:
                continue
            # Avoid capturing the next field when Azure places only the label on the line.
            if re.match(r"^(?:policy|address|effective|expiration|premium)\b", candidate, flags=re.IGNORECASE):
                continue
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": candidate,
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": match.group(0).strip(),
                "Confidence": 0.98,
            }
    return None


def finalize_insured_name(result: Dict[str, Any], chunks: Iterable[Any]) -> Dict[str, Any]:
    cleaned = dict(result)
    current = clean_insured_name(cleaned.get("Value"))
    if current:
        cleaned["Value"] = current
        if isinstance(cleaned.get("Evidence"), str):
            cleaned["Evidence"] = re.sub(r"\s+", " ", cleaned["Evidence"]).strip()
        return cleaned
    recovered = recover_insured_name_from_chunks(chunks)
    return recovered or {
        "Value": None, "Chunk_id": None, "Chunk_type": None,
        "Evidence": None, "Confidence": 0.0,
    }


def _direct_tiv_candidate(text: str) -> Optional[Tuple[str, str]]:
    """Find a directly labelled TIV amount. Reject unrelated limit/deductible wording."""
    if not isinstance(text, str):
        return None
    compact = re.sub(r"\s+", " ", text).strip()
    for label_match in _DIRECT_TIV_LABEL_RE.finditer(compact):
        window = compact[label_match.start(): label_match.end() + 180]
        # A direct TIV window must not actually be a limit-of-liability or occurrence statement.
        if _NON_TIV_RE.search(window[:120]):
            continue
        amounts = []
        for amount_match in _AMOUNT_RE.finditer(window):
            parsed = _parse_amount(amount_match.group(0))
            if parsed:
                amounts.append((Decimal(parsed[0]), parsed[0], amount_match.group(0).strip()))
        if amounts:
            # In summary tables there may be prior/current/delta amounts. The current TIV is
            # normally the largest insured-value amount; this avoids selecting the YoY delta.
            _, normalized, raw = max(amounts, key=lambda item: item[0])
            evidence = window[: min(len(window), 220)].strip()
            return normalized, evidence
    return None


def _labelled_component(text: str, label: str) -> Optional[Tuple[str, str]]:
    pattern = re.compile(rf"\b{label}\b\s*[:\-]?\s*(?P<tail>.{{0,80}})", flags=re.IGNORECASE)
    for match in pattern.finditer(text):
        tail = match.group("tail")
        if re.search(r"\b(?:deductible|per occurrence|sublimit|premium|yoy|change)\b", tail, flags=re.IGNORECASE):
            continue
        parsed = _parse_amount(tail)
        if parsed:
            return parsed[0], match.group(0).strip()
    return None


def _building_contents_candidate(text: str) -> Optional[Tuple[str, str]]:
    if not isinstance(text, str):
        return None
    compact = re.sub(r"\s+", " ", text)
    building = _labelled_component(compact, r"buildings?(?:\s+value)?")
    contents = _labelled_component(compact, r"contents?(?:\s+value)?")
    if not building or not contents:
        return None
    total = Decimal(building[0]) + Decimal(contents[0])
    normalized = format(total.quantize(Decimal("1")), "f")
    return normalized, f"{building[1]} | {contents[1]}"


def validate_limit_one(result: Dict[str, Any], chunks: Iterable[Any], min_confidence: float = 0.80) -> Dict[str, Any]:
    """
    Ground Limit One deterministically.

    Accepted only when:
    1) a direct TIV/Total Insured Value label is tied to an amount, or
    2) both Building and Contents values are explicitly labelled and Python can add them.

    Coverage limits, deductibles, per-occurrence amounts, sublimits and unsupported LLM
    calculations are rejected and returned as null.
    """
    chunk_list = list(chunks)
    result_confidence = float(result.get("Confidence") or 0.0)
    evidence = str(result.get("Evidence") or "")

    # First validate the exact evidence selected by the model.
    direct = _direct_tiv_candidate(evidence)
    if direct and result_confidence >= min_confidence:
        return {
            **result,
            "Value": direct[0],
            "Evidence": direct[1],
            "Confidence": max(result_confidence, 0.95),
            "Validation": "Direct labelled TIV evidence",
        }
    calculated = _building_contents_candidate(evidence)
    if calculated and result_confidence >= min_confidence:
        return {
            **result,
            "Value": calculated[0],
            "Evidence": calculated[1],
            "Confidence": max(result_confidence, 0.90),
            "Validation": "Building + Contents calculated in Python",
        }

    # If the LLM selected the wrong amount, recover only from strong retrieved evidence.
    for chunk in chunk_list:
        text = _chunk_original_text(chunk)
        direct = _direct_tiv_candidate(text)
        if direct:
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": direct[0],
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": direct[1],
                "Confidence": 0.95,
                "Validation": "Recovered from direct labelled TIV evidence",
            }

    for chunk in chunk_list:
        text = _chunk_original_text(chunk)
        calculated = _building_contents_candidate(text)
        if calculated:
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": calculated[0],
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": calculated[1],
                "Confidence": 0.90,
                "Validation": "Recovered and calculated from Building + Contents",
            }

    return {
        "Value": None,
        "Chunk_id": None,
        "Chunk_type": None,
        "Evidence": None,
        "Confidence": 0.0,
        "Validation": "Rejected: no direct TIV or verified Building + Contents evidence",
    }


def post_process_result(field_name: str, result: Dict[str, Any]) -> Dict[str, Any]:
    cleaned = dict(result)
    value = cleaned.get("Value")
    evidence = cleaned.get("Evidence")
    normalized_name = (field_name or "").strip().lower()

    if normalized_name in {"inception date", "effective date"}:
        cleaned["Value"] = normalize_date_value(value)
    elif normalized_name in {"expiration date", "expiry date"}:
        cleaned["Value"] = normalize_date_value(calculate_expiration_from_duration(value, evidence))
    elif normalized_name == "currency":
        cleaned["Value"] = normalize_currency_value(value, evidence)
    elif normalized_name == "insured name":
        cleaned["Value"] = clean_insured_name(value)
    elif normalized_name == "limit one":
        # Final grounding is intentionally performed by validate_limit_one(), which also
        # receives the retrieved chunks. Do not trust/normalize an unverified LLM number here.
        cleaned["Value"] = normalize_monetary_amount(value)
    return cleaned
