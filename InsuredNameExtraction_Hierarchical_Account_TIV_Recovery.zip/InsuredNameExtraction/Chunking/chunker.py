import re
import uuid
from collections import defaultdict
from typing import Any, Dict, List, Optional

from langchain_text_splitters import RecursiveCharacterTextSplitter

from Chunking.section_chunker import clean_text, detect_sections, split_section
from Chunking.table_chunker import build_header_aware_rows, table_is_relevant


def make_chunk(
    document_id: str,
    source: str,
    page: Optional[int],
    text: str,
    chunk_type: str,
    parent_id: Optional[str] = None,
    chunk_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    retrieval_text: Optional[str] = None,
) -> Dict[str, Any]:
    return {
        "chunk_id": chunk_id or str(uuid.uuid4()),
        "parent_id": parent_id,
        "document_id": document_id,
        "source": source,
        "page": page,
        "text": clean_text(text),
        "retrieval_text": retrieval_text or clean_text(text),
        "chunk_type": chunk_type,
        "metadata": metadata or {},
    }


def _page_from_regions(item: Dict[str, Any]) -> Optional[int]:
    regions = item.get("boundingRegions", []) or []
    return regions[0].get("pageNumber") if regions else None


def _page_text(page: Dict[str, Any]) -> str:
    lines = page.get("lines", []) or []
    line_text = "\n".join(clean_text(line.get("content", "")) for line in lines)
    return clean_text(line_text or page.get("content", ""))


def extract_page_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    for page in doc["azure_result"].get("pages", []) or []:
        page_number = page.get("pageNumber")
        text = _page_text(page)
        if not text:
            continue
        chunk_id = f"{doc['document_id']}::page::{page_number}"
        chunks.append(make_chunk(
            document_id=doc["document_id"], source=doc["source"], page=page_number,
            text=text, retrieval_text=f"Page {page_number}\n{text}", chunk_type="page",
            chunk_id=chunk_id,
            metadata={"bounding_regions": page.get("spans", []), "is_parent_chunk": True},
        ))
    return chunks


def extract_key_value_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Keep Azure key-values as small, high-priority chunks and metadata-rich evidence."""
    chunks: List[Dict[str, Any]] = []
    for idx, kv in enumerate(doc["azure_result"].get("keyValuePairs", []) or [], start=1):
        key_obj = kv.get("key") or {}
        value_obj = kv.get("value") or {}
        key = clean_text(key_obj.get("content", ""))
        value = clean_text(value_obj.get("content", ""))
        if not key and not value:
            continue
        text = f"{key}: {value}" if key and value else key or value
        page = _page_from_regions(key_obj or value_obj)
        chunks.append(make_chunk(
            document_id=doc["document_id"], source=doc["source"], page=page,
            text=text, retrieval_text=f"Key-value pair\nKey: {key}\nValue: {value}",
            chunk_type="key_value", parent_id=f"{doc['document_id']}::page::{page}",
            metadata={
                "key_value_index": idx, "key": key, "value": value,
                "confidence": kv.get("confidence"),
                "key_bounding_regions": key_obj.get("boundingRegions", []),
                "value_bounding_regions": value_obj.get("boundingRegions", []),
                "priority": "high",
            },
        ))
    return chunks


def _section_for_page(sections: List[Dict[str, Any]], page: Optional[int]) -> Optional[Dict[str, Any]]:
    if page is None:
        return None
    candidates = [s for s in sections if s.get("page_start") and s.get("page_end") and s["page_start"] <= page <= s["page_end"]]
    return candidates[-1] if candidates else None


def extract_selective_table_chunks(doc: Dict[str, Any], sections: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    for table_index, table in enumerate(doc["azure_result"].get("tables", []) or [], start=1):
        cells = table.get("cells", []) or []
        if not cells:
            continue
        page = _page_from_regions(table)
        section = _section_for_page(sections, page)
        section_heading = section.get("heading", "") if section else ""

        raw_rows: Dict[int, Dict[int, str]] = defaultdict(dict)
        for cell in cells:
            raw_rows[int(cell.get("rowIndex", 0))][int(cell.get("columnIndex", 0))] = clean_text(cell.get("content", ""))
        table_lines = [" | ".join(row[c] for c in sorted(row) if row[c]) for _, row in sorted(raw_rows.items())]
        table_text = clean_text("\n".join(line for line in table_lines if line))
        if not table_text or not table_is_relevant(table_text, section_heading):
            continue

        table_id = f"{doc['document_id']}::page::{page}::table::{table_index}"
        parent_id = section.get("section_id") if section else f"{doc['document_id']}::page::{page}"
        chunks.append(make_chunk(
            document_id=doc["document_id"], source=doc["source"], page=page,
            text=table_text,
            retrieval_text=f"Section: {section_heading}\nRelevant insurance table:\n{table_text}",
            chunk_type="table", parent_id=parent_id, chunk_id=table_id,
            metadata={
                "table_index": table_index, "section_heading": section_heading,
                "row_count": table.get("rowCount"), "column_count": table.get("columnCount"),
                "bounding_regions": table.get("boundingRegions", []),
            },
        ))

        for row_index, row_text in enumerate(build_header_aware_rows(cells), start=1):
            chunks.append(make_chunk(
                document_id=doc["document_id"], source=doc["source"], page=page,
                text=row_text,
                retrieval_text=f"Section: {section_heading}\nTable row: {row_text}",
                chunk_type="table_row", parent_id=table_id,
                metadata={"table_index": table_index, "row_index": row_index, "section_heading": section_heading},
            ))
    return chunks


def _dedupe_chunks(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    priority = {"key_value": 100, "table_row": 90, "table": 80, "section_split": 70, "section": 65, "page": 40}
    seen: Dict[str, Dict[str, Any]] = {}
    for chunk in chunks:
        normalized = re.sub(r"\W+", " ", chunk.get("text", "").lower()).strip()
        if not normalized:
            continue
        existing = seen.get(normalized)
        if existing is None or priority.get(chunk["chunk_type"], 0) > priority.get(existing["chunk_type"], 0):
            seen[normalized] = chunk
    return list(seen.values())


def chunk_azure_documents(analyzed_documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Hierarchical page/section chunking with selective tables and high-priority key-values."""
    all_chunks: List[Dict[str, Any]] = []

    max_chars = int(__import__("os").getenv("SECTION_MAX_CHARS", "6000"))
    overlap_chars = int(__import__("os").getenv("SECTION_OVERLAP_CHARS", "450"))
    summary_chars = int(__import__("os").getenv("PREVIOUS_SUMMARY_MAX_CHARS", "500"))

    for doc in analyzed_documents:
        page_chunks = extract_page_chunks(doc)
        sections = detect_sections(doc)
        section_chunks: List[Dict[str, Any]] = []
        for section in sections:
            for split in split_section(section, max_chars=max_chars, overlap_chars=overlap_chars, summary_chars=summary_chars):
                section_chunks.append(make_chunk(
                    document_id=doc["document_id"], source=doc["source"], page=split.get("page_start"),
                    text=split["text"], retrieval_text=split["retrieval_text"],
                    chunk_type=split["chunk_type"], parent_id=split.get("parent_id"), chunk_id=split["chunk_id"],
                    metadata={
                        "section_heading": split["heading"], "page_start": split.get("page_start"),
                        "page_end": split.get("page_end"), "bounding_regions": split.get("bounding_regions", []),
                        "previous_context_summary": split.get("previous_context_summary", ""),
                        "overlap_text": split.get("overlap_text", ""),
                        "split_index": split.get("split_index"), "split_count": split.get("split_count"),
                    },
                ))

        table_chunks = extract_selective_table_chunks(doc, sections)
        key_value_chunks = extract_key_value_chunks(doc)
        document_chunks = _dedupe_chunks(page_chunks + section_chunks + table_chunks + key_value_chunks)
        all_chunks.extend(document_chunks)
        print(
            f"{doc['document_id']} hierarchical chunks: pages={len(page_chunks)}, "
            f"sections/splits={len(section_chunks)}, selective_tables/rows={len(table_chunks)}, "
            f"key_values={len(key_value_chunks)}, after_dedupe={len(document_chunks)}"
        )

    print(f"Total hierarchical chunks created: {len(all_chunks)}")
    return all_chunks


def chunk_documents(pages: List[Dict[str, Any]], chunk_size: int = 5000, chunk_overlap: int = 350) -> List[Dict[str, Any]]:
    """Local-mode fallback. Azure mode is recommended for structure-aware chunking."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks: List[Dict[str, Any]] = []
    for page in pages:
        for index, text in enumerate(splitter.split_text(page.get("text", "")), start=1):
            chunks.append(make_chunk(
                document_id=page.get("document_id", "unknown_document"),
                source=page.get("source", ""), page=page.get("page"), text=text,
                retrieval_text=f"Page {page.get('page')} part {index}\n{text}",
                chunk_type="fixed_text", metadata={"split_index": index},
            ))
    return chunks
