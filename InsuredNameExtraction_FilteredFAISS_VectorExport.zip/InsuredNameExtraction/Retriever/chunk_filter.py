import re
from collections import Counter
from typing import Any, Dict, List, Tuple


HEADER_KEYWORDS = [
    "insured", "named insured", "first named insured", "primary named insured",
    "name of insured", "applicant", "account name", "client name",
    "policy period", "policy term", "period", "effective date",
    "inception date", "expiration date", "expiry date", "from", "to",
    "begins", "beginning", "ends", "ending", "attachment date",
]

CURRENCY_KEYWORDS = [
    "currency", "usd", "us dollar", "us dollars", "united states dollar",
    "gbp", "eur", "cad", "aud", "inr", "$", "£", "€", "₹",
    "limit", "limit of liability", "premium", "deductible", "occurrence",
    "aggregate", "values", "tiv", "sum insured",
]

SUBLIMIT_KEYWORDS = [
    "sublimit", "sub-limit", "sub limit", "sub-limits", "sub limits",
    "peril", "perils", "area", "areas", "territory", "territories",
    "occupancy", "occupancies", "coverage", "coverage limit",
    "flood", "earthquake", "earth movement", "windstorm", "named storm",
    "storm surge", "hail", "convective storm", "aop", "all other perils",
    "terrorism", "civil commotion", "riot", "strike", "fire", "lightning",
    "business interruption", "bi", "extra expense", "time element",
]

DATE_PATTERN = re.compile(
    r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|"
    r"\b\d{1,2}[-\s](jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*[-\s]\d{4}\b|"
    r"\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2},?\s+\d{4}\b",
    flags=re.IGNORECASE,
)

MONEY_PATTERN = re.compile(
    r"\b(USD|GBP|EUR|CAD|AUD|INR)\b|\$|£|€|₹|"
    r"\b\d{1,3}(,\d{3})+(\.\d+)?\b",
    flags=re.IGNORECASE,
)


HIGH_VALUE_TYPES = {"key_value", "key_value_pair", "kv"}
TABLE_TYPES = {"table", "table_row", "table_cell", "table_split"}
SECTION_TYPES = {"section", "section_candidate", "section_candidate_split"}
PAGE_TYPES = {"page", "page_split", "fixed_text"}


def _get_text(chunk: Any) -> str:
    if isinstance(chunk, dict):
        return chunk.get("text") or chunk.get("content") or ""
    return getattr(chunk, "page_content", "") or ""


def _get_metadata(chunk: Any) -> Dict[str, Any]:
    if isinstance(chunk, dict):
        metadata = dict(chunk.get("metadata", {}) or {})
        # Also expose top-level fields as metadata-like values for scoring.
        for key in ["chunk_id", "parent_id", "document_id", "source", "page", "chunk_type"]:
            if key in chunk and key not in metadata:
                metadata[key] = chunk[key]
        return metadata
    return getattr(chunk, "metadata", {}) or {}


def _as_page_number(value: Any) -> int | None:
    try:
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def _contains_any(text: str, keywords: List[str]) -> int:
    score = 0
    for keyword in keywords:
        keyword = keyword.lower().strip()
        if keyword and keyword in text:
            score += 1
    return score


def score_chunk_for_extraction(chunk: Dict[str, Any]) -> int:
    """
    Score one chunk for whether it should be embedded/indexed.

    This keeps the current mixed chunking strategy unchanged, but prevents FAISS
    from embedding thousands of low-value chunks such as notices/signatures/etc.
    """
    raw_text = _get_text(chunk)
    text = re.sub(r"\s+", " ", raw_text.lower()).strip()
    metadata = _get_metadata(chunk)

    chunk_type = str(metadata.get("chunk_type", "")).lower()
    page_number = _as_page_number(metadata.get("page") or metadata.get("page_number"))

    score = 0

    # First pages usually contain insured name, policy period and currency.
    if page_number and page_number <= 5:
        score += 2

    # Key-value chunks from Azure are high signal for named insured/effective dates.
    if chunk_type in HIGH_VALUE_TYPES:
        score += 5

    # Tables/table rows are high signal for limits, sublimits, perils, areas, occupancies.
    if chunk_type in TABLE_TYPES:
        score += 3

    # Section candidates are usually useful because they already matched insurance keywords.
    if chunk_type in SECTION_TYPES:
        score += 2

    header_hits = _contains_any(text, HEADER_KEYWORDS)
    currency_hits = _contains_any(text, CURRENCY_KEYWORDS)
    sublimit_hits = _contains_any(text, SUBLIMIT_KEYWORDS)

    score += min(header_hits * 3, 15)
    score += min(currency_hits * 2, 12)
    score += min(sublimit_hits * 4, 24)

    if DATE_PATTERN.search(raw_text):
        score += 3

    if MONEY_PATTERN.search(raw_text):
        score += 3

    # Keep compact chunks a little more readily than very large generic page text.
    if len(raw_text) <= 1200 and score > 0:
        score += 1

    return score


def _add_parent_chunks(selected_chunks: List[Dict[str, Any]], all_chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Add parent page/table chunks for selected child chunks so evidence has context."""
    by_chunk_id = {chunk.get("chunk_id"): chunk for chunk in all_chunks if chunk.get("chunk_id")}
    selected_ids = {chunk.get("chunk_id") for chunk in selected_chunks}
    output = list(selected_chunks)

    for chunk in selected_chunks:
        parent_id = chunk.get("parent_id")
        parent_chunk = by_chunk_id.get(parent_id)
        if parent_chunk and parent_chunk.get("chunk_id") not in selected_ids:
            output.append(parent_chunk)
            selected_ids.add(parent_chunk.get("chunk_id"))

    return output


def filter_chunks_for_faiss(
    chunks: List[Dict[str, Any]],
    min_score: int = 2,
    max_chunks: int = 1200,
    keep_first_pages: int = 5,
    include_parent_chunks: bool = True,
    return_summary: bool = False,
) -> List[Dict[str, Any]] | Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Filter chunks before FAISS indexing.

    The mixed chunking pipeline can still create page/paragraph/key-value/table/section
    chunks. This function only controls which chunks are expensive enough to embed.
    """
    if not chunks:
        summary = {"total_chunks": 0, "filtered_chunks": 0, "max_chunks": max_chunks}
        return ([], summary) if return_summary else []

    scored: List[Tuple[int, Dict[str, Any]]] = []

    for chunk in chunks:
        score = score_chunk_for_extraction(chunk)
        page_number = _as_page_number(chunk.get("page"))
        chunk_type = str(chunk.get("chunk_type", "")).lower()

        # Safety: always retain first few page-level chunks for header fields.
        if page_number and page_number <= keep_first_pages and chunk_type in PAGE_TYPES:
            score = max(score, min_score)

        if score >= min_score:
            scored.append((score, chunk))

    scored.sort(key=lambda item: item[0], reverse=True)
    filtered_chunks = [chunk for _, chunk in scored[:max_chunks]]

    if include_parent_chunks:
        filtered_chunks = _add_parent_chunks(filtered_chunks, chunks)
        # Keep parent-added chunks within max limit while preserving order.
        seen = set()
        deduped = []
        for chunk in filtered_chunks:
            chunk_id = chunk.get("chunk_id")
            if chunk_id in seen:
                continue
            seen.add(chunk_id)
            deduped.append(chunk)
        filtered_chunks = deduped[:max_chunks]

    # Safety fallback: if filtering became too strict, keep first max_chunks chunks.
    if len(filtered_chunks) < 20:
        filtered_chunks = chunks[: min(len(chunks), max_chunks)]

    type_counts = Counter(str(chunk.get("chunk_type", "unknown")) for chunk in filtered_chunks)
    summary = {
        "total_chunks": len(chunks),
        "filtered_chunks": len(filtered_chunks),
        "removed_chunks": max(len(chunks) - len(filtered_chunks), 0),
        "min_score": min_score,
        "max_chunks": max_chunks,
        "keep_first_pages": keep_first_pages,
        "chunk_type_counts": dict(type_counts),
    }

    return (filtered_chunks, summary) if return_summary else filtered_chunks
