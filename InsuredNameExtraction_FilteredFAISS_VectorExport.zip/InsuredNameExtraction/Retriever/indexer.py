import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

load_dotenv()

HF_TOKEN = os.getenv("HUGGING_FACE_TOKEN")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "BAAI/bge-base-en")
EMBEDDING_DEVICE = os.getenv("EMBEDDING_DEVICE", "cpu")
EMBEDDING_BATCH_SIZE = int(os.getenv("EMBEDDING_BATCH_SIZE", "32"))


def get_embedding_model() -> HuggingFaceEmbeddings:
    """Create the embedding model used by FAISS and vector export."""
    return HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL_NAME,
        model_kwargs={
            "device": EMBEDDING_DEVICE,
            "token": HF_TOKEN,
        },
        encode_kwargs={
            "normalize_embeddings": True,
            "batch_size": EMBEDDING_BATCH_SIZE,
        },
    )


def chunks_to_documents(chunks: List[Dict[str, Any]]) -> List[Document]:
    """Convert normalized chunk dictionaries into LangChain Documents."""
    documents: List[Document] = []

    for chunk in chunks:
        text = chunk.get("text", "")
        if not text.strip():
            continue

        documents.append(
            Document(
                page_content=text,
                metadata={
                    "chunk_id": chunk["chunk_id"],
                    "parent_id": chunk.get("parent_id"),
                    "document_id": chunk["document_id"],
                    "source": chunk["source"],
                    "page": chunk["page"],
                    "chunk_type": chunk.get("chunk_type"),
                    "extra_metadata": chunk.get("metadata", {}),
                },
            )
        )

    return documents


def save_vectors_jsonl(
    documents: List[Document],
    embeddings: List[List[float]],
    output_path: str,
) -> None:
    """
    Store one JSONL record per chunk containing text, metadata and vector.

    This file can later be loaded into a vector DB/table with columns such as:
    document_id, chunk_id, page, chunk_type, text, embedding_model, vector.
    """
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        for document, vector in zip(documents, embeddings):
            record = {
                "document_id": document.metadata.get("document_id"),
                "chunk_id": document.metadata.get("chunk_id"),
                "parent_id": document.metadata.get("parent_id"),
                "source": document.metadata.get("source"),
                "page": document.metadata.get("page"),
                "chunk_type": document.metadata.get("chunk_type"),
                "text": document.page_content,
                "metadata": document.metadata.get("extra_metadata", {}),
                "embedding_model": EMBEDDING_MODEL_NAME,
                "embedding_dimension": len(vector),
                "vector": vector,
            }
            file.write(json.dumps(record, ensure_ascii=False) + "\n")


def save_vector_summary(
    documents: List[Document],
    embeddings: List[List[float]],
    vectors_output_path: str,
) -> None:
    """Save a small companion summary so you can inspect vector export quickly."""
    summary_path = str(Path(vectors_output_path).with_suffix(".summary.json"))
    dimension = len(embeddings[0]) if embeddings else 0
    summary = {
        "vector_file": vectors_output_path,
        "embedding_model": EMBEDDING_MODEL_NAME,
        "embedding_device": EMBEDDING_DEVICE,
        "embedding_batch_size": EMBEDDING_BATCH_SIZE,
        "total_vectors": len(embeddings),
        "embedding_dimension": dimension,
        "documents": sorted({doc.metadata.get("document_id") for doc in documents}),
    }
    Path(summary_path).parent.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w", encoding="utf-8") as file:
        json.dump(summary, file, indent=2, ensure_ascii=False)


def create_faiss_index(
    chunks: List[Dict[str, Any]],
    vectors_output_path: Optional[str] = None,
    faiss_output_folder: Optional[str] = None,
) -> FAISS:
    """
    Create one FAISS vector index for filtered document chunks.

    If vectors_output_path is provided, the exact embedding vector generated for each
    chunk is also exported as JSONL for future database/vector-store loading.
    If faiss_output_folder is provided, the local FAISS index is persisted too.
    """
    if not chunks:
        raise ValueError("No chunks available to index.")

    embedding_model = get_embedding_model()
    documents = chunks_to_documents(chunks)

    if not documents:
        raise ValueError("All chunks were empty. Nothing to index.")

    texts = [document.page_content for document in documents]
    metadatas = [document.metadata for document in documents]
    ids = [str(document.metadata.get("chunk_id")) for document in documents]

    print(
        f"Generating embeddings for {len(documents)} filtered chunks "
        f"using {EMBEDDING_MODEL_NAME} on {EMBEDDING_DEVICE}..."
    )
    embeddings = embedding_model.embed_documents(texts)

    if vectors_output_path:
        save_vectors_jsonl(documents, embeddings, vectors_output_path)
        save_vector_summary(documents, embeddings, vectors_output_path)
        print(f"Chunk vectors saved to: {vectors_output_path}")

    text_embeddings: List[Tuple[str, List[float]]] = list(zip(texts, embeddings))
    vector_store = FAISS.from_embeddings(
        text_embeddings=text_embeddings,
        embedding=embedding_model,
        metadatas=metadatas,
        ids=ids,
    )

    if faiss_output_folder:
        Path(faiss_output_folder).mkdir(parents=True, exist_ok=True)
        vector_store.save_local(faiss_output_folder)
        print(f"FAISS index saved to: {faiss_output_folder}")

    print(f"FAISS index created successfully with {len(documents)} filtered chunks.")
    return vector_store
