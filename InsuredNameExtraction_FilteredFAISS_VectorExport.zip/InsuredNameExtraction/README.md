# Insurance Slip Field Extraction - Azure Document Intelligence + Mixed Chunking

This project extracts key insurance slip fields using a layout-aware RAG pipeline.

## Fields extracted

The updated version extracts:

1. **Insured Name**
2. **Inception Date** / Effective Date
3. **Expiration Date** / Expiry Date
4. **Currency**

Dates are normalized to:

```text
YYYY-MM-DD
```

Currency is normalized to ISO-style codes, for example:

```text
USD, GBP, EUR, CAD, AUD, INR
```

## Important date handling added

The extraction now handles different slip behaviors, including:

```text
Effective Date: from 9/1/2026 to 9/1/2027
```

Output:

```json
{
  "Inception Date": "2026-09-01",
  "Expiration Date": "2027-09-01"
}
```

```text
Inception date: 12 months @ 1st September 2026
```

Output:

```json
{
  "Inception Date": "2026-09-01",
  "Expiration Date": "2027-09-01"
}
```

```text
Policy Period
From: 01-August-2025
To: 01-August-2026
```

Output:

```json
{
  "Inception Date": "2025-08-01",
  "Expiration Date": "2026-08-01"
}
```

```text
Policy Term: 8/12/2026 to 8/12/2027
```

Output:

```json
{
  "Inception Date": "2026-08-12",
  "Expiration Date": "2027-08-12"
}
```

## Currency handling added

The extraction detects currency from monetary evidence such as:

```text
USD 50,000,000 per occurrence
$100,000 deductible
US Dollars
GBP
EUR
```

For example:

```text
LIMIT OF LIABILITY: USD 50,000,000 per occurrence
```

Output:

```json
{
  "Currency": "USD"
}
```

## Pipeline

```text
Document
  -> Azure Document Intelligence
  -> Raw Azure JSON saved
  -> Mixed chunking
     - page chunks
     - paragraph chunks
     - key-value chunks
     - table chunks
     - table-row chunks
     - section-candidate chunks
     - parent-child mapping
  -> chunks_output.json saved
  -> FAISS index
  -> hybrid retrieval
     - field-specific keyword retrieval
     - vector retrieval
     - parent context expansion
  -> Azure OpenAI field extraction
  -> deterministic post-processing
     - date normalization
     - duration-based expiration fallback
     - currency normalization
  -> one extraction result per document
  -> combined extraction_output.json
  -> per-document JSON files inside extraction_outputs/
```

## Folder Structure

```text
InsuredNameExtraction/
├── Documents/
├── DocumentIntelligence/
│   └── azure_document_loader.py
├── Fields/
│   ├── fields.json
│   └── fields_loader.py
├── Chunking/
│   ├── document_loader.py
│   └── chunker.py
├── Retriever/
│   ├── indexer.py
│   ├── retriever.py
│   ├── context_builder.py
│   └── llm.py
├── Prompt/
│   └── prompt.py
├── Utilities/
│   └── post_processor.py
├── .env.example
├── main.py
└── requirements.txt
```

## Required Azure resources

You need:

1. Azure AI Document Intelligence resource
2. Azure Document Intelligence endpoint and key
3. Azure OpenAI resource
4. Azure OpenAI chat model deployment
5. Hugging Face token, if your embedding model requires it

Recommended Document Intelligence model:

```text
prebuilt-document
```

Why: it can return layout content plus key-value pairs where available.

Alternative:

```text
prebuilt-layout
```

Use this if you only want OCR/layout/tables and do not care about Azure key-value pair extraction.

## Setup

Create and activate a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env`:

```bash
copy .env.example .env
```

Fill these values:

```env
EXTRACTION_MODE=azure

AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://your-doc-intel-resource.cognitiveservices.azure.com/
AZURE_DOCUMENT_INTELLIGENCE_KEY=your_document_intelligence_key_here
AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID=prebuilt-document

HUGGING_FACE_TOKEN=your_huggingface_token_here
EMBEDDING_MODEL_NAME=BAAI/bge-base-en

AZURE_OPENAI_KEY=your_azure_openai_key_here
AZURE_OPENAI_ENDPOINT=https://your-openai-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-02-15-preview
AZURE_OPENAI_DEPLOYMENT_NAME=your_chat_model_deployment_name
```

Put your documents inside:

```text
Documents/
```

Supported by the Azure loader:

```text
.pdf, .png, .jpg, .jpeg, .tif, .tiff, .bmp, .docx
```

Run:

```bash
python main.py
```

## Output files

### 1. Raw Azure JSON

Saved inside:

```text
azure_layout_json/
```

### 2. Mixed chunks

Saved as:

```text
chunks_output.json
```

### 3. Final extraction output

The updated version processes every supported file inside the `Documents/` folder independently.

Combined output for all documents is saved as:

```text
extraction_output.json
```

Individual per-document outputs are also saved inside:

```text
extraction_outputs/
```

Example combined output structure:

```json
{
  "total_documents": 2,
  "documents": [
    {
      "document_id": "Slip_1.pdf",
      "status": "success",
      "fields": {
        "Insured Name": {
    "Value": "Community Development Partners",
    "Chunk_id": "abc-123",
    "Chunk_type": "paragraph",
    "Evidence": "Named Insured: Community Development Partners",
    "Confidence": 0.95
  },
  "Inception Date": {
    "Value": "2026-08-12",
    "Chunk_id": "def-456",
    "Chunk_type": "key_value",
    "Evidence": "Policy Term: 8/12/2026 to 8/12/2027",
    "Confidence": 0.95
  },
  "Expiration Date": {
    "Value": "2027-08-12",
    "Chunk_id": "def-456",
    "Chunk_type": "key_value",
    "Evidence": "Policy Term: 8/12/2026 to 8/12/2027",
    "Confidence": 0.95
  },
        "Currency": {
          "Value": "USD",
          "Chunk_id": "ghi-789",
          "Chunk_type": "paragraph",
          "Evidence": "LIMIT OF LIABILITY: USD 50,000,000 per occurrence",
          "Confidence": 0.95,
          "Document_id": "Slip_1.pdf"
        }
      }
    }
  ]
}
```

## Local fallback mode

If you want to run without Azure Document Intelligence, set:

```env
EXTRACTION_MODE=local
```

This uses the old local PDF/DOCX text extraction and fixed-size chunking.

## Latest update: filtered FAISS indexing + vector export

The mixed chunking strategy is still kept as-is. The pipeline still creates page, paragraph, key-value, table/table-row and section-candidate chunks.

The optimization is now applied before FAISS indexing:

```text
All mixed chunks
   ↓
Score/filter chunks for extraction relevance
   ↓
Embed only filtered chunks
   ↓
Create FAISS index
   ↓
Extract fields
```

This reduces the expensive embedding/indexing workload while avoiding a major rewrite of the chunking pipeline.

### New files/folders generated at runtime

```text
chunks_output.json
```

Stores all mixed chunks created from all documents.

```text
filtered_chunks/<document>_filtered_chunks.json
```

Stores only the candidate chunks selected for FAISS indexing.

```text
vector_outputs/<document>_chunk_vectors.jsonl
```

Stores one JSONL record per embedded chunk. Each line contains:

```json
{
  "document_id": "Slip_1.pdf",
  "chunk_id": "...",
  "parent_id": "...",
  "source": "...",
  "page": 1,
  "chunk_type": "table_row",
  "text": "Peril | Area | Limit ...",
  "metadata": {},
  "embedding_model": "BAAI/bge-base-en",
  "embedding_dimension": 768,
  "vector": [0.0123, -0.0456]
}
```

This can later be loaded into a database/vector database. Recommended columns are:

```text
document_id
chunk_id
parent_id
source
page
chunk_type
text
metadata_json
embedding_model
embedding_dimension
vector
```

```text
vector_outputs/<document>_chunk_vectors.summary.json
```

Small summary file containing vector count, model name and embedding dimension.

```text
faiss_indexes/<document>/
```

Stores the persisted local FAISS index for that document.

### New configuration options

Add these to `.env` if you want to tune performance:

```env
EMBEDDING_DEVICE=cpu
EMBEDDING_BATCH_SIZE=32
FAISS_FILTER_MIN_SCORE=2
FAISS_FILTER_MAX_CHUNKS=1200
FAISS_FILTER_KEEP_FIRST_PAGES=5
```

For large documents, the most important value is:

```env
FAISS_FILTER_MAX_CHUNKS=1200
```

If a 100+ page document is still slow, reduce it to 800. If you feel relevant sublimit rows are getting missed, increase it to 1500 or 2000.

### What the filter keeps

The filter gives higher score to chunks containing terms related to:

```text
insured name
policy term / policy period / effective date
currency / USD / limits / deductibles / premium
sublimit / peril / area / territory / occupancy
flood / earthquake / named storm / windstorm / AOP
```

It also keeps first-page chunks and high-value Azure key-value chunks because those usually contain policy-level fields.
