import json
import re
from typing import Any, Dict, List

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from Prompt.sublimit_prompt import SYSTEM_SUBLIMIT_PROMPT, USER_SUBLIMIT_PROMPT
from Retriever.llm import get_llm


def _extract_json(text: str) -> str:
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        return text
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not match:
        raise ValueError("No JSON object found in LLM output")
    return match.group(0)


def run_sublimit_llm(context: str) -> List[Dict[str, Any]]:
    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_SUBLIMIT_PROMPT),
        ("human", USER_SUBLIMIT_PROMPT),
    ])
    raw = (prompt | get_llm() | StrOutputParser()).invoke({"context": context})
    print(f"Raw sublimit LLM output:\n{raw}")
    try:
        parsed = json.loads(_extract_json(raw))
        clauses = parsed.get("clauses", [])
        return clauses if isinstance(clauses, list) else []
    except Exception as exc:
        print(f"Failed to parse sublimit LLM output: {exc}")
        return []
