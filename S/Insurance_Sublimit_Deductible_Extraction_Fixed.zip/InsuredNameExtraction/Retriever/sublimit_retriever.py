import re
from typing import Any, List, Tuple

from langchain_core.documents import Document

from Retriever.retriever import dedupe_documents, expand_with_parent_context, get_all_indexed_documents

KEYWORDS = [
    "deductible", "deductibles", "retention", "excess", "minimum", "maximum",
    "per occurrence", "per occ", "percentage", "subject to", "earth movement",
    "earthquake", "windstorm", "hail", "wind driven rain", "flood", "aop",
    "all other perils", "terrorism", "contractors equipment", "musical equipment"
]


def _score(doc: Document) -> int:
    text = re.sub(r"\s+", " ", doc.page_content.lower())
    score = sum(12 for keyword in KEYWORDS if keyword in text)
    ctype = str(doc.metadata.get("chunk_type", "")).lower()
    if ctype in {"section", "section_split", "paragraph", "key_value", "table_row"}:
        score += 20
    if "deduct" in text or "retention" in text:
        score += 80
    if re.search(r"(?:USD|GBP|EUR|CAD|AUD|INR|\$|£|€)\s*[\d,]+|\b\d+(?:\.\d+)?%", doc.page_content, re.I):
        score += 25
    return score


def retrieve_deductible_chunks(vector_store, k: int = 14) -> List[Any]:
    query = "insurance deductible clauses retention minimum maximum per occurrence earth movement windstorm hail flood AOP terrorism"
    vector_results = vector_store.similarity_search(query, k=k)
    ranked: List[Tuple[int, Document]] = [(_score(doc), doc) for doc in get_all_indexed_documents(vector_store)]
    ranked = [item for item in ranked if item[0] > 0]
    ranked.sort(key=lambda item: item[0], reverse=True)
    keyword_results = [doc for _, doc in ranked[:k]]
    combined = dedupe_documents(keyword_results + vector_results)
    expanded = expand_with_parent_context(vector_store, combined, max_parent_docs=5)
    return expanded[: k + 5]


def retrieve_tiv_chunks(vector_store, k: int = 10) -> List[Any]:
    query = "TIV total insured value total insurable value total values buildings contents statement of values"
    return vector_store.similarity_search(query, k=k)
