import json
import re
from typing import Any, Dict, List

from langchain_core.messages import HumanMessage, SystemMessage

from Prompt.sublimit_prompt import SYSTEM_SUBLIMIT_PROMPT, USER_SUBLIMIT_PROMPT
from Retriever.llm import get_llm


def _extract_json(text: str) -> str:
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        return text
    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not match:
        raise ValueError("No JSON object found in LLM output")
    return match.group(0)


def run_sublimit_llm(context: str) -> List[Dict[str, Any]]:
    """Run sublimit extraction without treating JSON braces as prompt variables.

    SYSTEM_SUBLIMIT_PROMPT intentionally contains a JSON schema with many literal
    braces. Passing that text through ChatPromptTemplate makes LangChain parse
    those braces as f-string placeholders. Static SystemMessage/HumanMessage
    objects avoid that formatting error entirely.
    """
    messages = [
        SystemMessage(content=SYSTEM_SUBLIMIT_PROMPT),
        HumanMessage(content=USER_SUBLIMIT_PROMPT.format(context=context)),
    ]

    response = get_llm().invoke(messages)
    raw = response.content if hasattr(response, "content") else str(response)
    print(f"Raw sublimit LLM output:\n{raw}")

    try:
        parsed = json.loads(_extract_json(raw))
        clauses = parsed.get("clauses", [])
        return clauses if isinstance(clauses, list) else []
    except Exception as exc:
        print(f"Failed to parse sublimit LLM output: {exc}")
        return []
