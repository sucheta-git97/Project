import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

from dotenv import load_dotenv

from Chunking.chunker import chunk_azure_documents, chunk_documents
from Chunking.document_loader import process_all_documents
from DocumentIntelligence.azure_document_loader import process_documents_with_azure
from Retriever.context_builder import build_context
from Retriever.indexer import create_faiss_index
from Retriever.sublimit_llm import run_sublimit_llm
from Retriever.sublimit_retriever import retrieve_deductible_chunks
from Utilities.sublimit_normalizer import build_rows, detect_client_name, extract_tiv_fallback

load_dotenv()

FILE_PATH = "./Documents"
OUTPUT_JSON_PATH = "./sublimit_extraction_output.json"
OUTPUT_FOLDER = "./sublimit_extraction_outputs"
AZURE_JSON_OUTPUT_FOLDER = "./azure_layout_json"
CHUNKS_OUTPUT_PATH = "./chunks_output.json"
VECTOR_OUTPUT_FOLDER = "./vector_outputs"
FAISS_OUTPUT_FOLDER = "./faiss_indexes"

EXTRACTION_MODE = os.getenv("EXTRACTION_MODE", "azure").lower().strip()
AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID = os.getenv(
    "AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID", "prebuilt-layout"
)


def safe_filename(value: str) -> str:
    stem = Path(value).stem or "document"
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return stem or "document"


def save_json(data: Any, output_path: str) -> None:
    folder = os.path.dirname(output_path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def group_by_document_id(items: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for item in items:
        grouped[item.get("document_id") or "unknown_document"].append(item)
    return dict(grouped)


def load_and_chunk_documents_by_file() -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:
    if EXTRACTION_MODE == "local":
        print("Running in LOCAL mode.")
        pages = process_all_documents(FILE_PATH)
        if not pages:
            raise ValueError("No PDF/DOCX text found in Documents folder.")
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        all_chunks: List[Dict[str, Any]] = []
        for document_id, document_pages in group_by_document_id(pages).items():
            chunks = chunk_documents(document_pages)
            grouped[document_id] = chunks
            all_chunks.extend(chunks)
        return grouped, all_chunks

    print("Running in AZURE mode: Azure Document Intelligence + hierarchical chunking.")
    analyzed_documents = process_documents_with_azure(
        folder_path=FILE_PATH,
        output_json_folder=AZURE_JSON_OUTPUT_FOLDER,
        model_id=AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID,
    )
    if not analyzed_documents:
        raise ValueError("No documents analyzed. Check Documents folder and Azure credentials.")

    grouped = {}
    all_chunks = []
    for analyzed_document in analyzed_documents:
        document_id = analyzed_document["document_id"]
        chunks = chunk_azure_documents([analyzed_document])
        grouped[document_id] = chunks
        all_chunks.extend(chunks)
    return grouped, all_chunks


def extract_sublimits_for_document(document_id: str, chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not chunks:
        return {"document_name": document_id, "status": "failed", "error": "No chunks generated", "rows": []}

    print(f"\nProcessing: {document_id} ({len(chunks)} chunks)")
    safe_name = safe_filename(document_id)
    vector_store = create_faiss_index(
        chunks,
        faiss_output_folder=os.path.join(FAISS_OUTPUT_FOLDER, safe_name),
        vectors_output_path=os.path.join(VECTOR_OUTPUT_FOLDER, f"{safe_name}_chunk_vectors.jsonl"),
    )

    deductible_docs = retrieve_deductible_chunks(vector_store, k=int(os.getenv("SUBLIMIT_RETRIEVAL_K", "14")))
    context = build_context(deductible_docs)
    clauses = run_sublimit_llm(context)

    tiv = extract_tiv_fallback(chunks)
    client_name = detect_client_name(chunks)
    rows = build_rows(
        clauses=clauses,
        tiv=tiv,
        document_id=document_id,
        client_name=client_name,
    )

    return {
        "document_name": document_id,
        "status": "success",
        "client_rule_profile": client_name,
        "tiv_fallback": tiv,
        "retrieved_chunk_count": len(deductible_docs),
        "raw_clause_count": len(clauses),
        "row_count": len(rows),
        "chunking_summary": {
            "total_chunks": len(chunks),
            "chunk_type_counts": dict(Counter(chunk.get("chunk_type") for chunk in chunks)),
        },
        "rows": rows,
    }


def runner() -> Dict[str, Any]:
    os.makedirs(FILE_PATH, exist_ok=True)
    chunks_by_document, all_chunks = load_and_chunk_documents_by_file()
    if not all_chunks:
        raise ValueError("No chunks generated.")

    save_json(all_chunks, CHUNKS_OUTPUT_PATH)
    documents: List[Dict[str, Any]] = []
    for document_id, chunks in chunks_by_document.items():
        result = extract_sublimits_for_document(document_id, chunks)
        documents.append(result)
        save_json(
            result,
            os.path.join(OUTPUT_FOLDER, f"{safe_filename(document_id)}_sublimit_output.json"),
        )

    final = {
        "total_documents": len(documents),
        "total_rows": sum(item.get("row_count", 0) for item in documents),
        "documents": documents,
    }
    save_json(final, OUTPUT_JSON_PATH)
    print(json.dumps(final, indent=2, ensure_ascii=False))
    print(f"\nSaved combined output to {OUTPUT_JSON_PATH}")
    return final


if __name__ == "__main__":
    try:
        runner()
    except Exception as exc:
        print(f"An error occurred: {exc}")
        raise
