# Insurance Slip Sublimit Deductible Extraction

This project extracts a variable number of sublimit/deductible rows from insurance slips.

## Output fields

- `sublimit_perils`
- `sublimit_area`
- `sublimit_limit_type` (`B`)
- `sublimit_ded_type` (`MI`/`MA`)
- `sublimit_occupancy`
- `sublimit_occ`
- `sublimit_ded_amt1`
- `sublimit_ded_amt2`
- evidence, page number, chunk id, and confidence

## Flow

1. Azure Document Intelligence Layout extraction
2. Hierarchical page/section/table/key-value chunking
3. Per-document FAISS index using Azure OpenAI embeddings
4. Hybrid deductible-clause retrieval
5. One structured Azure OpenAI call to identify all deductible clauses
6. Deterministic peril-code mapping, client overrides, MI/MA logic, nomenclature generation, TIV fallback, and exception row splitting
7. JSON output per document and combined output

## Setup

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env
```

Place PDF/DOCX files in `Documents/`, then run:

```bash
python main.py
```

## Required environment variables

- `AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT`
- `AZURE_DOCUMENT_INTELLIGENCE_KEY`
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_KEY`
- `AZURE_OPENAI_API_VERSION`
- `AZURE_OPENAI_DEPLOYMENT_NAME`
- embedding variables already listed in `.env.example`

Optional:

- `EXTRACTION_MODE=azure`
- `AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID=prebuilt-layout`
- `SUBLIMIT_RETRIEVAL_K=14`

## Configuration

- `Config/peril_mapping.json`: aliases, output codes, and nomenclature prefixes
- `Config/client_overrides.json`: client-specific code exclusions such as removing `PWX` for Fidelis hail

## Important behavior

A scoped exception creates a separate row. Example: AOP USD 100,000 except USD 50,000 for Contractors' Equipment creates a general AOP row and an occupancy-specific exception row.

For `2% subject to a minimum of USD 1,000,000`, Amount 1 is the monetary minimum and Amount 2 is the percentage, with their types retained internally.
