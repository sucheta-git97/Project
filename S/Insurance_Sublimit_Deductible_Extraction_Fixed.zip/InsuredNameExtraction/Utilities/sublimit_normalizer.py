import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

ROOT = Path(__file__).resolve().parents[1]


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


PERIL_MAPPING = load_json(ROOT / "Config" / "peril_mapping.json")
CLIENT_OVERRIDES = load_json(ROOT / "Config" / "client_overrides.json")


def normalize_number(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    text = re.sub(r"[^0-9.\-]", "", text)
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def compact_amount(value: Any, amount_type: str = "CURRENCY") -> str:
    number = normalize_number(value)
    if number is None:
        return "UNK"
    if amount_type.upper() == "PERCENTAGE":
        return f"{number:g}PCT"
    if abs(number) >= 1_000_000_000:
        return f"{number / 1_000_000_000:g}B"
    if abs(number) >= 1_000_000:
        return f"{number / 1_000_000:g}M"
    if abs(number) >= 1_000:
        return f"{number / 1_000:g}K"
    return f"{number:g}"


def canonical_perils(clause: Dict[str, Any], client_name: Optional[str] = None) -> Tuple[List[str], str]:
    normalized = clause.get("normalized_perils") or []
    if isinstance(normalized, str):
        normalized = [normalized]

    source_text = str(clause.get("source_peril_text") or "").lower()
    selected: List[str] = []
    prefixes: List[str] = []

    for key, config in PERIL_MAPPING.items():
        aliases = [str(alias).lower() for alias in config.get("aliases", [])]
        include = key in normalized or any(alias in source_text for alias in aliases)
        if not include:
            continue
        codes = list(config.get("codes", []))
        if client_name:
            client_cfg = CLIENT_OVERRIDES.get(client_name.lower(), {}).get(key, {})
            excluded = set(client_cfg.get("exclude_codes", []))
            codes = [code for code in codes if code not in excluded]
        selected.extend(codes)
        prefixes.append(str(config.get("area_prefix") or key).upper())

    # Preserve mapping order and remove duplicates.
    selected = list(dict.fromkeys(selected))
    prefix = prefixes[0] if len(prefixes) == 1 else "_".join(dict.fromkeys(prefixes))
    return selected, prefix or "OTHER"


def deductible_type(clause: Dict[str, Any]) -> Tuple[str, str]:
    operator = str(clause.get("operator") or "").upper()
    evidence = str(clause.get("evidence") or "").lower()
    if operator == "MINIMUM" or re.search(r"subject to (?:a )?minimum|minimum of|not less than|whichever is greater", evidence):
        return "MI", "explicit_minimum"
    if operator == "MAXIMUM" or re.search(r"subject to (?:a )?maximum|maximum of|not exceeding|capped at|whichever is lower", evidence):
        return "MA", "explicit_maximum"
    return "MI", "business_default"


def generate_area(prefix: str, primary: Dict[str, Any], secondary: Optional[Dict[str, Any]], ded_type: str) -> str:
    parts = [prefix, "DED", compact_amount(primary.get("value"), primary.get("type", "CURRENCY"))]
    if secondary and normalize_number(secondary.get("value")) is not None:
        if ded_type == "MI":
            parts.append("MIN")
        elif ded_type == "MA":
            parts.append("MAX")
        parts.append(compact_amount(secondary.get("value"), secondary.get("type", "CURRENCY")))
    return "_".join(parts)


def detect_client_name(chunks: Iterable[Dict[str, Any]]) -> Optional[str]:
    text = " ".join(str(chunk.get("text") or chunk.get("original_text") or "") for chunk in chunks).lower()
    if "fidelis" in text:
        return "fidelis"
    return None


def extract_tiv_fallback(chunks: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    candidates: List[Tuple[int, float, Dict[str, Any], str]] = []
    money = r"(?:USD|US\s*Dollars?|\$)?\s*([0-9][0-9,]*(?:\.\d+)?)"
    direct_patterns = [
        re.compile(rf"\b(?:TIV|Total\s+Insur(?:able|ed)\s+Value|Total\s+Values?)\b[^\d$]{{0,40}}{money}", re.I),
    ]
    building_pattern = re.compile(rf"\bBuildings?\b[^\d$]{{0,30}}{money}", re.I)
    contents_pattern = re.compile(rf"\bContents?\b[^\d$]{{0,30}}{money}", re.I)

    chunks_list = list(chunks)
    for chunk in chunks_list:
        text = str(chunk.get("original_text") or chunk.get("text") or "")
        for pattern in direct_patterns:
            for match in pattern.finditer(text):
                value = normalize_number(match.group(1))
                if value and value >= 1000:
                    candidates.append((100, value, chunk, match.group(0)))
        b = building_pattern.search(text)
        c = contents_pattern.search(text)
        if b and c:
            bv = normalize_number(b.group(1))
            cv = normalize_number(c.group(1))
            if bv and cv:
                candidates.append((80, bv + cv, chunk, f"{b.group(0)}; {c.group(0)}"))

    if not candidates:
        return {"value": None, "source": None, "evidence": None, "page_number": None, "chunk_id": None, "confidence": 0.0}
    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
    score, value, chunk, evidence = candidates[0]
    return {
        "value": int(value) if float(value).is_integer() else value,
        "source": "TIV_FALLBACK",
        "evidence": evidence,
        "page_number": chunk.get("page"),
        "chunk_id": chunk.get("chunk_id"),
        "confidence": 0.85 if score == 100 else 0.78,
    }


def _amount_payload(payload: Optional[Dict[str, Any]]) -> Tuple[Optional[Any], Optional[str], Optional[str]]:
    if not payload:
        return None, None, None
    number = normalize_number(payload.get("value"))
    value: Optional[Any] = None
    if number is not None:
        value = int(number) if number.is_integer() else number
    return value, payload.get("type"), payload.get("currency")


def build_rows(
    clauses: List[Dict[str, Any]],
    tiv: Dict[str, Any],
    document_id: str,
    client_name: Optional[str] = None,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for clause in clauses:
        codes, prefix = canonical_perils(clause, client_name=client_name)
        if not codes:
            continue
        primary = clause.get("primary_amount") or {}
        secondary = clause.get("secondary_amount")
        p_value, p_type, p_currency = _amount_payload(primary)
        s_value, s_type, s_currency = _amount_payload(secondary)
        if p_value is None:
            continue
        ded_type, ded_type_source = deductible_type(clause)
        explicit_occ = clause.get("explicit_occurrence_limit") or {}
        occ_value = normalize_number(explicit_occ.get("value"))
        occ_source = "EXPLICIT" if occ_value is not None else tiv.get("source")
        if occ_value is None:
            occ_value = normalize_number(tiv.get("value"))
        occ_out = int(occ_value) if occ_value is not None and occ_value.is_integer() else occ_value

        base_row = {
            "document_name": document_id,
            "sublimit_perils": "+".join(codes),
            "sublimit_area": generate_area(prefix, primary, secondary, ded_type),
            "sublimit_limit_type": "B",
            "sublimit_ded_type": ded_type,
            "sublimit_ded_type_source": ded_type_source,
            "sublimit_occupancy": None,
            "sublimit_occ": occ_out,
            "sublimit_occ_source": occ_source,
            "sublimit_ded_amt1": p_value,
            "sublimit_ded_amt1_type": p_type,
            "sublimit_ded_amt1_currency": p_currency,
            "sublimit_ded_amt2": s_value,
            "sublimit_ded_amt2_type": s_type,
            "sublimit_ded_amt2_currency": s_currency,
            "scope": clause.get("scope"),
            "evidence": clause.get("evidence"),
            "page_number": clause.get("page_number"),
            "chunk_id": clause.get("chunk_id"),
            "confidence": float(clause.get("confidence") or 0.0),
        }
        rows.append(base_row)

        # A scoped exception is represented as a separate row because the amount applies
        # to a different occupancy/property type, not as a second component of one formula.
        exception = clause.get("exception_amount")
        occupancy = clause.get("occupancy")
        ex_value, ex_type, ex_currency = _amount_payload(exception)
        if occupancy and ex_value is not None:
            exception_row = dict(base_row)
            exception_row.update({
                "sublimit_area": f"{prefix}_DED_{compact_amount(ex_value, ex_type or 'CURRENCY')}_EXCEPTION",
                "sublimit_occupancy": occupancy,
                "sublimit_ded_amt1": ex_value,
                "sublimit_ded_amt1_type": ex_type,
                "sublimit_ded_amt1_currency": ex_currency,
                "sublimit_ded_amt2": None,
                "sublimit_ded_amt2_type": None,
                "sublimit_ded_amt2_currency": None,
            })
            rows.append(exception_row)

    for index, row in enumerate(rows, start=1):
        row["row_id"] = index
    return rows
