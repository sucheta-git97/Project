# PostgreSQL Setup Guide

This project stores one row for each processed document in the table
`insurance_extractions`.

`document_name` is the unique key. When the same document name is processed
again, the existing row is updated instead of creating a duplicate.

## 1. Install PostgreSQL

Install PostgreSQL and pgAdmin. During installation, remember the password
chosen for the default `postgres` user. The normal local port is `5432`.

## 2. Create the database

Open pgAdmin, connect to the local PostgreSQL server, open Query Tool, and run:

```sql
CREATE DATABASE insurance_extraction_db;
```

After creating it, connect Query Tool to `insurance_extraction_db`.

The Python application creates the table automatically. You can also create it
manually by running:

```text
sql/create_insurance_extractions.sql
```

## 3. Configure `.env`

Copy `.env.example` to `.env`, keep the existing Azure settings, and fill these
PostgreSQL settings:

```env
POSTGRES_ENABLED=true
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=insurance_extraction_db
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_actual_postgres_password
POSTGRES_SSLMODE=prefer
POSTGRES_CONNECT_TIMEOUT=10
```

Set `POSTGRES_ENABLED=false` when you temporarily want extraction without
writing to PostgreSQL.

## 4. Install the dependency

```bash
pip install -r requirements.txt
```

This installs Psycopg 3 using the binary package.

## 5. Test PostgreSQL before running extraction

Run this command from the project root:

```bash
python -m Database.test_connection
```

Expected output includes:

```text
PostgreSQL connection successful.
Database: insurance_extraction_db
User: postgres
```

## 6. Run extraction

Place documents inside `Documents/` and run:

```bash
python main.py
```

At startup, the application creates `insurance_extractions` if it does not
already exist. After each successful document extraction, it runs an upsert:

- new `document_name`: inserts a row;
- existing `document_name`: updates the existing row;
- database `id`: remains the same after an update;
- `updated_at`: changes to the latest database write time.

## 7. Table columns

For each field, the table stores its value, evidence, and confidence:

- `insured_name`, `insured_name_evidence`, `insured_name_confidence`
- `inception_date`, `inception_date_evidence`, `inception_date_confidence`
- `expiration_date`, `expiration_date_evidence`, `expiration_date_confidence`
- `currency`, `currency_evidence`, `currency_confidence`
- `limit_one`, `limit_one_evidence`, `limit_one_confidence`
- `limit_two`, `limit_two_evidence`, `limit_two_confidence`
- `sub_limit_limit_type`, its evidence and confidence
- `perils`, its evidence and confidence
- `layer_perils`, its evidence and confidence

The table also contains `id`, `document_name`, `extraction_status`,
`created_at`, and `updated_at`.

Values are stored as text to preserve exactly what the extraction pipeline
returns. Confidence columns are numeric values constrained to the range 0 to 1.

## 8. View saved records

Run in pgAdmin Query Tool:

```sql
SELECT *
FROM insurance_extractions
ORDER BY updated_at DESC;
```

A simpler view:

```sql
SELECT
    document_name,
    insured_name,
    inception_date,
    expiration_date,
    currency,
    limit_one,
    limit_two,
    updated_at
FROM insurance_extractions
ORDER BY updated_at DESC;
```

Find low-confidence insured names:

```sql
SELECT
    document_name,
    insured_name,
    insured_name_evidence,
    insured_name_confidence
FROM insurance_extractions
WHERE insured_name_confidence < 0.80
ORDER BY insured_name_confidence;
```

## 9. Rerun behavior

The SQL uses:

```sql
ON CONFLICT (document_name) DO UPDATE
```

For example, processing `sample_slip.pdf` twice produces only one database row.
The second run replaces its field values, evidence, confidence, status, and
`updated_at` timestamp.

The match uses the exact document name supplied by the current loader. For now,
this intentionally follows the agreed document-name-only design.

## 10. Common errors

### Connection refused

PostgreSQL is not running, the host/port is incorrect, or a firewall is blocking
it. Confirm the PostgreSQL Windows service is running and port is `5432`.

### Password authentication failed

The value in `POSTGRES_PASSWORD` does not match the password for
`POSTGRES_USER`.

### Database does not exist

Create `insurance_extraction_db` first. The application creates the table, but
it does not create the database itself.

### Psycopg is not installed

Run:

```bash
pip install "psycopg[binary]>=3.2,<4"
```
