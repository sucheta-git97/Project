"""Convert extraction JSON into a single PostgreSQL row and upsert it."""

from typing import Any, Dict, Optional

from Database.connection import get_postgres_connection


FIELD_COLUMN_MAPPING = {
    "Insured Name": "insured_name",
    "Inception Date": "inception_date",
    "Expiration Date": "expiration_date",
    "Currency": "currency",
    "Limit One": "limit_one",
    "Limit Two": "limit_two",
    "Sub Limit Limit Type": "sub_limit_limit_type",
    "Perils": "perils",
    "LayerPerils": "layer_perils",
}


def _normalize_confidence(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return None
    return max(0.0, min(1.0, confidence))


def _normalize_text_value(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, (dict, list, tuple)):
        import json

        return json.dumps(value, ensure_ascii=False)
    text = str(value).strip()
    return text or None


def prepare_database_record(document_output: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten one document's field output into SQL column parameters."""
    document_name = document_output.get("document_id")
    if not document_name:
        raise ValueError("Cannot save extraction because document_id is missing.")

    fields = document_output.get("fields") or {}
    record: Dict[str, Any] = {
        "document_name": str(document_name),
        "extraction_status": str(document_output.get("status") or "unknown"),
    }

    for field_name, column_name in FIELD_COLUMN_MAPPING.items():
        field_result = fields.get(field_name) or {}
        if not isinstance(field_result, dict):
            field_result = {}

        record[column_name] = _normalize_text_value(field_result.get("Value"))
        record[f"{column_name}_evidence"] = _normalize_text_value(
            field_result.get("Evidence")
        )
        record[f"{column_name}_confidence"] = _normalize_confidence(
            field_result.get("Confidence")
        )

    return record


UPSERT_EXTRACTION_SQL = """
INSERT INTO insurance_extractions (
    document_name,
    insured_name, insured_name_evidence, insured_name_confidence,
    inception_date, inception_date_evidence, inception_date_confidence,
    expiration_date, expiration_date_evidence, expiration_date_confidence,
    currency, currency_evidence, currency_confidence,
    limit_one, limit_one_evidence, limit_one_confidence,
    limit_two, limit_two_evidence, limit_two_confidence,
    sub_limit_limit_type, sub_limit_limit_type_evidence, sub_limit_limit_type_confidence,
    perils, perils_evidence, perils_confidence,
    layer_perils, layer_perils_evidence, layer_perils_confidence,
    extraction_status
)
VALUES (
    %(document_name)s,
    %(insured_name)s, %(insured_name_evidence)s, %(insured_name_confidence)s,
    %(inception_date)s, %(inception_date_evidence)s, %(inception_date_confidence)s,
    %(expiration_date)s, %(expiration_date_evidence)s, %(expiration_date_confidence)s,
    %(currency)s, %(currency_evidence)s, %(currency_confidence)s,
    %(limit_one)s, %(limit_one_evidence)s, %(limit_one_confidence)s,
    %(limit_two)s, %(limit_two_evidence)s, %(limit_two_confidence)s,
    %(sub_limit_limit_type)s, %(sub_limit_limit_type_evidence)s,
        %(sub_limit_limit_type_confidence)s,
    %(perils)s, %(perils_evidence)s, %(perils_confidence)s,
    %(layer_perils)s, %(layer_perils_evidence)s, %(layer_perils_confidence)s,
    %(extraction_status)s
)
ON CONFLICT (document_name)
DO UPDATE SET
    insured_name = EXCLUDED.insured_name,
    insured_name_evidence = EXCLUDED.insured_name_evidence,
    insured_name_confidence = EXCLUDED.insured_name_confidence,
    inception_date = EXCLUDED.inception_date,
    inception_date_evidence = EXCLUDED.inception_date_evidence,
    inception_date_confidence = EXCLUDED.inception_date_confidence,
    expiration_date = EXCLUDED.expiration_date,
    expiration_date_evidence = EXCLUDED.expiration_date_evidence,
    expiration_date_confidence = EXCLUDED.expiration_date_confidence,
    currency = EXCLUDED.currency,
    currency_evidence = EXCLUDED.currency_evidence,
    currency_confidence = EXCLUDED.currency_confidence,
    limit_one = EXCLUDED.limit_one,
    limit_one_evidence = EXCLUDED.limit_one_evidence,
    limit_one_confidence = EXCLUDED.limit_one_confidence,
    limit_two = EXCLUDED.limit_two,
    limit_two_evidence = EXCLUDED.limit_two_evidence,
    limit_two_confidence = EXCLUDED.limit_two_confidence,
    sub_limit_limit_type = EXCLUDED.sub_limit_limit_type,
    sub_limit_limit_type_evidence = EXCLUDED.sub_limit_limit_type_evidence,
    sub_limit_limit_type_confidence = EXCLUDED.sub_limit_limit_type_confidence,
    perils = EXCLUDED.perils,
    perils_evidence = EXCLUDED.perils_evidence,
    perils_confidence = EXCLUDED.perils_confidence,
    layer_perils = EXCLUDED.layer_perils,
    layer_perils_evidence = EXCLUDED.layer_perils_evidence,
    layer_perils_confidence = EXCLUDED.layer_perils_confidence,
    extraction_status = EXCLUDED.extraction_status,
    updated_at = CURRENT_TIMESTAMP
RETURNING id;
"""


def save_document_extraction(document_output: Dict[str, Any]) -> int:
    """Insert a new document row or update the existing row by document name."""
    record = prepare_database_record(document_output)
    with get_postgres_connection() as connection:
        cursor = connection.execute(UPSERT_EXTRACTION_SQL, record)
        row = cursor.fetchone()

    if not row:
        raise RuntimeError("PostgreSQL did not return the saved extraction ID.")
    return int(row[0])
