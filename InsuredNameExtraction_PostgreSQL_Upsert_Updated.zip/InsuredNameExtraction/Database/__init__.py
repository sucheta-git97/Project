"""PostgreSQL persistence package for extraction outputs."""
