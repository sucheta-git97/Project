"""Standalone PostgreSQL connection test."""

from Database.connection import get_postgres_connection
from Database.schema import initialize_database


def main() -> None:
    initialize_database()
    with get_postgres_connection() as connection:
        row = connection.execute(
            "SELECT current_database(), current_user, CURRENT_TIMESTAMP;"
        ).fetchone()

    print("PostgreSQL connection successful.")
    print(f"Database: {row[0]}")
    print(f"User: {row[1]}")
    print(f"Database time: {row[2]}")


if __name__ == "__main__":
    main()
