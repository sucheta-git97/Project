"""Database schema initialization."""

from Database.connection import get_postgres_connection


CREATE_EXTRACTIONS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS insurance_extractions (
    id BIGSERIAL PRIMARY KEY,
    document_name TEXT NOT NULL UNIQUE,

    insured_name TEXT,
    insured_name_evidence TEXT,
    insured_name_confidence DOUBLE PRECISION,

    inception_date TEXT,
    inception_date_evidence TEXT,
    inception_date_confidence DOUBLE PRECISION,

    expiration_date TEXT,
    expiration_date_evidence TEXT,
    expiration_date_confidence DOUBLE PRECISION,

    currency TEXT,
    currency_evidence TEXT,
    currency_confidence DOUBLE PRECISION,

    limit_one TEXT,
    limit_one_evidence TEXT,
    limit_one_confidence DOUBLE PRECISION,

    limit_two TEXT,
    limit_two_evidence TEXT,
    limit_two_confidence DOUBLE PRECISION,

    sub_limit_limit_type TEXT,
    sub_limit_limit_type_evidence TEXT,
    sub_limit_limit_type_confidence DOUBLE PRECISION,

    perils TEXT,
    perils_evidence TEXT,
    perils_confidence DOUBLE PRECISION,

    layer_perils TEXT,
    layer_perils_evidence TEXT,
    layer_perils_confidence DOUBLE PRECISION,

    extraction_status TEXT NOT NULL DEFAULT 'success',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT insured_name_confidence_range CHECK (
        insured_name_confidence IS NULL OR insured_name_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT inception_date_confidence_range CHECK (
        inception_date_confidence IS NULL OR inception_date_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT expiration_date_confidence_range CHECK (
        expiration_date_confidence IS NULL OR expiration_date_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT currency_confidence_range CHECK (
        currency_confidence IS NULL OR currency_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT limit_one_confidence_range CHECK (
        limit_one_confidence IS NULL OR limit_one_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT limit_two_confidence_range CHECK (
        limit_two_confidence IS NULL OR limit_two_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT sub_limit_limit_type_confidence_range CHECK (
        sub_limit_limit_type_confidence IS NULL
        OR sub_limit_limit_type_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT perils_confidence_range CHECK (
        perils_confidence IS NULL OR perils_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT layer_perils_confidence_range CHECK (
        layer_perils_confidence IS NULL OR layer_perils_confidence BETWEEN 0 AND 1
    )
);
"""


def initialize_database() -> None:
    """Create the extraction table when it does not already exist."""
    with get_postgres_connection() as connection:
        connection.execute(CREATE_EXTRACTIONS_TABLE_SQL)
