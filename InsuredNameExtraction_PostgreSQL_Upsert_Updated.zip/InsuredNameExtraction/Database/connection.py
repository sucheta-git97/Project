"""PostgreSQL connection helpers."""

import os
from typing import Any

from dotenv import load_dotenv

load_dotenv()


def is_postgres_enabled() -> bool:
    """Return True when PostgreSQL persistence is enabled in the environment."""
    return os.getenv("POSTGRES_ENABLED", "false").strip().lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }


def get_postgres_connection() -> Any:
    """Create a Psycopg 3 connection using environment variables."""
    try:
        import psycopg
    except ImportError as exc:
        raise RuntimeError(
            "The PostgreSQL driver is not installed. Run: pip install psycopg[binary]"
        ) from exc

    required = {
        "POSTGRES_HOST": os.getenv("POSTGRES_HOST"),
        "POSTGRES_DB": os.getenv("POSTGRES_DB"),
        "POSTGRES_USER": os.getenv("POSTGRES_USER"),
        "POSTGRES_PASSWORD": os.getenv("POSTGRES_PASSWORD"),
    }
    missing = [name for name, value in required.items() if not value]
    if missing:
        raise ValueError(
            "PostgreSQL is enabled, but these environment variables are missing: "
            + ", ".join(missing)
        )

    return psycopg.connect(
        host=required["POSTGRES_HOST"],
        port=int(os.getenv("POSTGRES_PORT", "5432")),
        dbname=required["POSTGRES_DB"],
        user=required["POSTGRES_USER"],
        password=required["POSTGRES_PASSWORD"],
        sslmode=os.getenv("POSTGRES_SSLMODE", "prefer"),
        connect_timeout=int(os.getenv("POSTGRES_CONNECT_TIMEOUT", "10")),
    )
