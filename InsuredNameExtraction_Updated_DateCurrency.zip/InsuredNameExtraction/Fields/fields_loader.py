import json
from typing import Any, Dict, List


def load_fields_from_json(file_path: str) -> List[Dict[str, Any]]:
    """Load extraction field definitions from a JSON configuration file."""
    with open(file_path, "r", encoding="utf-8") as file:
        data = json.load(file)

    return data.get("fields", [])
