import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient

load_dotenv()

AZURE_DOC_INTEL_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
AZURE_DOC_INTEL_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
AZURE_DOC_INTEL_MODEL_ID = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID", "prebuilt-document")

SUPPORTED_EXTENSIONS = {
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
    ".bmp",
    ".docx",
}


def get_document_intelligence_client() -> DocumentIntelligenceClient:
    """Create Azure Document Intelligence client."""
    missing = [
        name for name, value in {
            "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT": AZURE_DOC_INTEL_ENDPOINT,
            "AZURE_DOCUMENT_INTELLIGENCE_KEY": AZURE_DOC_INTEL_KEY,
        }.items()
        if not value
    ]

    if missing:
        raise ValueError(f"Missing environment variables: {', '.join(missing)}")

    return DocumentIntelligenceClient(
        endpoint=AZURE_DOC_INTEL_ENDPOINT,
        credential=AzureKeyCredential(AZURE_DOC_INTEL_KEY),
    )


def analyze_document_with_azure(file_path: str, model_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Analyze one document using Azure Document Intelligence.

    Recommended model_id values:
    - prebuilt-document: layout + key-value pairs where available
    - prebuilt-layout: layout, pages, paragraphs, tables, OCR text
    """
    model_id = model_id or AZURE_DOC_INTEL_MODEL_ID
    client = get_document_intelligence_client()

    with open(file_path, "rb") as file:
        poller = client.begin_analyze_document(
            model_id=model_id,
            body=file,
            content_type="application/octet-stream",
        )

    result = poller.result()
    return result.as_dict()


def save_json(data: Dict[str, Any], output_path: str) -> None:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, ensure_ascii=False)


def process_documents_with_azure(
    folder_path: str,
    output_json_folder: str = "./azure_layout_json",
    model_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Process all supported files in a folder through Azure Document Intelligence.

    Returns:
        List of dictionaries containing document_id, source path, raw JSON path,
        and Azure's extracted JSON result.
    """
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"Documents folder not found: {folder_path}")

    os.makedirs(output_json_folder, exist_ok=True)
    analyzed_documents: List[Dict[str, Any]] = []

    for file_path in sorted(folder.iterdir()):
        if not file_path.is_file():
            continue

        ext = file_path.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            print(f"Skipping unsupported file: {file_path.name}")
            continue

        print(f"Analyzing with Azure Document Intelligence: {file_path.name}")

        try:
            result_json = analyze_document_with_azure(str(file_path), model_id=model_id)

            output_json_path = os.path.join(
                output_json_folder,
                f"{file_path.stem}_azure_output.json",
            )
            save_json(result_json, output_json_path)

            analyzed_documents.append({
                "document_id": file_path.name,
                "source": str(file_path),
                "azure_json_path": output_json_path,
                "azure_result": result_json,
            })

            print(f"Azure JSON saved to: {output_json_path}")

        except Exception as exc:
            print(f"Failed to analyze {file_path.name}: {exc}")

    return analyzed_documents
