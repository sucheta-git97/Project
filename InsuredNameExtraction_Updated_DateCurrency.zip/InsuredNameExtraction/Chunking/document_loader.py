import os
from typing import Any, Dict, List

import fitz  # PyMuPDF
from docx import Document


SUPPORTED_EXTENSIONS = [".pdf", ".docx", ".doc"]


def load_pdf(file_path: str) -> List[Dict[str, Any]]:
    """Load text from each page of a PDF file."""
    doc = fitz.open(file_path)
    pages = []

    for page_number, page in enumerate(doc, start=1):
        text = page.get_text("text")

        if text and text.strip():
            pages.append({
                "document_id": os.path.basename(file_path),
                "source": file_path,
                "page": page_number,
                "text": text.strip()
            })

    return pages


def load_docx(file_path: str) -> List[Dict[str, Any]]:
    """Load text from a DOCX file."""
    doc = Document(file_path)
    text = "\n".join([para.text for para in doc.paragraphs if para.text.strip()])

    if not text.strip():
        return []

    return [{
        "document_id": os.path.basename(file_path),
        "source": file_path,
        "page": 1,
        "text": text.strip()
    }]


def load_document(file_path: str) -> List[Dict[str, Any]]:
    """Load supported document types."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        return load_pdf(file_path)

    if ext in [".docx", ".doc"]:
        return load_docx(file_path)

    raise ValueError(f"Unsupported file type: {ext}")


def process_all_documents(folder_path: str) -> List[Dict[str, Any]]:
    """Process all supported documents inside a folder."""
    all_pages = []

    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"Documents folder not found: {folder_path}")

    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)

        if not os.path.isfile(file_path):
            continue

        ext = os.path.splitext(filename)[1].lower()

        if ext not in SUPPORTED_EXTENSIONS:
            continue

        print(f"Loading document: {filename}")

        try:
            pages = load_document(file_path)
            all_pages.extend(pages)
        except Exception as e:
            print(f"Failed to process {filename}: {e}")

    return all_pages
