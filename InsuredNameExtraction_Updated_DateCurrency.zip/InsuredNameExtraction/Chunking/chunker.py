import re
import uuid
from typing import Any, Dict, List, Optional

from langchain_text_splitters import RecursiveCharacterTextSplitter


INSURANCE_SECTION_KEYWORDS = [
    "insured",
    "named insured",
    "first named insured",
    "primary named insured",
    "applicant",
    "account information",
    "policy information",
    "submission information",
    "organization",
    "entity",
    "client name",
    "account name",
    "org chart",
]


def clean_text(text: Optional[str]) -> str:
    if not text:
        return ""
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def page_parent_id(document_id: str, page: int) -> str:
    return f"{document_id}::page::{page}"


def make_chunk(
    document_id: str,
    source: str,
    page: int,
    text: str,
    chunk_type: str,
    parent_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    chunk_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create one normalized chunk object."""
    return {
        "chunk_id": chunk_id or str(uuid.uuid4()),
        "parent_id": parent_id,
        "document_id": document_id,
        "source": source,
        "page": page,
        "chunk_type": chunk_type,
        "text": clean_text(text),
        "metadata": metadata or {},
    }


def get_page_from_bounding_regions(item: Dict[str, Any], default: int = 1) -> int:
    regions = item.get("boundingRegions") or item.get("bounding_regions") or []
    if regions:
        return int(regions[0].get("pageNumber") or regions[0].get("page_number") or default)
    return default


def extract_page_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    document_id = doc["document_id"]
    source = doc["source"]
    result = doc["azure_result"]

    for page in result.get("pages", []):
        page_number = int(page.get("pageNumber") or page.get("page_number") or 1)
        lines = [line.get("content", "") for line in page.get("lines", []) if line.get("content")]
        page_text = clean_text("\n".join(lines))

        if not page_text:
            continue

        chunks.append(
            make_chunk(
                document_id=document_id,
                source=source,
                page=page_number,
                text=page_text,
                chunk_type="page",
                parent_id=None,
                chunk_id=page_parent_id(document_id, page_number),
                metadata={
                    "width": page.get("width"),
                    "height": page.get("height"),
                    "unit": page.get("unit"),
                },
            )
        )

    return chunks


def extract_paragraph_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    document_id = doc["document_id"]
    source = doc["source"]
    result = doc["azure_result"]

    for idx, paragraph in enumerate(result.get("paragraphs", []), start=1):
        text = clean_text(paragraph.get("content", ""))
        if not text:
            continue

        page_number = get_page_from_bounding_regions(paragraph)
        chunks.append(
            make_chunk(
                document_id=document_id,
                source=source,
                page=page_number,
                text=text,
                chunk_type="paragraph",
                parent_id=page_parent_id(document_id, page_number),
                metadata={
                    "paragraph_index": idx,
                    "role": paragraph.get("role"),
                    "bounding_regions": paragraph.get("boundingRegions", []),
                    "spans": paragraph.get("spans", []),
                },
            )
        )

    return chunks


def extract_key_value_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    document_id = doc["document_id"]
    source = doc["source"]
    result = doc["azure_result"]

    for idx, kv in enumerate(result.get("keyValuePairs", []), start=1):
        key_obj = kv.get("key") or {}
        value_obj = kv.get("value") or {}
        key = clean_text(key_obj.get("content", ""))
        value = clean_text(value_obj.get("content", ""))

        if not key and not value:
            continue

        text = f"{key}: {value}" if key and value else key or value
        page_number = get_page_from_bounding_regions(key_obj or value_obj)

        chunks.append(
            make_chunk(
                document_id=document_id,
                source=source,
                page=page_number,
                text=text,
                chunk_type="key_value",
                parent_id=page_parent_id(document_id, page_number),
                metadata={
                    "key_value_index": idx,
                    "key": key,
                    "value": value,
                    "confidence": kv.get("confidence"),
                    "key_bounding_regions": key_obj.get("boundingRegions", []),
                    "value_bounding_regions": value_obj.get("boundingRegions", []),
                },
            )
        )

    return chunks


def extract_table_chunks(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Create table-level and row-level chunks from Azure table cells."""
    chunks: List[Dict[str, Any]] = []
    document_id = doc["document_id"]
    source = doc["source"]
    result = doc["azure_result"]

    for table_index, table in enumerate(result.get("tables", []), start=1):
        cells = table.get("cells", [])
        if not cells:
            continue

        page_number = get_page_from_bounding_regions(table)
        rows: Dict[int, Dict[int, str]] = {}

        for cell in cells:
            row_index = int(cell.get("rowIndex", 0))
            col_index = int(cell.get("columnIndex", 0))
            rows.setdefault(row_index, {})[col_index] = clean_text(cell.get("content", ""))

        table_lines: List[str] = []
        for row_index in sorted(rows.keys()):
            row = rows[row_index]
            row_values = [row[col] for col in sorted(row.keys())]
            line = " | ".join(row_values).strip()
            if line:
                table_lines.append(line)

        table_text = clean_text("\n".join(table_lines))
        if not table_text:
            continue

        table_chunk_id = f"{document_id}::page::{page_number}::table::{table_index}"

        chunks.append(
            make_chunk(
                document_id=document_id,
                source=source,
                page=page_number,
                text=table_text,
                chunk_type="table",
                parent_id=page_parent_id(document_id, page_number),
                chunk_id=table_chunk_id,
                metadata={
                    "table_index": table_index,
                    "row_count": table.get("rowCount"),
                    "column_count": table.get("columnCount"),
                    "bounding_regions": table.get("boundingRegions", []),
                },
            )
        )

        # Row-level chunks are useful when a field appears inside one table row.
        for row_index in sorted(rows.keys()):
            row = rows[row_index]
            row_values = [row[col] for col in sorted(row.keys())]
            row_text = clean_text(" | ".join(row_values))
            if not row_text:
                continue

            chunks.append(
                make_chunk(
                    document_id=document_id,
                    source=source,
                    page=page_number,
                    text=row_text,
                    chunk_type="table_row",
                    parent_id=table_chunk_id,
                    metadata={
                        "table_index": table_index,
                        "row_index": row_index,
                    },
                )
            )

    return chunks


def extract_section_candidate_chunks(base_chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Create extra insurance-focused section candidate chunks.

    This is a lightweight section strategy: it marks high-value chunks containing
    phrases such as Named Insured, Applicant, Account Name, etc.
    """
    section_chunks: List[Dict[str, Any]] = []

    for chunk in base_chunks:
        text_lower = chunk["text"].lower()
        matched_keywords = [kw for kw in INSURANCE_SECTION_KEYWORDS if kw in text_lower]
        if not matched_keywords:
            continue

        section_chunks.append(
            make_chunk(
                document_id=chunk["document_id"],
                source=chunk["source"],
                page=chunk["page"],
                text=chunk["text"],
                chunk_type="section_candidate",
                parent_id=chunk.get("parent_id"),
                metadata={
                    "source_chunk_id": chunk["chunk_id"],
                    "source_chunk_type": chunk["chunk_type"],
                    "matched_keywords": matched_keywords,
                },
            )
        )

    return section_chunks


def split_large_chunks(
    chunks: List[Dict[str, Any]],
    max_chars: int = 1600,
    overlap: int = 200,
) -> List[Dict[str, Any]]:
    """
    Keep small structured chunks as-is, but split very large page/table chunks.
    This avoids passing very long page text into embedding or LLM retrieval.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=max_chars,
        chunk_overlap=overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    output: List[Dict[str, Any]] = []

    for chunk in chunks:
        text = chunk.get("text", "")
        if len(text) <= max_chars or chunk["chunk_type"] in {"key_value", "paragraph", "table_row"}:
            output.append(chunk)
            continue

        splits = splitter.split_text(text)
        for idx, split in enumerate(splits, start=1):
            child = dict(chunk)
            child["chunk_id"] = str(uuid.uuid4())
            child["parent_id"] = chunk["chunk_id"]
            child["chunk_type"] = f"{chunk['chunk_type']}_split"
            child["text"] = clean_text(split)
            child["metadata"] = dict(chunk.get("metadata", {}))
            child["metadata"].update({
                "split_index": idx,
                "source_chunk_id": chunk["chunk_id"],
                "source_chunk_type": chunk["chunk_type"],
            })
            output.append(child)

    return output


def chunk_azure_documents(analyzed_documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Create mixed chunks from Azure Document Intelligence JSON output."""
    all_chunks: List[Dict[str, Any]] = []

    for doc in analyzed_documents:
        page_chunks = extract_page_chunks(doc)
        paragraph_chunks = extract_paragraph_chunks(doc)
        key_value_chunks = extract_key_value_chunks(doc)
        table_chunks = extract_table_chunks(doc)

        base_chunks = page_chunks + paragraph_chunks + key_value_chunks + table_chunks
        section_chunks = extract_section_candidate_chunks(base_chunks)
        mixed_chunks = split_large_chunks(base_chunks + section_chunks)

        all_chunks.extend(mixed_chunks)

        print(
            f"{doc['document_id']} chunks: "
            f"pages={len(page_chunks)}, paragraphs={len(paragraph_chunks)}, "
            f"key_values={len(key_value_chunks)}, tables/table_rows={len(table_chunks)}, "
            f"sections={len(section_chunks)}"
        )

    print(f"Total mixed chunks created: {len(all_chunks)}")
    return all_chunks


# Kept for backward compatibility with the older plain-text loader.
def chunk_documents(
    pages: List[Dict[str, Any]],
    chunk_size: int = 1000,
    chunk_overlap: int = 150,
) -> List[Dict[str, Any]]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", " ", ""],
    )

    chunks: List[Dict[str, Any]] = []
    for page in pages:
        page_text = page.get("text", "")
        if not page_text.strip():
            continue

        for split in splitter.split_text(page_text):
            chunks.append(
                make_chunk(
                    document_id=page["document_id"],
                    source=page["source"],
                    page=page["page"],
                    text=split,
                    chunk_type="fixed_text",
                    parent_id=page_parent_id(page["document_id"], page["page"]),
                )
            )

    print(f"Total fixed text chunks created: {len(chunks)}")
    return chunks
