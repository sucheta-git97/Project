from typing import Any, List


def build_context(chunks: List[Any]) -> str:
    """Build an LLM-ready context string from retrieved chunks."""
    context_parts = []

    for chunk in chunks:
        metadata = chunk.metadata
        extra_metadata = metadata.get("extra_metadata") or {}

        context_parts.append(
            f"""
Chunk ID: {metadata.get("chunk_id")}
Parent ID: {metadata.get("parent_id")}
Chunk Type: {metadata.get("chunk_type")}
Document: {metadata.get("document_id")}
Page: {metadata.get("page")}
Extra Metadata: {extra_metadata}

Body:
{chunk.page_content}

------------------------------
""".strip()
        )

    return "\n\n".join(context_parts).strip()
