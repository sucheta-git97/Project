import os
from typing import Any, Dict, List

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings

load_dotenv()

HF_TOKEN = os.getenv("HUGGING_FACE_TOKEN")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "BAAI/bge-base-en")


def create_faiss_index(chunks: List[Dict[str, Any]]) -> FAISS:
    """Create one FAISS vector index for all mixed document chunks."""
    if not chunks:
        raise ValueError("No chunks available to index.")

    embedding_model = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL_NAME,
        model_kwargs={
            "device": "cpu",
            "token": HF_TOKEN,
        },
        encode_kwargs={
            "normalize_embeddings": True,
        },
    )

    documents: List[Document] = []

    for chunk in chunks:
        text = chunk.get("text", "")
        if not text.strip():
            continue

        documents.append(
            Document(
                page_content=text,
                metadata={
                    "chunk_id": chunk["chunk_id"],
                    "parent_id": chunk.get("parent_id"),
                    "document_id": chunk["document_id"],
                    "source": chunk["source"],
                    "page": chunk["page"],
                    "chunk_type": chunk.get("chunk_type"),
                    "extra_metadata": chunk.get("metadata", {}),
                },
            )
        )

    if not documents:
        raise ValueError("All chunks were empty. Nothing to index.")

    vector_store = FAISS.from_documents(documents, embedding_model)
    print(f"FAISS index created successfully with {len(documents)} chunks.")
    return vector_store
