import re
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

try:
    from dateutil.relativedelta import relativedelta
except Exception:  # pragma: no cover
    relativedelta = None


MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

CURRENCY_PATTERNS = [
    (r"\bUSD\b|\bUS\s*Dollars?\b|\bUnited\s+States\s+Dollars?\b|\$", "USD"),
    (r"\bGBP\b|\bPounds?\b|\bSterling\b|£", "GBP"),
    (r"\bEUR\b|\bEuros?\b|€", "EUR"),
    (r"\bCAD\b|\bCanadian\s+Dollars?\b", "CAD"),
    (r"\bAUD\b|\bAustralian\s+Dollars?\b", "AUD"),
    (r"\bINR\b|\bIndian\s+Rupees?\b|₹", "INR"),
]


def _strip_ordinal(day_text: str) -> str:
    return re.sub(r"(?<=\d)(st|nd|rd|th)\b", "", day_text, flags=re.IGNORECASE)


def _format_date(year: int, month: int, day: int) -> Optional[str]:
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return None


def normalize_date_value(value: Any) -> Any:
    """Normalize common insurance date strings to YYYY-MM-DD when possible."""
    if value is None or not isinstance(value, str):
        return value

    text = _strip_ordinal(value.strip())
    if not text:
        return value

    # Already normalized.
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text

    # 01-August-2025 / 01 August 2025 / August 24, 2026
    patterns = [
        r"\b(?P<day>\d{1,2})[-\s/]+(?P<month>[A-Za-z]{3,9})[-,\s/]+(?P<year>\d{4})\b",
        r"\b(?P<month>[A-Za-z]{3,9})[-\s]+(?P<day>\d{1,2}),?[-\s]+(?P<year>\d{4})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            month_name = match.group("month").lower()
            month = MONTHS.get(month_name)
            if month:
                normalized = _format_date(int(match.group("year")), month, int(match.group("day")))
                if normalized:
                    return normalized

    # Numeric dates: 9/1/2026, 8-12-2026, 08.12.2026.
    # Insurance slips in the examples are US-style month/day/year.
    match = re.search(r"\b(?P<m>\d{1,2})[/-](?P<d>\d{1,2})[/-](?P<y>\d{2,4})\b", text)
    if match:
        year = int(match.group("y"))
        if year < 100:
            year += 2000
        normalized = _format_date(year, int(match.group("m")), int(match.group("d")))
        if normalized:
            return normalized

    return value


def normalize_currency_value(value: Any, evidence: Any = None) -> Any:
    """Normalize currency mentions/amount strings to an ISO-style currency code."""
    text_parts = []
    if isinstance(value, str):
        text_parts.append(value)
    if isinstance(evidence, str):
        text_parts.append(evidence)
    text = " ".join(text_parts)

    if not text.strip():
        return value

    for pattern, code in CURRENCY_PATTERNS:
        if re.search(pattern, text, flags=re.IGNORECASE):
            return code

    upper_value = value.strip().upper() if isinstance(value, str) else value
    if upper_value in {"USD", "GBP", "EUR", "CAD", "AUD", "INR"}:
        return upper_value

    return value


def calculate_expiration_from_duration(value: Any, evidence: Any) -> Any:
    """
    Fallback for values/evidence like '12 months @ 1st September 2026'.
    The LLM is instructed to calculate this, but this protects the output if it returns the raw phrase.
    """
    if relativedelta is None:
        return value

    text = " ".join(part for part in [str(value or ""), str(evidence or "")] if part).strip()
    if not text:
        return value

    duration_match = re.search(r"\b(?P<num>\d{1,2})\s*months?\b", text, flags=re.IGNORECASE)
    if not duration_match:
        return value

    # Date after @ or after 'from'.
    date_candidate = text
    at_match = re.search(r"@\s*(.+)$", text)
    if at_match:
        date_candidate = at_match.group(1)

    inception = normalize_date_value(date_candidate)
    if not isinstance(inception, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", inception):
        return value

    start = datetime.strptime(inception, "%Y-%m-%d")
    end = start + relativedelta(months=int(duration_match.group("num")))
    return end.strftime("%Y-%m-%d")



def calculate_expiration_from_inception(inception_value: Any, days: int = 364) -> Optional[str]:
    """Calculate expiration as the normalized inception date plus the configured number of days."""
    normalized = normalize_date_value(inception_value)
    if not isinstance(normalized, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return None

    try:
        inception_date = datetime.strptime(normalized, "%Y-%m-%d")
    except ValueError:
        return None

    return (inception_date + timedelta(days=days)).strftime("%Y-%m-%d")


def normalize_monetary_amount(value: Any) -> Any:
    """Normalize a monetary amount to a plain numeric string without currency or separators."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return str(value)
    if not isinstance(value, str):
        return value

    text = value.strip()
    if not text:
        return value

    # Remove common currency labels/symbols and thousands separators while preserving decimals.
    text = re.sub(r"\b(?:USD|GBP|EUR|CAD|AUD|INR)\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"[$£€₹]", "", text)
    text = text.replace(",", "").strip()

    match = re.search(r"-?\d+(?:\.\d+)?", text)
    return match.group(0) if match else value

def post_process_result(field_name: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """Apply deterministic cleanup after LLM extraction."""
    cleaned = dict(result)
    value = cleaned.get("Value")
    evidence = cleaned.get("Evidence")
    normalized_name = (field_name or "").strip().lower()

    if normalized_name in {"inception date", "effective date"}:
        cleaned["Value"] = normalize_date_value(value)
    elif normalized_name in {"expiration date", "expiry date"}:
        calculated = calculate_expiration_from_duration(value, evidence)
        cleaned["Value"] = normalize_date_value(calculated)
    elif normalized_name == "currency":
        cleaned["Value"] = normalize_currency_value(value, evidence)
    elif normalized_name == "limit one":
        cleaned["Value"] = normalize_monetary_amount(value)

    return cleaned
