import json
import os
import re
import unicodedata
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

from dotenv import load_dotenv

from Chunking.chunker import chunk_azure_documents, chunk_documents
from Chunking.document_loader import process_all_documents
from DocumentIntelligence.azure_document_loader import process_documents_with_azure
from Fields.fields_loader import load_fields_from_json
from Retriever.context_builder import build_context
from Retriever.indexer import create_faiss_index
from Retriever.llm import run_llm
from Retriever.retriever import retrieve_relevant_chunks
from Utilities.post_processor import calculate_expiration_from_inception, post_process_result
from Extractors.perils import derive_perils_fields

load_dotenv()

FILE_PATH = "./Documents"
FIELDS_JSON_PATH = "./Fields/fields.json"
OUTPUT_JSON_PATH = "./extraction_output.json"
OUTPUT_FOLDER = "./extraction_outputs"
AZURE_JSON_OUTPUT_FOLDER = "./azure_layout_json"
CHUNKS_OUTPUT_PATH = "./chunks_output.json"
VECTOR_OUTPUT_FOLDER = "./vector_outputs"
FAISS_OUTPUT_FOLDER = "./faiss_indexes"

# Options:
# azure = Azure Document Intelligence + mixed chunking
# local = older PyMuPDF/DOCX text extraction + fixed chunking fallback
EXTRACTION_MODE = os.getenv("EXTRACTION_MODE", "azure").lower().strip()
AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID = os.getenv(
    "AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID",
    "prebuilt-document",
)


def normalize_text(value):
    """Normalize whitespace and unicode for clean output."""
    if not isinstance(value, str):
        return value

    value = unicodedata.normalize("NFKC", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def safe_filename(value: str) -> str:
    """Create a safe file name for per-document JSON output."""
    stem = Path(value).stem or "document"
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return stem or "document"


def save_json(data, output_path: str) -> None:
    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, ensure_ascii=False)


def group_by_document_id(items: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """Group pages/chunks by document_id."""
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for item in items:
        document_id = item.get("document_id") or "unknown_document"
        grouped[document_id].append(item)
    return dict(grouped)


def load_and_chunk_documents_by_file() -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str, Any]]]:
    """
    Load every supported file from the Documents folder and return chunks grouped per file.

    This is important because extraction must run independently for each slip.
    If all files are indexed together, the retriever can mix evidence from different slips
    and the final output becomes one combined result instead of one result per document.
    """
    if EXTRACTION_MODE == "local":
        print("Running in LOCAL mode: PyMuPDF/DOCX loader + fixed chunking.")
        pages = process_all_documents(FILE_PATH)
        print(f"Total pages loaded: {len(pages)}")

        if not pages:
            raise ValueError("No document text was loaded. Add PDF/DOCX files inside the Documents folder.")

        chunks_by_document: Dict[str, List[Dict[str, Any]]] = {}
        all_chunks: List[Dict[str, Any]] = []

        for document_id, document_pages in group_by_document_id(pages).items():
            document_chunks = chunk_documents(document_pages)
            chunks_by_document[document_id] = document_chunks
            all_chunks.extend(document_chunks)
            print(f"{document_id}: {len(document_chunks)} chunks generated")

        return chunks_by_document, all_chunks

    print("Running in AZURE mode: Azure Document Intelligence + mixed chunking.")
    analyzed_documents = process_documents_with_azure(
        folder_path=FILE_PATH,
        output_json_folder=AZURE_JSON_OUTPUT_FOLDER,
        model_id=AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID,
    )

    print(f"Total documents analyzed by Azure: {len(analyzed_documents)}")

    if not analyzed_documents:
        raise ValueError("No documents were analyzed. Check Documents folder, file types, and Azure credentials.")

    chunks_by_document = {}
    all_chunks = []

    for analyzed_document in analyzed_documents:
        document_id = analyzed_document["document_id"]
        document_chunks = chunk_azure_documents([analyzed_document])
        chunks_by_document[document_id] = document_chunks
        all_chunks.extend(document_chunks)
        print(f"{document_id}: {len(document_chunks)} chunks generated")

    return chunks_by_document, all_chunks


def extract_fields_for_document(
    document_id: str,
    chunks: List[Dict[str, Any]],
    fields: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Create a document-specific FAISS index and extract all configured fields."""
    if not chunks:
        return {
            "document_id": document_id,
            "status": "failed",
            "error": "No chunks generated for this document.",
            "fields": {},
        }

    print(f"\n==============================")
    print(f"Processing document: {document_id}")
    print(f"Chunks for this document: {len(chunks)}")
    print(f"==============================")

    safe_doc_name = safe_filename(document_id)
    vector_store = create_faiss_index(
        chunks,
        faiss_output_folder=os.path.join(FAISS_OUTPUT_FOLDER, safe_doc_name),
        vectors_output_path=os.path.join(VECTOR_OUTPUT_FOLDER, f"{safe_doc_name}_chunk_vectors.jsonl"),
    )
    extracted_fields: Dict[str, Any] = {}

    # Only fields with an active LLM extraction operation are sent through retrieval + LLM.
    # Expiration Date remains in fields.json for future reuse, but its previous LLM path is
    # intentionally disabled below because the active requirement is Inception Date + 364 days.
    dynamic_fields = [
        field
        for field in fields
        if field.get("operation_type") in {"extract", "extract_or_calculate"}
        and field.get("field_name") != "Expiration Date"
    ]
    for field in dynamic_fields:
        field_name = field["field_name"]
        print(f"\nExtracting field: {field_name} from {document_id}")

        retrieved_chunks = retrieve_relevant_chunks(
            vector_store=vector_store,
            field=field,
            k=10,
        )

        context = build_context(retrieved_chunks)
        llm_result = run_llm(field, context)
        llm_result = post_process_result(field_name, llm_result)

        if isinstance(llm_result.get("Value"), str):
            llm_result["Value"] = normalize_text(llm_result["Value"])

        # Add document_id for traceability in the output.
        llm_result["Document_id"] = document_id
        extracted_fields[field_name] = llm_result

        print(f"Extracted value for {field_name}:")
        print(json.dumps(llm_result, indent=2, ensure_ascii=False))

    # -------------------------------------------------------------------------
    # PREVIOUS EXPIRATION DATE LLM EXTRACTION (DISABLED FOR FUTURE REUSE)
    # -------------------------------------------------------------------------
    # expiration_field = next(
    #     (field for field in fields if field.get("field_name") == "Expiration Date"),
    #     None,
    # )
    # if expiration_field:
    #     retrieved_chunks = retrieve_relevant_chunks(
    #         vector_store=vector_store,
    #         field=expiration_field,
    #         k=10,
    #     )
    #     context = build_context(retrieved_chunks)
    #     expiration_result = run_llm(expiration_field, context)
    #     expiration_result = post_process_result("Expiration Date", expiration_result)
    #     expiration_result["Document_id"] = document_id
    #     extracted_fields["Expiration Date"] = expiration_result

    # Active expiration logic: calculate from the already extracted inception date.
    inception_result = extracted_fields.get("Inception Date", {})
    inception_value = inception_result.get("Value")
    calculated_expiration = calculate_expiration_from_inception(inception_value, days=364)
    extracted_fields["Expiration Date"] = {
        "Value": calculated_expiration,
        "Chunk_id": inception_result.get("Chunk_id"),
        "Chunk_type": inception_result.get("Chunk_type"),
        "Evidence": (
            f"Calculated as Inception Date {inception_value} + 364 days"
            if calculated_expiration
            else None
        ),
        "Confidence": inception_result.get("Confidence", 0.0) if calculated_expiration else 0.0,
        "Document_id": document_id,
        "Calculation": "Inception Date + 364 days",
    }

    # Static schema value requested by the downstream output.
    extracted_fields["Sub Limit Limit Type"] = {
        "Value": "B",
        "Chunk_id": None,
        "Chunk_type": "static",
        "Evidence": "Static configured value",
        "Confidence": 1.0,
        "Document_id": document_id,
    }

    # Perils and Layer Perils are deterministic outputs. PTR is appended only
    # when terrorism wording is found in the deductible section.
    extracted_fields.update(derive_perils_fields(chunks, document_id))

    # Preserve the field order configured in fields.json in the returned JSON.
    ordered_extracted_fields: Dict[str, Any] = {}
    for configured_field in fields:
        configured_name = configured_field.get("field_name")
        if configured_name in extracted_fields:
            ordered_extracted_fields[configured_name] = extracted_fields[configured_name]
    for field_name, field_result in extracted_fields.items():
        if field_name not in ordered_extracted_fields:
            ordered_extracted_fields[field_name] = field_result
    extracted_fields = ordered_extracted_fields

    return {
        "document_id": document_id,
        "status": "success",
        "chunking_summary": {
            "total_chunks": len(chunks),
            "chunk_type_counts": dict(__import__("collections").Counter(c.get("chunk_type") for c in chunks)),
            "vectors_file": os.path.join(VECTOR_OUTPUT_FOLDER, f"{safe_doc_name}_chunk_vectors.jsonl"),
            "faiss_index_folder": os.path.join(FAISS_OUTPUT_FOLDER, safe_doc_name),
        },
        "fields": extracted_fields,
    }


def runner():
    print("Loading fields...")
    fields = load_fields_from_json(FIELDS_JSON_PATH)

    if not fields:
        raise ValueError("No fields found in Fields/fields.json")

    print(f"Fields to extract: {[field['field_name'] for field in fields]}")

    print("\nLoading and chunking documents...")
    chunks_by_document, all_chunks = load_and_chunk_documents_by_file()

    if not all_chunks:
        raise ValueError("No chunks were generated.")

    save_json(all_chunks, CHUNKS_OUTPUT_PATH)
    print(f"\nAll chunks saved to: {CHUNKS_OUTPUT_PATH}")
    print(f"Total chunks generated across all documents: {len(all_chunks)}")
    print(f"Total documents to extract: {len(chunks_by_document)}")

    document_outputs: List[Dict[str, Any]] = []
    output_by_document: Dict[str, Any] = {}

    for document_id, document_chunks in chunks_by_document.items():
        document_output = extract_fields_for_document(
            document_id=document_id,
            chunks=document_chunks,
            fields=fields,
        )
        document_outputs.append(document_output)
        output_by_document[document_id] = document_output

        per_document_output_path = os.path.join(
            OUTPUT_FOLDER,
            f"{safe_filename(document_id)}_extraction_output.json",
        )
        save_json(document_output, per_document_output_path)
        print(f"Per-document output saved to: {per_document_output_path}")

    final_output = {
        "total_documents": len(document_outputs),
        "documents": document_outputs,
        "by_document": output_by_document,
    }

    save_json(final_output, OUTPUT_JSON_PATH)

    print("\nFinal output:")
    print(json.dumps(final_output, indent=2, ensure_ascii=False))
    print(f"\nCombined output saved to: {OUTPUT_JSON_PATH}")
    print(f"Individual outputs saved inside: {OUTPUT_FOLDER}")

    return final_output


if __name__ == "__main__":
    try:
        runner()
    except Exception as e:
        print(f"An error occurred: {e}")
