import re
from typing import Any, Dict, Iterable, List, Tuple

from langchain_core.documents import Document


CHUNK_TYPE_PRIORITY = {
    "key_value": 100,
    "section": 95,
    "section_split": 92,
    "paragraph": 80,
    "table_row": 75,
    "table": 70,
    "page_split": 45,
    "page": 40,
    "fixed_text": 35,
}

FIELD_RETRIEVAL_KEYWORDS = {
    "insured name": [
        "named insured",
        "first named insured",
        "primary named insured",
        "insured entity",
        "insured name",
        "applicant name",
        "account name",
        "organization name",
        "client name",
        "legal entity",
        "will be",
        "named insured will be",
        "first named insured will be",
        "org chart for",
    ],
    "inception date": [
        "inception date",
        "effective date",
        "policy effective date",
        "policy start date",
        "policy term",
        "policy period",
        "period",
        "from",
        "begins",
        "beginning",
        "attachment date",
        "12 months",
    ],
    "expiration date": [
        "expiration date",
        "expiry date",
        "policy expiration date",
        "policy end date",
        "policy term",
        "policy period",
        "period",
        "to",
        "ends",
        "ending",
        "12 months",
        "cancellation or expiration",
    ],
    "limit one": [
        "tiv",
        "total insurable value",
        "total insured value",
        "total values",
        "total value",
        "summary of values",
        "statement of values",
        "building",
        "buildings",
        "building value",
        "contents",
        "contents value",
    ],
    "currency": [
        "currency",
        "usd",
        "us dollar",
        "united states dollar",
        "dollar",
        "$",
        "gbp",
        "eur",
        "cad",
        "aud",
        "inr",
        "limit of liability",
        "limit",
        "deductible",
        "premium",
        "values",
        "occurrence",
        "aop",
        "flood",
        "earth movement",
    ],
}

DATE_RANGE_PATTERN = re.compile(
    r"(\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{1,2}[-\s][A-Za-z]{3,9}[-\s]\d{4}\b|\b[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}\b).{0,40}"
    r"(to|through|until|ending|ends).{0,40}"
    r"(\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{1,2}[-\s][A-Za-z]{3,9}[-\s]\d{4}\b|\b[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}\b)",
    flags=re.IGNORECASE,
)

CURRENCY_PATTERN = re.compile(
    r"\b(USD|GBP|EUR|CAD|AUD|INR)\b|\$|£|€|₹|\bUS\s*Dollars?\b|\bUnited\s+States\s+Dollars?\b",
    flags=re.IGNORECASE,
)


def get_field_keywords(field: Dict[str, Any]) -> List[str]:
    field_name = str(field.get("field_name", "")).strip().lower()
    possible_names = field.get("possible_names", []) or []

    keywords: List[str] = [field.get("field_name", ""), field.get("description", "")]
    keywords.extend(FIELD_RETRIEVAL_KEYWORDS.get(field_name, []))
    if isinstance(possible_names, list):
        keywords.extend(possible_names)

    return [str(keyword) for keyword in keywords if keyword]


def build_query(field: Dict[str, Any]) -> str:
    """Build a retrieval query focused on the requested field."""
    return " ".join(get_field_keywords(field))


def get_all_indexed_documents(vector_store) -> List[Document]:
    """Read all LangChain Document objects from a FAISS vector store."""
    docstore_dict = getattr(vector_store.docstore, "_dict", {})
    return list(docstore_dict.values())


def normalize_for_match(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def keyword_score(doc: Document, field: Dict[str, Any]) -> int:
    """Simple keyword score for hybrid retrieval."""
    text = normalize_for_match(doc.page_content)
    field_name = str(field.get("field_name", "")).strip().lower()
    keywords = get_field_keywords(field)

    score = 0
    for keyword in keywords:
        keyword = normalize_for_match(str(keyword))
        if keyword and keyword in text:
            score += 10

    # Strong boosts for common insurance patterns.
    if field_name == "insured name" and "will be" in text and "insured" in text:
        score += 25

    if field_name in {"inception date", "expiration date"}:
        if DATE_RANGE_PATTERN.search(doc.page_content):
            score += 35
        if re.search(r"\b\d{1,2}\s*months?\s*@", doc.page_content, flags=re.IGNORECASE):
            score += 35
        if "policy term" in text or "policy period" in text or "effective date" in text:
            score += 20

    if field_name == "currency":
        if CURRENCY_PATTERN.search(doc.page_content):
            score += 35
        if re.search(r"\b(limit|deductible|premium|values?|occurrence)\b", text):
            score += 15

    if field_name == "limit one":
        if re.search(r"\bTIV\b|total\s+(?:insurable|insured)?\s*value|total\s+values?", doc.page_content, flags=re.IGNORECASE):
            score += 60
        if re.search(r"\bbuildings?\b", text) and re.search(r"\bcontents?\b", text):
            score += 40
        if re.search(r"\bsummary of values\b|\bstatement of values\b", text):
            score += 30
        if CURRENCY_PATTERN.search(doc.page_content):
            score += 15

    chunk_type = doc.metadata.get("chunk_type")
    score += CHUNK_TYPE_PRIORITY.get(chunk_type, 0)

    return score


def dedupe_documents(documents: Iterable[Document]) -> List[Document]:
    unique: List[Document] = []
    seen_ids = set()

    for doc in documents:
        chunk_id = doc.metadata.get("chunk_id")
        if chunk_id in seen_ids:
            continue
        seen_ids.add(chunk_id)
        unique.append(doc)

    return unique


def expand_with_parent_context(vector_store, documents: List[Document], max_parent_docs: int = 3) -> List[Document]:
    """
    Add parent page/table chunks for selected child chunks.

    This supports parent-child retrieval: the retriever can find a small chunk,
    but the LLM also sees the nearby parent context.
    """
    all_docs = get_all_indexed_documents(vector_store)
    by_chunk_id = {doc.metadata.get("chunk_id"): doc for doc in all_docs}

    expanded: List[Document] = list(documents)
    parent_added = 0

    for doc in documents:
        parent_id = doc.metadata.get("parent_id")
        if not parent_id:
            continue

        parent_doc = by_chunk_id.get(parent_id)
        if not parent_doc:
            continue

        expanded.append(parent_doc)
        parent_added += 1

        if parent_added >= max_parent_docs:
            break

    return dedupe_documents(expanded)


def retrieve_relevant_chunks(vector_store, field: Dict[str, Any], k: int = 10) -> List[Any]:
    """
    Hybrid retrieval:
    1. Vector similarity search from FAISS
    2. Keyword search over indexed chunks
    3. Parent context expansion
    4. Deduplication
    """
    query = build_query(field)
    print(f"Retrieving chunks for field: {field.get('field_name')}")

    vector_results = vector_store.similarity_search(query, k=k)

    all_docs = get_all_indexed_documents(vector_store)
    keyword_ranked: List[Tuple[int, Document]] = []

    for doc in all_docs:
        score = keyword_score(doc, field)
        if score > 0:
            keyword_ranked.append((score, doc))

    keyword_ranked.sort(key=lambda item: item[0], reverse=True)
    keyword_results = [doc for _, doc in keyword_ranked[: max(8, k)]]

    combined = dedupe_documents(keyword_results + vector_results)
    expanded = expand_with_parent_context(vector_store, combined, max_parent_docs=3)

    # Keep the context size controlled.
    final_results = expanded[: k + 3]

    print(
        f"Retrieved chunks: vector={len(vector_results)}, "
        f"keyword={len(keyword_results)}, final_with_parents={len(final_results)}"
    )
    return final_results
