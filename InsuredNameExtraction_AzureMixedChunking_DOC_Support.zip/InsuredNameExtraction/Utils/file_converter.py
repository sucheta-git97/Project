import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional


COMMON_LIBREOFFICE_PATHS = [
    r"C:\Program Files\LibreOffice\program\soffice.exe",
    r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    "/usr/bin/soffice",
    "/usr/local/bin/soffice",
    "/opt/libreoffice/program/soffice",
]


def find_soffice_executable(custom_path: Optional[str] = None) -> str:
    """
    Find LibreOffice executable.

    Priority:
    1. Custom path from env/code
    2. PATH lookup
    3. Common Windows/Linux install locations
    """
    if custom_path:
        custom = Path(custom_path)
        if custom.exists():
            return str(custom)

    env_path = os.getenv("LIBREOFFICE_PATH")
    if env_path:
        env_candidate = Path(env_path)
        if env_candidate.exists():
            return str(env_candidate)

    path_lookup = shutil.which("soffice") or shutil.which("libreoffice")
    if path_lookup:
        return path_lookup

    for candidate in COMMON_LIBREOFFICE_PATHS:
        if Path(candidate).exists():
            return candidate

    raise FileNotFoundError(
        "LibreOffice executable was not found. Install LibreOffice and either add 'soffice' "
        "to PATH or set LIBREOFFICE_PATH in .env, for example: "
        "LIBREOFFICE_PATH=C:\\Program Files\\LibreOffice\\program\\soffice.exe"
    )


def convert_office_to_pdf(
    input_path: str,
    output_folder: str = "./converted_documents",
    soffice_path: Optional[str] = None,
) -> str:
    """
    Convert Office files such as .doc, .docx, .rtf, .odt to PDF using LibreOffice.

    Azure Document Intelligence does not reliably accept legacy .doc files directly.
    This function converts them to PDF first and returns the converted PDF path.
    """
    input_file = Path(input_path).resolve()

    if not input_file.exists():
        raise FileNotFoundError(f"Input file not found: {input_file}")

    output_dir = Path(output_folder).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    converted_pdf = output_dir / f"{input_file.stem}.pdf"

    # Reuse already converted PDF when it is newer than the source document.
    if converted_pdf.exists() and converted_pdf.stat().st_mtime >= input_file.stat().st_mtime:
        return str(converted_pdf)

    executable = find_soffice_executable(soffice_path=soffice_path)

    command = [
        executable,
        "--headless",
        "--convert-to",
        "pdf",
        "--outdir",
        str(output_dir),
        str(input_file),
    ]

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=180,
    )

    if result.returncode != 0:
        raise RuntimeError(
            f"LibreOffice conversion failed for {input_file.name}\n"
            f"Command: {' '.join(command)}\n"
            f"STDOUT: {result.stdout}\n"
            f"STDERR: {result.stderr}"
        )

    if not converted_pdf.exists():
        raise FileNotFoundError(
            f"LibreOffice finished but expected converted PDF was not found: {converted_pdf}\n"
            f"STDOUT: {result.stdout}\n"
            f"STDERR: {result.stderr}"
        )

    return str(converted_pdf)
