import json
import mimetypes
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient

from Utils.file_converter import convert_office_to_pdf

load_dotenv()

AZURE_DOC_INTEL_ENDPOINT = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
AZURE_DOC_INTEL_KEY = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
AZURE_DOC_INTEL_MODEL_ID = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID", "prebuilt-layout")
AZURE_DOC_INTEL_FEATURES = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_FEATURES", "keyValuePairs")
CONVERT_OFFICE_TO_PDF = os.getenv("CONVERT_OFFICE_TO_PDF", "true").lower().strip() in {"1", "true", "yes", "y"}
CONVERTED_DOCUMENTS_FOLDER = os.getenv("CONVERTED_DOCUMENTS_FOLDER", "./converted_documents")

# Files that Azure can receive directly or that the pipeline can convert first.
SUPPORTED_EXTENSIONS = {
    ".pdf",
    ".png",
    ".jpg",
    ".jpeg",
    ".tif",
    ".tiff",
    ".bmp",
    ".docx",
    ".doc",
    ".rtf",
    ".odt",
}

# Legacy/Office files to convert before sending to Azure.
# .doc is the important one for your current issue.
OFFICE_EXTENSIONS_TO_CONVERT = {
    ".doc",
    ".rtf",
    ".odt",
}

# Optional: convert .docx also if Azure rejects your docx files or if you want stronger layout stability.
CONVERT_DOCX_TO_PDF = os.getenv("CONVERT_DOCX_TO_PDF", "false").lower().strip() in {"1", "true", "yes", "y"}


def get_document_intelligence_client() -> DocumentIntelligenceClient:
    """Create Azure Document Intelligence client."""
    missing = [
        name for name, value in {
            "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT": AZURE_DOC_INTEL_ENDPOINT,
            "AZURE_DOCUMENT_INTELLIGENCE_KEY": AZURE_DOC_INTEL_KEY,
        }.items()
        if not value
    ]

    if missing:
        raise ValueError(f"Missing environment variables: {', '.join(missing)}")

    return DocumentIntelligenceClient(
        endpoint=AZURE_DOC_INTEL_ENDPOINT,
        credential=AzureKeyCredential(AZURE_DOC_INTEL_KEY),
    )


def _parse_features() -> Optional[List[str]]:
    """
    Parse Azure Document Intelligence features from .env.

    Example:
        AZURE_DOCUMENT_INTELLIGENCE_FEATURES=keyValuePairs

    Set this to empty if your Azure API version does not accept feature flags:
        AZURE_DOCUMENT_INTELLIGENCE_FEATURES=
    """
    raw = (AZURE_DOC_INTEL_FEATURES or "").strip()
    if not raw:
        return None
    return [item.strip() for item in raw.split(",") if item.strip()]


def _guess_content_type(file_path: str) -> str:
    suffix = Path(file_path).suffix.lower()
    if suffix == ".pdf":
        return "application/pdf"
    if suffix in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if suffix == ".png":
        return "image/png"
    if suffix in {".tif", ".tiff"}:
        return "image/tiff"
    if suffix == ".bmp":
        return "image/bmp"

    guessed, _ = mimetypes.guess_type(file_path)
    return guessed or "application/octet-stream"


def prepare_file_for_azure(file_path: Path) -> Dict[str, str]:
    """
    Prepare file for Azure.

    For .doc, converts to PDF using LibreOffice because legacy DOC is not reliable/directly supported.
    Returns both original and analysis paths.
    """
    ext = file_path.suffix.lower()
    file_to_analyze = str(file_path)
    conversion_status = "not_required"

    should_convert = False
    if CONVERT_OFFICE_TO_PDF and ext in OFFICE_EXTENSIONS_TO_CONVERT:
        should_convert = True
    if CONVERT_OFFICE_TO_PDF and CONVERT_DOCX_TO_PDF and ext == ".docx":
        should_convert = True

    if should_convert:
        print(f"Converting Office file to PDF before Azure analysis: {file_path.name}")
        file_to_analyze = convert_office_to_pdf(
            input_path=str(file_path),
            output_folder=CONVERTED_DOCUMENTS_FOLDER,
        )
        conversion_status = "converted_to_pdf"
        print(f"Converted file created: {file_to_analyze}")

    return {
        "original_path": str(file_path),
        "analysis_path": file_to_analyze,
        "conversion_status": conversion_status,
    }


def analyze_document_with_azure(file_path: str, model_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Analyze one document using Azure Document Intelligence.

    Recommended:
        AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID=prebuilt-layout
        AZURE_DOCUMENT_INTELLIGENCE_FEATURES=keyValuePairs

    For legacy .doc files, convert to PDF first and pass the converted PDF path here.
    """
    model_id = model_id or AZURE_DOC_INTEL_MODEL_ID
    client = get_document_intelligence_client()
    features = _parse_features()
    content_type = _guess_content_type(file_path)

    analyze_kwargs = {
        "model_id": model_id,
        "content_type": content_type,
    }

    if features:
        analyze_kwargs["features"] = features

    with open(file_path, "rb") as file:
        poller = client.begin_analyze_document(
            body=file,
            **analyze_kwargs,
        )

    result = poller.result()
    return result.as_dict()


def save_json(data: Dict[str, Any], output_path: str) -> None:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, ensure_ascii=False)


def process_documents_with_azure(
    folder_path: str,
    output_json_folder: str = "./azure_layout_json",
    model_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Process all supported files in a folder through Azure Document Intelligence.

    .doc handling:
        .doc -> LibreOffice PDF conversion -> Azure Document Intelligence

    Returns:
        List of dictionaries containing original document path, analysis path,
        raw JSON path, and Azure's extracted JSON result.
    """
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"Documents folder not found: {folder_path}")

    os.makedirs(output_json_folder, exist_ok=True)
    analyzed_documents: List[Dict[str, Any]] = []

    for file_path in sorted(folder.iterdir()):
        if not file_path.is_file():
            continue

        ext = file_path.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            print(f"Skipping unsupported file: {file_path.name}")
            continue

        try:
            prepared = prepare_file_for_azure(file_path)
            analysis_path = prepared["analysis_path"]

            print(f"Analyzing with Azure Document Intelligence: {file_path.name}")
            if analysis_path != str(file_path):
                print(f"Azure input file: {analysis_path}")

            result_json = analyze_document_with_azure(analysis_path, model_id=model_id)

            # Keep the Azure JSON name tied to the original document name.
            output_json_path = os.path.join(
                output_json_folder,
                f"{file_path.stem}_azure_output.json",
            )
            save_json(result_json, output_json_path)

            analyzed_documents.append({
                "document_id": file_path.name,
                "source": str(file_path),
                "analysis_source": analysis_path,
                "conversion_status": prepared["conversion_status"],
                "azure_json_path": output_json_path,
                "azure_result": result_json,
            })

            print(f"Azure JSON saved to: {output_json_path}")

        except Exception as exc:
            print(f"Failed to analyze {file_path.name}: {exc}")

    return analyzed_documents
