import json
import os
import re
import unicodedata

from dotenv import load_dotenv

from Chunking.chunker import chunk_azure_documents, chunk_documents
from Chunking.document_loader import process_all_documents
from DocumentIntelligence.azure_document_loader import process_documents_with_azure
from Fields.fields_loader import load_fields_from_json
from Retriever.context_builder import build_context
from Retriever.indexer import create_faiss_index
from Retriever.llm import run_llm
from Retriever.retriever import retrieve_relevant_chunks

load_dotenv()

FILE_PATH = "./Documents"
FIELDS_JSON_PATH = "./Fields/fields.json"
OUTPUT_JSON_PATH = "./extraction_output.json"
AZURE_JSON_OUTPUT_FOLDER = "./azure_layout_json"
CHUNKS_OUTPUT_PATH = "./chunks_output.json"

# Options:
# azure = Azure Document Intelligence + mixed chunking
# local = older PyMuPDF/DOCX text extraction + fixed chunking fallback
EXTRACTION_MODE = os.getenv("EXTRACTION_MODE", "azure").lower().strip()
AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID = os.getenv(
    "AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID",
    "prebuilt-layout"
)


def normalize_text(value):
    """Normalize whitespace and unicode for clean output."""
    if not isinstance(value, str):
        return value

    value = unicodedata.normalize("NFKC", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def save_json(data, output_path: str) -> None:
    with open(output_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2, ensure_ascii=False)


def load_and_chunk_documents():
    """
    Load documents and create chunks.

    Preferred path:
    Azure Document Intelligence -> raw JSON -> mixed chunks.

    Fallback path:
    Local text extraction -> fixed overlapping chunks.
    """
    if EXTRACTION_MODE == "local":
        print("Running in LOCAL mode: PyMuPDF/DOCX loader + fixed chunking.")
        pages = process_all_documents(FILE_PATH)
        print(f"Total pages loaded: {len(pages)}")

        if not pages:
            raise ValueError("No document text was loaded. Add PDF/DOCX files inside the Documents folder.")

        chunks = chunk_documents(pages)
        return chunks

    print("Running in AZURE mode: Azure Document Intelligence + mixed chunking.")
    analyzed_documents = process_documents_with_azure(
        folder_path=FILE_PATH,
        output_json_folder=AZURE_JSON_OUTPUT_FOLDER,
        model_id=AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID,
    )

    print(f"Total documents analyzed by Azure: {len(analyzed_documents)}")

    if not analyzed_documents:
        raise ValueError("No documents were analyzed. Check Documents folder, file types, and Azure credentials.")

    chunks = chunk_azure_documents(analyzed_documents)
    return chunks


def runner():
    final_output = {}

    print("Loading and chunking documents...")
    chunks = load_and_chunk_documents()

    if not chunks:
        raise ValueError("No chunks were generated.")

    save_json(chunks, CHUNKS_OUTPUT_PATH)
    print(f"Chunks saved to: {CHUNKS_OUTPUT_PATH}")
    print(f"Total chunks generated: {len(chunks)}")

    print("Creating FAISS index...")
    vector_store = create_faiss_index(chunks)

    print("Loading fields...")
    fields = load_fields_from_json(FIELDS_JSON_PATH)

    if not fields:
        raise ValueError("No fields found in Fields/fields.json")

    print(f"Fields to extract: {[field['field_name'] for field in fields]}")

    for field in fields:
        field_name = field["field_name"]

        print(f"\nExtracting field: {field_name}")

        retrieved_chunks = retrieve_relevant_chunks(
            vector_store=vector_store,
            field=field,
            k=10,
        )

        context = build_context(retrieved_chunks)
        llm_result = run_llm(field, context)

        if isinstance(llm_result.get("Value"), str):
            llm_result["Value"] = normalize_text(llm_result["Value"])

        final_output[field_name] = llm_result

        print(f"Extracted value for {field_name}:")
        print(json.dumps(llm_result, indent=2, ensure_ascii=False))

    save_json(final_output, OUTPUT_JSON_PATH)

    print("\nFinal output:")
    print(json.dumps(final_output, indent=2, ensure_ascii=False))
    print(f"\nOutput saved to: {OUTPUT_JSON_PATH}")

    return final_output


if __name__ == "__main__":
    try:
        runner()
    except Exception as e:
        print(f"An error occurred: {e}")
