import re
from typing import Any, Dict, Iterable, List, Tuple

from langchain_core.documents import Document


CHUNK_TYPE_PRIORITY = {
    "key_value": 100,
    "section_candidate": 90,
    "paragraph": 80,
    "table_row": 75,
    "table": 70,
    "table_split": 65,
    "page_split": 45,
    "page": 40,
    "fixed_text": 35,
}


def build_query(field: Dict[str, Any]) -> str:
    """Build a retrieval query focused on insured-name style language."""
    field_name = field.get("field_name", "")
    description = field.get("description", "")
    possible_names = field.get("possible_names", [])

    query_parts = [
        field_name,
        description,
        "named insured",
        "first named insured",
        "primary named insured",
        "insured entity",
        "insured name",
        "applicant name",
        "account name",
        "organization name",
        "client name",
        "legal entity",
        "will be",
        "named insured will be",
        "first named insured will be",
        "org chart for",
    ]

    if isinstance(possible_names, list):
        query_parts.extend(possible_names)

    return " ".join(str(part) for part in query_parts if part)


def get_all_indexed_documents(vector_store) -> List[Document]:
    """Read all LangChain Document objects from a FAISS vector store."""
    docstore_dict = getattr(vector_store.docstore, "_dict", {})
    return list(docstore_dict.values())


def normalize_for_match(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def keyword_score(doc: Document, field: Dict[str, Any]) -> int:
    """Simple keyword score for hybrid retrieval."""
    text = normalize_for_match(doc.page_content)
    possible_names = field.get("possible_names", []) or []

    keywords = [
        field.get("field_name", ""),
        "insured name",
        "named insured",
        "first named insured",
        "primary named insured",
        "applicant",
        "account name",
        "client name",
        "organization name",
        "org chart for",
        "legal entity",
    ]
    keywords.extend(possible_names if isinstance(possible_names, list) else [])

    score = 0
    for keyword in keywords:
        keyword = normalize_for_match(str(keyword))
        if keyword and keyword in text:
            score += 10

    # Strong boost for sentence-style evidence.
    if "will be" in text and "insured" in text:
        score += 25

    chunk_type = doc.metadata.get("chunk_type")
    score += CHUNK_TYPE_PRIORITY.get(chunk_type, 0)

    return score


def dedupe_documents(documents: Iterable[Document]) -> List[Document]:
    unique: List[Document] = []
    seen_ids = set()

    for doc in documents:
        chunk_id = doc.metadata.get("chunk_id")
        if chunk_id in seen_ids:
            continue
        seen_ids.add(chunk_id)
        unique.append(doc)

    return unique


def expand_with_parent_context(vector_store, documents: List[Document], max_parent_docs: int = 3) -> List[Document]:
    """
    Add parent page/table chunks for selected child chunks.

    This supports parent-child retrieval: the retriever can find a small chunk,
    but the LLM also sees the nearby parent context.
    """
    all_docs = get_all_indexed_documents(vector_store)
    by_chunk_id = {doc.metadata.get("chunk_id"): doc for doc in all_docs}

    expanded: List[Document] = list(documents)
    parent_added = 0

    for doc in documents:
        parent_id = doc.metadata.get("parent_id")
        if not parent_id:
            continue

        parent_doc = by_chunk_id.get(parent_id)
        if not parent_doc:
            continue

        expanded.append(parent_doc)
        parent_added += 1

        if parent_added >= max_parent_docs:
            break

    return dedupe_documents(expanded)


def retrieve_relevant_chunks(vector_store, field: Dict[str, Any], k: int = 10) -> List[Any]:
    """
    Hybrid retrieval:
    1. Vector similarity search from FAISS
    2. Keyword search over indexed chunks
    3. Parent context expansion
    4. Deduplication
    """
    query = build_query(field)
    print(f"Retrieving chunks for field: {field.get('field_name')}")

    vector_results = vector_store.similarity_search(query, k=k)

    all_docs = get_all_indexed_documents(vector_store)
    keyword_ranked: List[Tuple[int, Document]] = []

    for doc in all_docs:
        score = keyword_score(doc, field)
        if score > 0:
            keyword_ranked.append((score, doc))

    keyword_ranked.sort(key=lambda item: item[0], reverse=True)
    keyword_results = [doc for _, doc in keyword_ranked[: max(5, k // 2)]]

    combined = dedupe_documents(keyword_results + vector_results)
    expanded = expand_with_parent_context(vector_store, combined, max_parent_docs=3)

    # Keep the context size controlled.
    final_results = expanded[: k + 3]

    print(
        f"Retrieved chunks: vector={len(vector_results)}, "
        f"keyword={len(keyword_results)}, final_with_parents={len(final_results)}"
    )
    return final_results
