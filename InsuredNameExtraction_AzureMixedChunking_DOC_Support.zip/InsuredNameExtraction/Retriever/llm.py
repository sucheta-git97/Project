import json
import os
import re
from typing import Any, Dict

from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI

from Prompt.prompt import SYSTEM_EXTRACTION_PROMPT, USER_EXTRACTION_PROMPT


load_dotenv()

AZURE_API_KEY = os.getenv("AZURE_OPENAI_KEY")
AZURE_API_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
AZURE_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")


def get_llm():
    """Create Azure OpenAI chat client."""
    missing = [
        name for name, value in {
            "AZURE_OPENAI_KEY": AZURE_API_KEY,
            "AZURE_OPENAI_ENDPOINT": AZURE_API_ENDPOINT,
            "AZURE_OPENAI_API_VERSION": AZURE_API_VERSION,
            "AZURE_OPENAI_DEPLOYMENT_NAME": AZURE_DEPLOYMENT_NAME,
        }.items()
        if not value
    ]

    if missing:
        raise ValueError(f"Missing environment variables: {', '.join(missing)}")

    return AzureChatOpenAI(
        azure_deployment=AZURE_DEPLOYMENT_NAME,
        api_key=AZURE_API_KEY,
        azure_endpoint=AZURE_API_ENDPOINT,
        api_version=AZURE_API_VERSION,
        temperature=0
    )


def extract_json_block(text: str) -> str:
    """Extract JSON object from an LLM response."""
    text = text.strip()

    if text.startswith("{") and text.endswith("}"):
        return text

    match = re.search(r"\{.*\}", text, re.DOTALL)

    if match:
        return match.group(0)

    raise ValueError("No JSON block found in LLM response.")


def run_llm(field: Dict[str, Any], context: str) -> Dict[str, Any]:
    """Run extraction LLM and return parsed JSON result."""
    llm = get_llm()

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_EXTRACTION_PROMPT),
        ("human", USER_EXTRACTION_PROMPT)
    ])

    chain = prompt | llm | StrOutputParser()

    raw_result = chain.invoke({
        "field_name": field.get("field_name", ""),
        "field_description": field.get("description", ""),
        "field_possible_names": field.get("possible_names", []),
        "value_format": field.get("value_format", ""),
        "context": context
    })

    print(f"Raw LLM output:\n{raw_result}")

    try:
        json_text = extract_json_block(raw_result)
        parsed = json.loads(json_text)

        value = parsed.get("Value")
        if isinstance(value, str) and value.strip().lower() in ["null", "none", "not found", "n/a"]:
            value = None

        confidence = parsed.get("Confidence", 0.0)
        try:
            confidence = float(confidence) if confidence is not None else 0.0
        except (TypeError, ValueError):
            confidence = 0.0

        return {
            "Value": value,
            "Chunk_id": parsed.get("Chunk_id"),
            "Chunk_type": parsed.get("Chunk_type"),
            "Evidence": parsed.get("Evidence"),
            "Confidence": confidence
        }

    except Exception as e:
        print(f"Failed to parse LLM output: {e}")

        return {
            "Value": None,
            "Chunk_id": None,
            "Chunk_type": None,
            "Evidence": None,
            "Confidence": 0.0
        }
