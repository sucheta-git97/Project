# Insured Name Extraction - Azure Document Intelligence + Mixed Chunking

This project extracts insurance fields such as **Insured Name** from documents using:

1. Azure Document Intelligence layout extraction
2. Mixed chunking
3. FAISS retrieval
4. Azure OpenAI extraction

## Flow

```text
Documents/
  -> Azure Document Intelligence
  -> azure_layout_json/*.json
  -> mixed chunks
  -> chunks_output.json
  -> FAISS retrieval
  -> Azure OpenAI extraction
  -> extraction_output.json
```

## Supported input files

Direct Azure input:

```text
.pdf, .png, .jpg, .jpeg, .tif, .tiff, .bmp, .docx
```

Legacy Office files handled through conversion:

```text
.doc, .rtf, .odt
```

For `.doc`, the pipeline converts the file to PDF first using LibreOffice, then sends the PDF to Azure Document Intelligence.

## Required setup

### 1. Install Python packages

```bash
pip install -r requirements.txt
```

### 2. Install LibreOffice for `.doc` files

Legacy `.doc` files need LibreOffice conversion.

After installing LibreOffice, check this in Anaconda Prompt:

```bash
soffice --version
```

If it does not work, set `LIBREOFFICE_PATH` in `.env`:

```env
LIBREOFFICE_PATH=C:\Program Files\LibreOffice\program\soffice.exe
```

### 3. Create `.env`

Copy `.env.example` to `.env` and fill your keys:

```env
EXTRACTION_MODE=azure

AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://your-doc-intel-resource.cognitiveservices.azure.com/
AZURE_DOCUMENT_INTELLIGENCE_KEY=your_document_intelligence_key_here
AZURE_DOCUMENT_INTELLIGENCE_MODEL_ID=prebuilt-layout
AZURE_DOCUMENT_INTELLIGENCE_FEATURES=keyValuePairs

CONVERT_OFFICE_TO_PDF=true
CONVERTED_DOCUMENTS_FOLDER=./converted_documents
CONVERT_DOCX_TO_PDF=false

HUGGING_FACE_TOKEN=your_huggingface_token_here
EMBEDDING_MODEL_NAME=BAAI/bge-base-en

AZURE_OPENAI_KEY=your_azure_openai_key_here
AZURE_OPENAI_ENDPOINT=https://your-openai-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-02-15-preview
AZURE_OPENAI_DEPLOYMENT_NAME=your_chat_model_deployment_name
```

## How to run

Put files inside:

```text
Documents/
```

Then run:

```bash
python main.py
```

## Output files

```text
converted_documents/       # PDFs created from .doc/.rtf/.odt files
azure_layout_json/         # raw Azure Document Intelligence JSON
chunks_output.json         # mixed chunks generated from Azure JSON
extraction_output.json     # final extracted field output
```

## Chunk types generated

```text
page
paragraph
key_value
table
table_row
section_candidate
page_split / table_split for large chunks
```

## Important note for `.doc`

Do not send `.doc` directly to Azure. This project converts `.doc` to PDF first and then sends the converted PDF to Azure Document Intelligence.
