import re
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    from dateutil.relativedelta import relativedelta
except Exception:  # pragma: no cover
    relativedelta = None


MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2,
    "mar": 3, "march": 3, "apr": 4, "april": 4, "may": 5,
    "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10, "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

CURRENCY_PATTERNS = [
    (r"\bUSD\b|\bUS\s*Dollars?\b|\bUnited\s+States\s+Dollars?\b|\$", "USD"),
    (r"\bGBP\b|\bPounds?\b|\bSterling\b|£", "GBP"),
    (r"\bEUR\b|\bEuros?\b|€", "EUR"),
    (r"\bCAD\b|\bCanadian\s+Dollars?\b", "CAD"),
    (r"\bAUD\b|\bAustralian\s+Dollars?\b", "AUD"),
    (r"\bINR\b|\bIndian\s+Rupees?\b|₹", "INR"),
]

# A monetary candidate may be written as USD 3,356,843,132, $3.3 billion, 8MM, etc.
_AMOUNT_RE = re.compile(
    r"(?:USD|US\s*Dollars?|GBP|EUR|CAD|AUD|INR|[$£€₹])?\s*"
    r"(?P<number>\d{1,3}(?:[ ,]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*"
    r"(?P<scale>bn|billion|mm|million|m)?\b",
    flags=re.IGNORECASE,
)

_DIRECT_TIV_LABEL_RE = re.compile(
    r"\b(?:TIV|total\s+insur(?:able|ed)\s+values?|total\s+insured\s+values?|"
    r"total\s+values?|total\s+property\s+values?)\b",
    flags=re.IGNORECASE,
)

_NON_TIV_RE = re.compile(
    r"\b(?:per\s+occ(?:urrence)?|deductible|sublimit|sub-limit|annual\s+aggregate|"
    r"limit\s+of\s+liability|policy\s+limit|named\s+windstorm|flood\s+limit|premium)\b",
    flags=re.IGNORECASE,
)

_INSURED_LABEL_RE = re.compile(
    r"\b(?:insured\s+name|name(?:d)?\s+insured|first\s+named\s+insured|"
    r"primary\s+named\s+insured|account(?:\s+name)?)\b\s*[:\-]\s*(?P<value>[^\n\r]+)",
    flags=re.IGNORECASE,
)

_INSURED_SUFFIX_PATTERNS = [
    r"\s+and\s+all\s+affiliated\b.*$",
    r"\s+and/or\s+affiliated\b.*$",
    r"\s+and\s+all\s+subsidiar(?:y|ies)\b.*$",
    r"\s+including\s+(?:all\s+)?subsidiar(?:y|ies)\b.*$",
    r"\s+together\s+with\b.*$",
    r"\s+and\s+all\s+associated\b.*$",
    r"\s+and\s+all\s+allied\b.*$",
    r"\s+as\s+now\s+exist\b.*$",
    r"\s+now\s+existing\s+or\s+hereafter\b.*$",
    r"\s+or\s+may\s+hereafter\b.*$",
    r"\s+for\s+which\s+the\s+named\s+insured\b.*$",
]


def _strip_ordinal(day_text: str) -> str:
    return re.sub(r"(?<=\d)(st|nd|rd|th)\b", "", day_text, flags=re.IGNORECASE)


def _format_date(year: int, month: int, day: int) -> Optional[str]:
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return None


def normalize_date_value(value: Any) -> Any:
    if value is None or not isinstance(value, str):
        return value
    text = _strip_ordinal(value.strip())
    if not text:
        return value
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text
    patterns = [
        r"\b(?P<day>\d{1,2})[-\s/]+(?P<month>[A-Za-z]{3,9})[-,\s/]+(?P<year>\d{4})\b",
        r"\b(?P<month>[A-Za-z]{3,9})[-\s]+(?P<day>\d{1,2}),?[-\s]+(?P<year>\d{4})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            month = MONTHS.get(match.group("month").lower())
            if month:
                normalized = _format_date(int(match.group("year")), month, int(match.group("day")))
                if normalized:
                    return normalized
    match = re.search(r"\b(?P<m>\d{1,2})[/-](?P<d>\d{1,2})[/-](?P<y>\d{2,4})\b", text)
    if match:
        year = int(match.group("y"))
        if year < 100:
            year += 2000
        normalized = _format_date(year, int(match.group("m")), int(match.group("d")))
        if normalized:
            return normalized
    return value


def normalize_currency_value(value: Any, evidence: Any = None) -> Any:
    text = " ".join(x for x in [value, evidence] if isinstance(x, str))
    if not text.strip():
        return value
    for pattern, code in CURRENCY_PATTERNS:
        if re.search(pattern, text, flags=re.IGNORECASE):
            return code
    upper_value = value.strip().upper() if isinstance(value, str) else value
    return upper_value if upper_value in {"USD", "GBP", "EUR", "CAD", "AUD", "INR"} else value


def calculate_expiration_from_duration(value: Any, evidence: Any) -> Any:
    if relativedelta is None:
        return value
    text = " ".join(part for part in [str(value or ""), str(evidence or "")] if part).strip()
    duration_match = re.search(r"\b(?P<num>\d{1,2})\s*months?\b", text, flags=re.IGNORECASE)
    if not duration_match:
        return value
    date_candidate = text
    at_match = re.search(r"@\s*(.+)$", text)
    if at_match:
        date_candidate = at_match.group(1)
    inception = normalize_date_value(date_candidate)
    if not isinstance(inception, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", inception):
        return value
    start = datetime.strptime(inception, "%Y-%m-%d")
    return (start + relativedelta(months=int(duration_match.group("num")))).strftime("%Y-%m-%d")


def calculate_expiration_from_inception(inception_value: Any, days: int = 364) -> Optional[str]:
    normalized = normalize_date_value(inception_value)
    if not isinstance(normalized, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized):
        return None
    try:
        inception_date = datetime.strptime(normalized, "%Y-%m-%d")
    except ValueError:
        return None
    return (inception_date + timedelta(days=days)).strftime("%Y-%m-%d")


def normalize_monetary_amount(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return str(int(value)) if value.is_integer() else str(value)
    if not isinstance(value, str) or not value.strip():
        return value
    parsed = _parse_amount(value)
    return parsed[0] if parsed else value


def _parse_amount(text: str) -> Optional[Tuple[str, int, int]]:
    """Return normalized amount plus start/end offsets for the first valid amount."""
    if not isinstance(text, str):
        return None
    for match in _AMOUNT_RE.finditer(text):
        raw_number = match.group("number").replace(",", "").replace(" ", "")
        try:
            amount = Decimal(raw_number)
        except InvalidOperation:
            continue
        scale = (match.group("scale") or "").lower()
        if scale in {"m", "mm", "million"}:
            amount *= Decimal("1000000")
        elif scale in {"bn", "billion"}:
            amount *= Decimal("1000000000")
        if amount <= 0:
            continue
        normalized = format(amount.quantize(Decimal("1")), "f") if amount == amount.to_integral() else format(amount, "f")
        return normalized, match.start(), match.end()
    return None


def clean_insured_name(value: Any) -> Any:
    """Keep only the principal named-insured entity, not the extension clause."""
    if not isinstance(value, str):
        return value
    cleaned = re.sub(r"\s+", " ", value).strip(" ,;:-")
    cleaned = re.sub(
        r"^(?:insured\s+name|name(?:d)?\s+insured|first\s+named\s+insured|primary\s+named\s+insured|account(?:\s+name)?)\s*[:\-]\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )
    for pattern in _INSURED_SUFFIX_PATTERNS:
        cleaned = re.sub(pattern, "", cleaned, flags=re.IGNORECASE).strip(" ,;:-")
    # A principal insured name should not be a full policy paragraph.
    if len(cleaned) > 180:
        cleaned = re.split(r"[.;]", cleaned, maxsplit=1)[0].strip(" ,;:-")
    return cleaned or None


def _chunk_original_text(chunk: Any) -> str:
    metadata = getattr(chunk, "metadata", {}) or {}
    return str(metadata.get("original_text") or getattr(chunk, "page_content", "") or "")


def recover_insured_name_from_chunks(chunks: Iterable[Any]) -> Optional[Dict[str, Any]]:
    """Deterministic fallback for obvious labels such as 'Insured Name: Sutter Health' or 'Account: Frisco ISD'."""
    for chunk in chunks:
        text = _chunk_original_text(chunk)
        for match in _INSURED_LABEL_RE.finditer(text):
            candidate = clean_insured_name(match.group("value"))
            if not candidate or len(candidate) < 2:
                continue
            # Avoid capturing the next field when Azure places only the label on the line.
            if re.match(r"^(?:policy|address|effective|expiration|premium)\b", candidate, flags=re.IGNORECASE):
                continue
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": candidate,
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": match.group(0).strip(),
                "Confidence": 0.98,
            }
    return None


def finalize_insured_name(result: Dict[str, Any], chunks: Iterable[Any]) -> Dict[str, Any]:
    cleaned = dict(result)
    current = clean_insured_name(cleaned.get("Value"))
    if current:
        cleaned["Value"] = current
        if isinstance(cleaned.get("Evidence"), str):
            cleaned["Evidence"] = re.sub(r"\s+", " ", cleaned["Evidence"]).strip()
        return cleaned
    recovered = recover_insured_name_from_chunks(chunks)
    return recovered or {
        "Value": None, "Chunk_id": None, "Chunk_type": None,
        "Evidence": None, "Confidence": 0.0,
    }


def _direct_tiv_candidate(text: str, inception_year: Optional[int] = None) -> Optional[Tuple[str, str]]:
    """Find a directly labelled TIV amount. Reject unrelated limit/deductible wording."""
    if not isinstance(text, str):
        return None
    compact = re.sub(r"\s+", " ", text).strip()
    for label_match in _DIRECT_TIV_LABEL_RE.finditer(compact):
        window = compact[label_match.start(): label_match.end() + 180]
        # A direct TIV window must not actually be a limit-of-liability or occurrence statement.
        if _NON_TIV_RE.search(window[:120]):
            continue
        amounts = []
        for amount_match in _AMOUNT_RE.finditer(window):
            parsed = _parse_amount(amount_match.group(0))
            if parsed:
                raw_candidate = amount_match.group(0).strip()
                if re.fullmatch(r"(?:19|20)\d{2}", raw_candidate):
                    continue
                amounts.append((Decimal(parsed[0]), parsed[0], raw_candidate))
        if amounts:
            # When the TIV row contains year-labelled columns, select the amount for the
            # policy inception year. Never select a YOY %, YOY $ change, or arbitrary maximum.
            if inception_year is not None:
                year_pattern = re.compile(
                    rf"\b{inception_year}\b\s*[:\-]?\s*(?:USD|US\s*Dollars?|GBP|EUR|CAD|AUD|INR|[$£€₹])?\s*"
                    r"(?P<number>\d{1,3}(?:[ ,]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?P<scale>bn|billion|mm|million|m)?\b",
                    flags=re.IGNORECASE,
                )
                year_match = year_pattern.search(window)
                if year_match:
                    amount_text = year_match.group("number")
                    if year_match.group("scale"):
                        amount_text += " " + year_match.group("scale")
                    parsed = _parse_amount(amount_text)
                    if parsed:
                        evidence = window[: min(len(window), 260)].strip()
                        return parsed[0], evidence

                # Header-aware table rows are commonly serialized as
                # "2025: $... | 2026: $... | YOY $: $...".
                labelled = re.search(
                    rf"(?:^|[|;])\s*{inception_year}\s*:\s*([^|;]+)",
                    window,
                    flags=re.IGNORECASE,
                )
                if labelled:
                    parsed = _parse_amount(labelled.group(1))
                    if parsed:
                        evidence = window[: min(len(window), 260)].strip()
                        return parsed[0], evidence

            # If no year-wise bifurcation is present, use the directly stated TIV.
            # If multiple year/delta values are present but the inception year was not
            # matched, do not guess from the largest amount.
            years_present = set(re.findall(r"\b(?:19|20)\d{2}\b", window))
            if inception_year is not None and len(years_present) >= 2:
                continue
            _, normalized, raw = amounts[0]
            evidence = window[: min(len(window), 220)].strip()
            return normalized, evidence
    return None


def _labelled_component(text: str, label: str) -> Optional[Tuple[str, str]]:
    pattern = re.compile(rf"\b{label}\b\s*[:\-]?\s*(?P<tail>.{{0,80}})", flags=re.IGNORECASE)
    for match in pattern.finditer(text):
        tail = match.group("tail")
        if re.search(r"\b(?:deductible|per occurrence|sublimit|premium|yoy|change)\b", tail, flags=re.IGNORECASE):
            continue
        parsed = _parse_amount(tail)
        if parsed:
            return parsed[0], match.group(0).strip()
    return None


def _building_contents_candidate(text: str) -> Optional[Tuple[str, str]]:
    if not isinstance(text, str):
        return None
    compact = re.sub(r"\s+", " ", text)
    building = _labelled_component(compact, r"buildings?(?:\s+value)?")
    contents = _labelled_component(compact, r"contents?(?:\s+value)?")
    if not building or not contents:
        return None
    total = Decimal(building[0]) + Decimal(contents[0])
    normalized = format(total.quantize(Decimal("1")), "f")
    return normalized, f"{building[1]} | {contents[1]}"


def _page_grouped_texts(chunks: Iterable[Any]) -> Iterable[Tuple[str, Any]]:
    """Yield combined original text by page so labels and amounts split across chunks can be matched."""
    grouped: Dict[Any, list] = {}
    representative: Dict[Any, Any] = {}
    for chunk in chunks:
        metadata = getattr(chunk, "metadata", {}) or {}
        page = metadata.get("page")
        key = page if page is not None else metadata.get("chunk_id")
        text = _chunk_original_text(chunk)
        if not text.strip():
            continue
        grouped.setdefault(key, []).append(text)
        representative.setdefault(key, chunk)
    for key, texts in grouped.items():
        # Remove exact duplicate representations while retaining order.
        unique = list(dict.fromkeys(re.sub(r"\s+", " ", text).strip() for text in texts if text.strip()))
        yield "\n".join(unique), representative[key]


def _recover_direct_tiv_from_chunks(chunks: Iterable[Any], inception_year: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """Recover direct TIV from an individual chunk or combined same-page evidence."""
    chunk_list = list(chunks)
    for chunk in chunk_list:
        direct = _direct_tiv_candidate(_chunk_original_text(chunk), inception_year=inception_year)
        if direct:
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": direct[0],
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": direct[1],
                "Confidence": 0.95,
                "Validation": "Recovered from direct labelled TIV evidence",
            }
    for page_text, representative_chunk in _page_grouped_texts(chunk_list):
        direct = _direct_tiv_candidate(page_text, inception_year=inception_year)
        if direct:
            metadata = getattr(representative_chunk, "metadata", {}) or {}
            return {
                "Value": direct[0],
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": direct[1],
                "Confidence": 0.95,
                "Validation": "Recovered from direct labelled TIV evidence across same-page chunks",
            }
    return None


def validate_limit_one(result: Dict[str, Any], chunks: Iterable[Any], min_confidence: float = 0.80, inception_date: Any = None) -> Dict[str, Any]:
    """
    Ground Limit One deterministically.

    Accepted only when:
    1) a direct TIV/Total Insured Value label is tied to an amount, or
    2) both Building and Contents values are explicitly labelled and Python can add them.

    Coverage limits, deductibles, per-occurrence amounts, sublimits and unsupported LLM
    calculations are rejected and returned as null.
    """
    chunk_list = list(chunks)
    normalized_inception = normalize_date_value(inception_date)
    inception_year = None
    if isinstance(normalized_inception, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", normalized_inception):
        inception_year = int(normalized_inception[:4])
    result_confidence = float(result.get("Confidence") or 0.0)
    evidence = str(result.get("Evidence") or "")

    # First validate the exact evidence selected by the model.
    direct = _direct_tiv_candidate(evidence, inception_year=inception_year)
    if direct and result_confidence >= min_confidence:
        return {
            **result,
            "Value": direct[0],
            "Evidence": direct[1],
            "Confidence": max(result_confidence, 0.95),
            "Validation": "Direct labelled TIV evidence",
            "Selection_year": inception_year,
        }
    calculated = _building_contents_candidate(evidence)
    if calculated and result_confidence >= min_confidence:
        return {
            **result,
            "Value": calculated[0],
            "Evidence": calculated[1],
            "Confidence": max(result_confidence, 0.90),
            "Validation": "Building + Contents calculated in Python",
        }

    # If the LLM selected the wrong amount, recover from strong evidence anywhere
    # in the current document. Same-page aggregation handles Azure splitting the
    # TIV label and its amount into separate chunks.
    recovered_direct = _recover_direct_tiv_from_chunks(chunk_list, inception_year=inception_year)
    if recovered_direct:
        recovered_direct["Selection_year"] = inception_year
        return recovered_direct

    for chunk in chunk_list:
        text = _chunk_original_text(chunk)
        calculated = _building_contents_candidate(text)
        if calculated:
            metadata = getattr(chunk, "metadata", {}) or {}
            return {
                "Value": calculated[0],
                "Chunk_id": metadata.get("chunk_id"),
                "Chunk_type": metadata.get("chunk_type"),
                "Evidence": calculated[1],
                "Confidence": 0.90,
                "Validation": "Recovered and calculated from Building + Contents",
            }

    return {
        "Value": None,
        "Chunk_id": None,
        "Chunk_type": None,
        "Evidence": None,
        "Confidence": 0.0,
        "Validation": "Rejected: no direct TIV or verified Building + Contents evidence",
    }



def _extra_metadata(chunk: Any) -> Dict[str, Any]:
    metadata = getattr(chunk, "metadata", {}) or {}
    extra = metadata.get("extra_metadata")
    return extra if isinstance(extra, dict) else metadata


def _polygon_center(polygon: Any) -> Optional[Tuple[float, float]]:
    if not isinstance(polygon, list) or not polygon:
        return None
    points: List[Tuple[float, float]] = []
    if polygon and isinstance(polygon[0], dict):
        for point in polygon:
            try:
                points.append((float(point.get("x")), float(point.get("y"))))
            except (TypeError, ValueError):
                continue
    else:
        nums = []
        for value in polygon:
            try:
                nums.append(float(value))
            except (TypeError, ValueError):
                pass
        points = list(zip(nums[0::2], nums[1::2]))
    if not points:
        return None
    return sum(x for x, _ in points) / len(points), sum(y for _, y in points) / len(points)


def _page_lines_from_chunks(chunks: Iterable[Any]) -> Iterable[Tuple[Any, List[Dict[str, Any]], Any]]:
    seen_pages = set()
    for chunk in chunks:
        metadata = getattr(chunk, "metadata", {}) or {}
        if metadata.get("chunk_type") != "page":
            continue
        page = metadata.get("page")
        if page in seen_pages:
            continue
        extra = _extra_metadata(chunk)
        lines = extra.get("lines", []) if isinstance(extra, dict) else []
        if lines:
            seen_pages.add(page)
            yield page, lines, chunk


def _percentage_values(text: str) -> List[Decimal]:
    values: List[Decimal] = []
    for match in re.finditer(r"(?<!\d)(\d{1,3}(?:\.\d{1,6})?)\s*%", text or ""):
        try:
            value = Decimal(match.group(1))
        except InvalidOperation:
            continue
        if Decimal("0") < value <= Decimal("100"):
            values.append(value)
    return values


def extract_fidelis_signed_line(chunks: Iterable[Any]) -> Dict[str, Any]:
    """Extract signed-line percentage only from a mandatory Fidelis stamp block.

    The Fidelis stamp/entity is a hard gate. Percentages elsewhere in the document
    are never accepted. If several percentages are within the same spatial block,
    an explicitly labelled Signed/Signed Line value wins over Written, Order, or
    minimum-signing values.
    """
    fidelis_re = re.compile(
        r"THE\s+FIDELIS\s+PARTNERSHIP|\bFIDELIS\b|\bFBIL\b|"
        r"Fidelis\s+Insurance\s+Bermuda|Fidelis\s+Underwriting",
        flags=re.IGNORECASE,
    )
    signed_re = re.compile(r"\b(?:signed(?:\s+line)?|line\s+signed|signing)\b", flags=re.IGNORECASE)
    written_re = re.compile(r"\bwritten\b", flags=re.IGNORECASE)
    reject_re = re.compile(r"\b(?:minimum|min\.?|order|subjectivit(?:y|ies))\s*(?:signing|signed|line)?\b", flags=re.IGNORECASE)

    page_candidates = []
    for page, lines, representative in _page_lines_from_chunks(chunks):
        stamp_indexes = [i for i, line in enumerate(lines) if fidelis_re.search(str(line.get("content", "")))]
        if not stamp_indexes:
            continue

        stamp_centers = [_polygon_center(lines[i].get("polygon", [])) for i in stamp_indexes]
        stamp_centers = [c for c in stamp_centers if c is not None]
        for idx, line in enumerate(lines):
            text = str(line.get("content", ""))
            percentages = _percentage_values(text)
            if not percentages:
                continue
            center = _polygon_center(line.get("polygon", []))

            # Spatially associate the percentage with the Fidelis stamp. If geometry
            # is unavailable, use a conservative reading-order window around the stamp.
            near_stamp = False
            distance = 999.0
            if center and stamp_centers:
                for sx, sy in stamp_centers:
                    dx, dy = abs(center[0] - sx), abs(center[1] - sy)
                    candidate_distance = dx + (2.0 * dy)
                    if dx <= 5.5 and dy <= 3.0:
                        near_stamp = True
                        distance = min(distance, candidate_distance)
            else:
                line_distance = min(abs(idx - stamp_idx) for stamp_idx in stamp_indexes)
                if line_distance <= 8:
                    near_stamp = True
                    distance = float(line_distance)
            if not near_stamp:
                continue

            # Include adjacent lines because OCR often separates "25%" and "Signed".
            context_lines = lines[max(0, idx - 2): min(len(lines), idx + 3)]
            context = " | ".join(str(item.get("content", "")) for item in context_lines)
            adjacent_lines = lines[max(0, idx - 1): min(len(lines), idx + 2)]
            adjacent_context = " | ".join(str(item.get("content", "")) for item in adjacent_lines)
            labelled_signed = bool(signed_re.search(text) or signed_re.search(adjacent_context))
            for percentage in percentages:
                score = 50.0 - distance
                if labelled_signed:
                    score += 100.0
                if re.search(r"\bFBIL\b|\bFIDELIS\b", text, flags=re.IGNORECASE):
                    score += 60.0
                elif re.search(r"\bFBIL\b|\bFIDELIS\b", context, flags=re.IGNORECASE):
                    score += 35.0
                if written_re.search(text):
                    score -= 120.0
                elif written_re.search(context) and not signed_re.search(text):
                    score -= 35.0
                if reject_re.search(text):
                    score -= 120.0
                page_candidates.append({
                    "percentage": percentage,
                    "score": score,
                    "text": text,
                    "context": context,
                    "page": page,
                    "chunk": representative,
                    "explicit_signed": labelled_signed,
                })

    if not page_candidates:
        return {
            "Value": None,
            "Chunk_id": None,
            "Chunk_type": None,
            "Evidence": None,
            "Confidence": 0.0,
            "Validation": "Fidelis signature block/stamp not found with an associated percentage",
        }

    # If any candidate is explicitly labelled Signed, restrict selection to those.
    explicit = [candidate for candidate in page_candidates if candidate["explicit_signed"]]
    pool = explicit or page_candidates
    best = max(pool, key=lambda candidate: candidate["score"])
    metadata = getattr(best["chunk"], "metadata", {}) or {}
    confidence = 0.99 if best["explicit_signed"] else 0.92
    return {
        "Value": format(best["percentage"], "f"),
        "Chunk_id": metadata.get("chunk_id"),
        "Chunk_type": "fidelis_signature_block",
        "Evidence": best["context"],
        "Confidence": confidence,
        "Page": best["page"],
        "Validation": "Percentage selected only from the mandatory Fidelis stamp/signature block",
    }


def calculate_limit_two(limit_one_result: Dict[str, Any], signed_line_result: Dict[str, Any], document_id: Optional[str] = None) -> Dict[str, Any]:
    limit_one = normalize_monetary_amount((limit_one_result or {}).get("Value"))
    percentage = (signed_line_result or {}).get("Value")
    try:
        if limit_one is None or percentage is None:
            raise InvalidOperation
        amount = Decimal(str(limit_one))
        pct = Decimal(str(percentage))
        if amount <= 0 or pct <= 0 or pct > 100:
            raise InvalidOperation
        value = (amount * pct / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        return {
            "Value": None,
            "Chunk_id": (signed_line_result or {}).get("Chunk_id"),
            "Chunk_type": "derived",
            "Evidence": (signed_line_result or {}).get("Evidence"),
            "Confidence": 0.0,
            "Document_id": document_id,
            "Signed_line_percentage": percentage,
            "Calculation": None,
            "Validation": (signed_line_result or {}).get("Validation", "Limit One or Fidelis signed line unavailable"),
        }
    return {
        "Value": format(value, "f"),
        "Chunk_id": signed_line_result.get("Chunk_id"),
        "Chunk_type": "derived_from_fidelis_signed_line",
        "Evidence": signed_line_result.get("Evidence"),
        "Confidence": min(float(limit_one_result.get("Confidence") or 0.0), float(signed_line_result.get("Confidence") or 0.0)),
        "Document_id": document_id,
        "Signed_line_percentage": format(pct, "f"),
        "Calculation": f"{format(amount, 'f')} × {format(pct, 'f')} / 100",
        "Validation": "Calculated from validated Limit One and Fidelis signed-line percentage",
    }

def post_process_result(field_name: str, result: Dict[str, Any]) -> Dict[str, Any]:
    cleaned = dict(result)
    value = cleaned.get("Value")
    evidence = cleaned.get("Evidence")
    normalized_name = (field_name or "").strip().lower()

    if normalized_name in {"inception date", "effective date"}:
        cleaned["Value"] = normalize_date_value(value)
    elif normalized_name in {"expiration date", "expiry date"}:
        cleaned["Value"] = normalize_date_value(calculate_expiration_from_duration(value, evidence))
    elif normalized_name == "currency":
        cleaned["Value"] = normalize_currency_value(value, evidence)
    elif normalized_name == "insured name":
        cleaned["Value"] = clean_insured_name(value)
    elif normalized_name == "limit one":
        # Final grounding is intentionally performed by validate_limit_one(), which also
        # receives the retrieved chunks. Do not trust/normalize an unverified LLM number here.
        cleaned["Value"] = normalize_monetary_amount(value)
    return cleaned
