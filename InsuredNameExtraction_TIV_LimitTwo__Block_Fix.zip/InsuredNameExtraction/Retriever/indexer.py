import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings

load_dotenv()

AZURE_EMBEDDING_MODEL_ENDPOINT = os.getenv("AZURE_EMBEDDING_MODEL_ENDPOINT") or os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_EMBEDDING_MODEL_KEY = os.getenv("AZURE_EMBEDDING_MODEL_KEY") or os.getenv("AZURE_OPENAI_KEY")
AZURE_EMBEDDING_MODEL_NAME = os.getenv("AZURE_EMBEDDING_MODEL_NAME", "text-embedding-3-large")
AZURE_EMBEDDING_MODEL_VERSION = os.getenv("AZURE_EMBEDDING_MODEL_VERSION", "2024-02-01")
AZURE_EMBEDDING_DIMENSIONS = os.getenv("AZURE_EMBEDDING_DIMENSIONS", "")
EMBEDDING_BATCH_SIZE = int(os.getenv("EMBEDDING_BATCH_SIZE", "32"))


def get_embedding_model() -> AzureOpenAIEmbeddings:
    missing = [name for name, value in {
        "AZURE_EMBEDDING_MODEL_ENDPOINT": AZURE_EMBEDDING_MODEL_ENDPOINT,
        "AZURE_EMBEDDING_MODEL_KEY": AZURE_EMBEDDING_MODEL_KEY,
        "AZURE_EMBEDDING_MODEL_NAME": AZURE_EMBEDDING_MODEL_NAME,
    }.items() if not value]
    if missing:
        raise ValueError(f"Missing embedding environment variables: {', '.join(missing)}")

    kwargs: Dict[str, Any] = {
        "azure_endpoint": AZURE_EMBEDDING_MODEL_ENDPOINT,
        "api_key": AZURE_EMBEDDING_MODEL_KEY,
        "openai_api_version": AZURE_EMBEDDING_MODEL_VERSION,
        "azure_deployment": AZURE_EMBEDDING_MODEL_NAME,
        "model": "text-embedding-3-large",
        "chunk_size": EMBEDDING_BATCH_SIZE,
    }
    if AZURE_EMBEDDING_DIMENSIONS.strip():
        kwargs["dimensions"] = int(AZURE_EMBEDDING_DIMENSIONS)
    return AzureOpenAIEmbeddings(**kwargs)


def _to_documents(chunks: List[Dict[str, Any]]) -> Tuple[List[Document], List[Dict[str, Any]]]:
    documents: List[Document] = []
    retained_chunks: List[Dict[str, Any]] = []
    for chunk in chunks:
        original_text = chunk.get("text", "")
        retrieval_text = chunk.get("retrieval_text") or original_text
        if not str(retrieval_text).strip():
            continue
        documents.append(Document(
            page_content=str(retrieval_text),
            metadata={
                "chunk_id": chunk["chunk_id"],
                "parent_id": chunk.get("parent_id"),
                "document_id": chunk["document_id"],
                "source": chunk["source"],
                "page": chunk.get("page"),
                "chunk_type": chunk.get("chunk_type"),
                "original_text": original_text,
                "extra_metadata": chunk.get("metadata", {}),
            },
        ))
        retained_chunks.append(chunk)
    return documents, retained_chunks


def _save_vectors_jsonl(
    chunks: List[Dict[str, Any]],
    vectors: List[List[float]],
    output_path: str,
) -> None:
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as handle:
        for chunk, vector in zip(chunks, vectors):
            record = {
                "document_id": chunk.get("document_id"),
                "chunk_id": chunk.get("chunk_id"),
                "parent_id": chunk.get("parent_id"),
                "source": chunk.get("source"),
                "page": chunk.get("page"),
                "chunk_type": chunk.get("chunk_type"),
                "text": chunk.get("text", ""),
                "retrieval_text": chunk.get("retrieval_text", chunk.get("text", "")),
                "metadata": chunk.get("metadata", {}),
                "embedding_provider": "azure_openai",
                "embedding_deployment": AZURE_EMBEDDING_MODEL_NAME,
                "embedding_dimension": len(vector),
                "vector": vector,
            }
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def create_faiss_index(
    chunks: List[Dict[str, Any]],
    faiss_output_folder: Optional[str] = None,
    vectors_output_path: Optional[str] = None,
) -> FAISS:
    """Create an Azure OpenAI embedding FAISS index and optionally persist vectors/index."""
    if not chunks:
        raise ValueError("No chunks available to index.")

    documents, retained_chunks = _to_documents(chunks)
    if not documents:
        raise ValueError("All chunks were empty. Nothing to index.")

    embedding_model = get_embedding_model()
    texts = [doc.page_content for doc in documents]
    print(f"Generating Azure OpenAI embeddings for {len(texts)} chunks in API batches...")
    vectors = embedding_model.embed_documents(texts)

    text_embeddings = list(zip(texts, vectors))
    vector_store = FAISS.from_embeddings(
        text_embeddings=text_embeddings,
        embedding=embedding_model,
        metadatas=[doc.metadata for doc in documents],
    )

    if vectors_output_path:
        _save_vectors_jsonl(retained_chunks, vectors, vectors_output_path)
        print(f"Chunk vectors saved to: {vectors_output_path}")

    if faiss_output_folder:
        Path(faiss_output_folder).mkdir(parents=True, exist_ok=True)
        vector_store.save_local(faiss_output_folder)
        print(f"FAISS index saved to: {faiss_output_folder}")

    print(f"FAISS index created successfully with {len(documents)} chunks.")
    return vector_store
