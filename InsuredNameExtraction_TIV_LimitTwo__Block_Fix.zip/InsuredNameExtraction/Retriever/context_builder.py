from typing import Any, List


def build_context(chunks: List[Any]) -> str:
    """Build context with retrieval context plus original text for grounded evidence."""
    context_parts = []
    for chunk in chunks:
        metadata = chunk.metadata
        extra_metadata = metadata.get("extra_metadata") or {}
        original_text = metadata.get("original_text") or chunk.page_content
        context_parts.append(
            f"""
Chunk ID: {metadata.get('chunk_id')}
Parent ID: {metadata.get('parent_id')}
Chunk Type: {metadata.get('chunk_type')}
Document: {metadata.get('document_id')}
Page: {metadata.get('page')}
Extra Metadata: {extra_metadata}

Retrieval Context (may include heading, previous summary, and small overlap):
{chunk.page_content}

Original Evidence Text (quote evidence only from this block):
{original_text}

------------------------------
""".strip()
        )
    return "\n\n".join(context_parts).strip()
