# Grounded Insured Name and Limit One Fix

## Changes

1. **Keyword retrieval relevance gate**
   - Chunk-type priority is now added only after a real field-specific keyword/pattern match.
   - Unrelated key-value, section, and table chunks no longer rank simply because of their structure.
   - Limit One retrieval rejects per-occurrence, deductible, sublimit, aggregate, premium, limit-of-liability, and Named Windstorm chunks unless they also contain a direct TIV label.

2. **Insured Name cleanup and fallback**
   - Long extension clauses are trimmed after phrases such as `and all affiliated`, `subsidiary`, `associated`, `allied`, and `hereafter acquired`.
   - A deterministic fallback recovers direct labels such as `Insured Name: Sutter Health` when the LLM returns null.

3. **Limit One validation**
   - LLM output is no longer accepted merely because it is numeric.
   - A value is accepted only when evidence contains a direct TIV/Total Insured Value label, or both Building and Contents values can be parsed and added in Python.
   - Unsupported evidence such as `USD 80,000,000 Per Occurrence for Named Windstorm` returns null.
   - Minimum accepted LLM confidence is 0.80, followed by deterministic evidence validation.

4. **Deterministic recovery**
   - If the LLM selects the wrong chunk, the code scans the retrieved chunks for strong direct TIV evidence.
   - Building + Contents arithmetic is performed in Python, never trusted as an unverified LLM calculation.
