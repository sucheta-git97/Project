# Insurance Slip Field Extraction

This project processes multiple insurance documents with Azure Document Intelligence, creates hierarchical chunks, embeds those chunks with an Azure OpenAI `text-embedding-3-large` deployment, builds a separate FAISS index per document, and produces structured JSON extraction outputs.

## Extracted fields

- Insured Name
- Inception Date
- Expiration Date
- Currency
- Perils
- LayerPerils

`Perils` and `LayerPerils` use this deterministic base mapping:

```text
PES+PFF+PSL+PTS+PLS+PLQ+PWW+PPH+PSH+PWH+PWT+PFL+PNC+PWB
```

`+PTR` is appended to both values only when `terrorism`, `terror`, `terrorist`, or `TRIA` is detected inside the deductible section.

## Chunking strategy

The Azure mode now uses a smaller hierarchical strategy:

1. One parent chunk per page.
2. Section detection from Azure paragraph roles (`title`, `sectionHeading`) plus numbered/insurance heading rules.
3. Small sections are kept intact.
4. Large sections are split only when they exceed `SECTION_MAX_CHARS`.
5. Each split receives:
   - section heading,
   - deterministic previous-context summary,
   - a small exact overlap,
   - current original text.
6. Table and table-row chunks are created only when the table or surrounding section is relevant to limits, sublimits, deductibles, perils, area, territory, occupancy, currency, aggregate, or occurrence.
7. Azure key-value pairs are retained as high-priority metadata-rich chunks.
8. Exact duplicate chunks are removed before embedding.

The generated summary is used only for retrieval context. Evidence shown in final output must come from the original chunk text.

## Azure OpenAI embeddings

Create an Azure OpenAI deployment for `text-embedding-3-large`. Put the deployment details in `.env`:

```env
AZURE_EMBEDDING_MODEL_ENDPOINT=https://your-openai-resource.openai.azure.com/
AZURE_EMBEDDING_MODEL_KEY=your-key
AZURE_EMBEDDING_MODEL_NAME=your-text-embedding-3-large-deployment-name
AZURE_EMBEDDING_MODEL_VERSION=2024-02-01
AZURE_EMBEDDING_DIMENSIONS=
EMBEDDING_BATCH_SIZE=32
```

`AZURE_EMBEDDING_MODEL_NAME` must be the Azure deployment name, not necessarily the underlying model name.

## Chunking controls

```env
SECTION_MAX_CHARS=6000
SECTION_OVERLAP_CHARS=450
PREVIOUS_SUMMARY_MAX_CHARS=500
```

These values are character based. A section under `SECTION_MAX_CHARS` remains a single chunk.

## Outputs

```text
azure_layout_json/                  Azure Document Intelligence JSON
chunks_output.json                  All generated chunks
extraction_outputs/                 One extraction JSON per input document
extraction_output.json              Combined extraction output
vector_outputs/*_chunk_vectors.jsonl  One vector record per chunk
faiss_indexes/<document>/            Persisted FAISS index per document
```

Each JSONL vector record includes chunk text, retrieval text, metadata, embedding deployment, vector dimension, and the full vector. It can later be loaded into PostgreSQL/pgvector, Azure AI Search, or another vector database.

## Run

1. Copy `.env.example` to `.env` and fill in credentials/deployment names.
2. Put supported files into `Documents/`.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run:

```bash
python main.py
```

Each document is processed independently, preventing evidence from different slips from being mixed.


## Updated output rules

- `Expiration Date` is currently calculated as the extracted `Inception Date` plus **364 days**.
  The former LLM extraction block is retained as commented code in `main.py` under
  `PREVIOUS EXPIRATION DATE LLM EXTRACTION (DISABLED FOR FUTURE REUSE)`.
- `Sub Limit Limit Type` is returned as the static value `B`.
- `Limit One` is extracted as TIV. Direct TIV is preferred; otherwise the LLM calculates
  `Building + Contents`. The returned value is normalized to a numeric string without
  currency symbols or thousands separators.
