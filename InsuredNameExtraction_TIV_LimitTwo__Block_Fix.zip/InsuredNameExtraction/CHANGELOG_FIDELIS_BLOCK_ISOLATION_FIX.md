# Fidelis block isolation fix

- Fixed signed-line extraction on pages containing multiple underwriters.
- A percentage is now eligible only when it falls inside the vertical Fidelis underwriting block beginning at the Fidelis heading/stamp.
- Percentages from an earlier block, such as Inigo `10% Signed`, are excluded even when present on the same page.
- Within the Fidelis block, `Signed` is preferred and `Written`, `Order`, `Minimum signing`, and Subjectivities values are rejected.
- When multiple Fidelis-block percentages exist but none is clearly labelled Signed, Limit Two is returned as null rather than guessing.
