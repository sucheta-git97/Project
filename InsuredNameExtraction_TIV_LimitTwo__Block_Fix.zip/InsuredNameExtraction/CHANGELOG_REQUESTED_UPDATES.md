# Requested updates

## 1. Expiration Date

- The active LLM extraction call for Expiration Date has been disabled.
- The previous retrieval + LLM block remains commented in `main.py` under:
  `PREVIOUS EXPIRATION DATE LLM EXTRACTION (DISABLED FOR FUTURE REUSE)`.
- The active result is calculated as `Inception Date + 364 days`.
- When inception is unavailable or invalid, expiration is returned as `null`.

## 2. Sub Limit Limit Type

- Added as a static field with value `B`.
- It is not sent through retrieval or the LLM.

## 3. Limit One

- Added as an LLM extraction/calculation field.
- Direct TIV / Total Insurable Value is preferred.
- When direct TIV is unavailable, the prompt instructs the model to calculate `Building + Contents`.
- Retrieval includes TIV, Total Values, Building, Contents, Summary of Values, and Statement of Values terms.
- The final value is normalized to a numeric string without currency symbols or commas.
