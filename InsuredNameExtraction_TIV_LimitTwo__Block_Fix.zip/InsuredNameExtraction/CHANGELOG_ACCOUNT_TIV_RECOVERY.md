# Account label and full-document TIV recovery update

## Insured Name
- Added `Account:` and `Account Name:` as valid insured-name labels.
- Added retrieval boosting for an explicit `Account:` label.
- Deterministic insured-name recovery now scans all chunks in the current document, not only the top-K LLM context.
- Example: `Account: Frisco ISD` returns `Frisco ISD`.

## Limit One
- The LLM still receives K=10 retrieved chunks; this flow was not changed.
- Final deterministic TIV validation now scans all indexed chunks for the current document.
- Added same-page aggregation so Azure can split `Total Insured Values` and `USD 3,356,843,132` into separate chunks and the value can still be recovered.
- Only direct TIV labels or verified Building + Contents are accepted.
- Per-occurrence limits, deductibles, sublimits, premiums, annual aggregates, and named-windstorm amounts remain rejected.
