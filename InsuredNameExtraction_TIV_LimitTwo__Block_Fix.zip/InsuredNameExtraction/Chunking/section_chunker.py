import re
import uuid
from typing import Any, Dict, List, Optional, Tuple

from langchain_text_splitters import RecursiveCharacterTextSplitter

from Chunking.context_summary import build_extraction_summary

SECTION_KEYWORDS = {
    "named insured", "first named insured", "mailing address", "policy period",
    "policy term", "effective date", "inception date", "expiration date",
    "limits", "limit of liability", "sublimits", "sub-limits", "deductibles",
    "perils", "coverage", "territory", "occupancy", "conditions", "exclusions",
    "endorsements", "program specifications", "schedule", "layer",
}


def clean_text(text: Optional[str]) -> str:
    if not text:
        return ""
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _page_from_regions(item: Dict[str, Any]) -> Optional[int]:
    regions = item.get("boundingRegions", []) or []
    if regions:
        return regions[0].get("pageNumber")
    return None


def _looks_like_heading(text: str, role: str = "") -> bool:
    normalized = clean_text(text)
    lowered = normalized.lower().rstrip(":")
    if role.lower() in {"title", "sectionheading"}:
        return True
    if re.match(r"^\d+(?:\.\d+)*\.?\s+[A-Za-z]", normalized) and len(normalized) <= 140:
        return True
    if normalized.endswith(":") and len(normalized) <= 100:
        return True
    if lowered in SECTION_KEYWORDS:
        return True
    if any(lowered.startswith(keyword) for keyword in SECTION_KEYWORDS) and len(normalized) <= 120:
        return True
    words = normalized.split()
    if 1 <= len(words) <= 10 and len(normalized) <= 100 and normalized.isupper():
        return True
    return False


def detect_sections(doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Use Azure paragraph roles plus insurance heading heuristics to build ordered sections."""
    result = doc["azure_result"]
    document_id = doc["document_id"]
    source = doc["source"]
    paragraphs = result.get("paragraphs", []) or []

    sections: List[Dict[str, Any]] = []
    current_heading = "Document Introduction"
    current_items: List[str] = []
    current_pages: List[int] = []
    current_regions: List[Dict[str, Any]] = []

    def flush() -> None:
        nonlocal current_items, current_pages, current_regions
        text = clean_text("\n".join(current_items))
        if not text:
            current_items, current_pages, current_regions = [], [], []
            return
        sections.append({
            "section_id": f"{document_id}::section::{len(sections) + 1}",
            "heading": current_heading,
            "text": text,
            "page_start": min(current_pages) if current_pages else None,
            "page_end": max(current_pages) if current_pages else None,
            "bounding_regions": current_regions,
            "document_id": document_id,
            "source": source,
        })
        current_items, current_pages, current_regions = [], [], []

    for paragraph in paragraphs:
        text = clean_text(paragraph.get("content", ""))
        if not text:
            continue
        role = str(paragraph.get("role", ""))
        page = _page_from_regions(paragraph)
        if _looks_like_heading(text, role):
            flush()
            current_heading = text.rstrip(":")
            current_items = [text]
        else:
            current_items.append(text)
        if page:
            current_pages.append(page)
        current_regions.extend(paragraph.get("boundingRegions", []) or [])

    flush()
    return sections


def split_section(
    section: Dict[str, Any],
    max_chars: int = 6000,
    overlap_chars: int = 450,
    summary_chars: int = 500,
) -> List[Dict[str, Any]]:
    text = section["text"]
    if len(text) <= max_chars:
        return [{
            **section,
            "chunk_id": section["section_id"],
            "chunk_type": "section",
            "parent_id": None,
            "previous_context_summary": "",
            "overlap_text": "",
            "retrieval_text": f"Section: {section['heading']}\n{text}",
        }]

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=max_chars,
        chunk_overlap=overlap_chars,
        separators=["\n\n", "\n", ". ", "; ", " ", ""],
    )
    parts = splitter.split_text(text)
    chunks: List[Dict[str, Any]] = []
    previous_original = ""

    for index, part in enumerate(parts, start=1):
        previous_summary = build_extraction_summary(previous_original, max_chars=summary_chars) if previous_original else ""
        overlap_text = previous_original[-overlap_chars:] if previous_original else ""
        retrieval_parts = [f"Section: {section['heading']}"]
        if previous_summary:
            retrieval_parts.append(f"Previous context summary: {previous_summary}")
        if overlap_text:
            retrieval_parts.append(f"Previous exact overlap: {overlap_text}")
        retrieval_parts.append(f"Current text: {part}")

        chunks.append({
            **section,
            "chunk_id": str(uuid.uuid4()),
            "chunk_type": "section_split",
            "parent_id": section["section_id"],
            "text": clean_text(part),
            "previous_context_summary": previous_summary,
            "overlap_text": clean_text(overlap_text),
            "retrieval_text": "\n".join(retrieval_parts),
            "split_index": index,
            "split_count": len(parts),
        })
        previous_original = part

    return chunks
