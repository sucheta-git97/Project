import re
from typing import Iterable, List

PERIL_TERMS = [
    "flood", "earthquake", "earth movement", "windstorm", "named storm",
    "hail", "terrorism", "terror", "aop", "all other perils", "fire",
]
AREA_TERMS = ["territory", "area", "zone", "county", "state", "tier", "coastal", "inland"]
OCCUPANCY_TERMS = ["occupancy", "residential", "commercial", "industrial", "education", "school", "hospital"]
CURRENCY_PATTERN = re.compile(r"\b(?:USD|GBP|EUR|CAD|AUD|INR)\b|[$£€₹]", re.IGNORECASE)
AMOUNT_PATTERN = re.compile(r"(?:\b(?:USD|GBP|EUR|CAD|AUD|INR)\s*)?[$£€₹]?\s*\d[\d,]*(?:\.\d+)?\s*(?:K|M|MM|B|BN|million|billion)?", re.IGNORECASE)


def _find_terms(text: str, terms: Iterable[str], limit: int = 6) -> List[str]:
    lowered = text.lower()
    found: List[str] = []
    for term in terms:
        if term in lowered and term not in found:
            found.append(term)
        if len(found) >= limit:
            break
    return found


def build_extraction_summary(text: str, max_chars: int = 500) -> str:
    """Create a deterministic extraction-oriented summary; no LLM call is required."""
    if not text or not text.strip():
        return ""

    pieces: List[str] = []
    perils = _find_terms(text, PERIL_TERMS)
    areas = _find_terms(text, AREA_TERMS)
    occupancies = _find_terms(text, OCCUPANCY_TERMS)
    currencies = list(dict.fromkeys(m.group(0).upper() for m in CURRENCY_PATTERN.finditer(text)))[:3]
    amounts = [re.sub(r"\s+", " ", m.group(0)).strip() for m in AMOUNT_PATTERN.finditer(text)]
    amounts = [a for a in dict.fromkeys(amounts) if any(ch.isdigit() for ch in a)][:6]

    if perils:
        pieces.append("Perils/coverage terms: " + ", ".join(perils))
    if areas:
        pieces.append("Area/territory terms: " + ", ".join(areas))
    if occupancies:
        pieces.append("Occupancy terms: " + ", ".join(occupancies))
    if currencies:
        pieces.append("Currencies/symbols: " + ", ".join(currencies))
    if amounts:
        pieces.append("Amounts: " + ", ".join(amounts))

    if not pieces:
        sentence = re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", text.strip()))[0]
        pieces.append("Previous context: " + sentence[:300])

    summary = ". ".join(pieces)
    return summary[:max_chars].rstrip(" .") + "."
