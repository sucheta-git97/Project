import re
from typing import Any, Dict, List, Optional

RELEVANT_TABLE_KEYWORDS = {
    "sublimit", "sub-limit", "sub limit", "limit", "deductible", "peril",
    "coverage", "territory", "area", "occupancy", "amount", "currency",
    "usd", "gbp", "eur", "cad", "aud", "inr", "aggregate", "occurrence",
}


def clean_text(text: Optional[str]) -> str:
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def table_is_relevant(table_text: str, section_heading: str = "") -> bool:
    candidate = f"{section_heading} {table_text}".lower()
    return any(keyword in candidate for keyword in RELEVANT_TABLE_KEYWORDS)


def build_header_aware_rows(cells: List[Dict[str, Any]]) -> List[str]:
    rows: Dict[int, Dict[int, str]] = {}
    header_by_column: Dict[int, str] = {}

    for cell in cells:
        row_index = int(cell.get("rowIndex", 0))
        col_index = int(cell.get("columnIndex", 0))
        content = clean_text(cell.get("content", ""))
        rows.setdefault(row_index, {})[col_index] = content
        kind = str(cell.get("kind", "")).lower()
        if row_index == 0 or "columnheader" in kind:
            if content:
                header_by_column[col_index] = content

    output: List[str] = []
    for row_index in sorted(rows):
        if row_index == 0 and header_by_column:
            continue
        row = rows[row_index]
        values: List[str] = []
        for col_index in sorted(row):
            value = row[col_index]
            if not value:
                continue
            header = header_by_column.get(col_index)
            values.append(f"{header}: {value}" if header and header != value else value)
        if values:
            output.append(" | ".join(values))
    return output
