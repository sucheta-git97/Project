import re
from typing import Any, Dict, Iterable, List

BASE_PERILS = "PES+PFF+PSL+PTS+PLS+PLQ+PWW+PPH+PSH+PWH+PWT+PFL+PNC+PWB"
TERRORISM_PATTERN = re.compile(r"\b(?:terrorism|terrorist|terror|TRIA)\b", re.IGNORECASE)
NEXT_SECTION_PATTERN = re.compile(
    r"\n\s*(?:limits?|sublimits?|perils?|coverage|territory|occupanc(?:y|ies)|conditions?|exclusions?|endorsements?)\s*:",
    re.IGNORECASE,
)


def _deductible_candidate_texts(chunks: Iterable[Dict[str, Any]]) -> List[str]:
    candidates: List[str] = []
    for chunk in chunks:
        text = str(chunk.get("text", ""))
        metadata = chunk.get("metadata", {}) or {}
        heading = str(metadata.get("section_heading", chunk.get("heading", "")))

        if "deductib" in heading.lower():
            candidates.append(f"{heading}\n{text}")
            continue

        label = re.search(r"\bdeductibles?\s*:\s*", text, re.IGNORECASE)
        if label:
            block = text[label.start():]
            next_heading = NEXT_SECTION_PATTERN.search(block, pos=max(1, label.end() - label.start()))
            if next_heading:
                block = block[:next_heading.start()]
            candidates.append(block[:4000])
    return candidates


def derive_perils_fields(chunks: List[Dict[str, Any]], document_id: str) -> Dict[str, Dict[str, Any]]:
    deductible_texts = _deductible_candidate_texts(chunks)
    matched_text = next((text for text in deductible_texts if TERRORISM_PATTERN.search(text)), None)
    has_terrorism = matched_text is not None
    value = BASE_PERILS + ("+PTR" if has_terrorism else "")

    evidence = (
        "PTR appended because terrorism-related wording was detected in the deductible section."
        if has_terrorism
        else "Static peril mapping applied; no terrorism-related wording was detected in the deductible section."
    )
    common = {
        "Value": value,
        "Chunk_id": None,
        "Chunk_type": "deterministic_rule",
        "Evidence": evidence,
        "Confidence": 1.0,
        "Document_id": document_id,
    }
    return {"Perils": dict(common), "LayerPerils": dict(common)}
