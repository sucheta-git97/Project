# Limit One year selection and Limit Two (Fidelis signed line)

## Changes

- Limit One now uses the year from the extracted Inception Date when a TIV table contains multiple year columns.
- YOY percentage and YOY monetary-change columns are excluded from TIV selection.
- If no year-wise split exists, the directly stated TIV continues to be used.
- Added `Limit Two` to the output schema.
- Azure page chunks now retain OCR line polygons so the signature block can be evaluated spatially.
- The Fidelis stamp/signature block is mandatory for signed-line extraction.
- Only percentages spatially associated with the Fidelis block are considered.
- If multiple percentages are present, a value labelled `Signed` or `Signed Line` is selected over `Written`, `Order`, or minimum-signing values.
- Limit Two is calculated in Python using Decimal arithmetic: `Limit One × signed line % / 100`.
- If the Fidelis block or associated percentage is missing, Limit Two is returned as null rather than using an unrelated percentage.
