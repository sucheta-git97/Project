import os
from typing import Any, Dict, List

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings


load_dotenv()

HF_TOKEN = os.getenv("HUGGING_FACE_TOKEN")


def create_faiss_index(chunks: List[Dict[str, Any]]) -> FAISS:
    """Create one FAISS vector index for all document chunks."""

    if not chunks:
        raise ValueError("No chunks available to index.")

    embedding_model = HuggingFaceEmbeddings(
        model_name="BAAI/bge-base-en",
        model_kwargs={
            "device": "cpu",
            "token": HF_TOKEN
        },
        encode_kwargs={
            "normalize_embeddings": True
        }
    )

    documents = []

    for chunk in chunks:
        documents.append(
            Document(
                page_content=chunk["text"],
                metadata={
                    "chunk_id": chunk["chunk_id"],
                    "document_id": chunk["document_id"],
                    "source": chunk["source"],
                    "page": chunk["page"]
                }
            )
        )

    vector_store = FAISS.from_documents(documents, embedding_model)

    print("FAISS index created successfully.")
    return vector_store
