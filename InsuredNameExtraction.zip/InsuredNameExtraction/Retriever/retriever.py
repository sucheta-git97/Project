from typing import Any, Dict, List


def build_query(field: Dict[str, Any]) -> str:
    """Build a retrieval query focused on insured-name style language."""
    field_name = field.get("field_name", "")
    description = field.get("description", "")
    possible_names = field.get("possible_names", [])

    query_parts = [
        field_name,
        description,
        "named insured",
        "first named insured",
        "primary named insured",
        "insured entity",
        "insured name",
        "applicant name",
        "account name",
        "organization name",
        "client name",
        "legal entity",
        "will be",
        "named insured will be",
        "first named insured will be",
        "org chart for"
    ]

    if isinstance(possible_names, list):
        query_parts.extend(possible_names)

    return " ".join(query_parts)


def retrieve_relevant_chunks(vector_store, field: Dict[str, Any], k: int = 6) -> List[Any]:
    """Retrieve relevant chunks from the FAISS index."""
    query = build_query(field)

    print(f"Retrieving chunks for field: {field.get('field_name')}")
    results = vector_store.similarity_search(query, k=k)

    unique_results = []
    seen_ids = set()

    for doc in results:
        chunk_id = doc.metadata.get("chunk_id")

        if chunk_id in seen_ids:
            continue

        seen_ids.add(chunk_id)
        unique_results.append(doc)

    print(f"Total retrieved chunks: {len(unique_results)}")
    return unique_results
