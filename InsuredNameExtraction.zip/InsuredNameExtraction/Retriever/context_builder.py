from typing import Any, List


def build_context(chunks: List[Any]) -> str:
    """Build an LLM-ready context string from retrieved chunks."""
    context = ""

    for chunk in chunks:
        metadata = chunk.metadata

        context += f"""
Chunk ID: {metadata.get("chunk_id")}
Document: {metadata.get("document_id")}
Page: {metadata.get("page")}

Body:
{chunk.page_content}

------------------------------
"""

    return context.strip()
