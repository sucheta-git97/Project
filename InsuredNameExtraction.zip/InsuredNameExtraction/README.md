# Insured Name Extraction

This project extracts the **Insured Name** from insurance slip / policy documents using:

1. PDF/DOCX text loading
2. Text chunking
3. Hugging Face embeddings
4. FAISS retrieval
5. Azure OpenAI extraction
6. JSON output with evidence

## Folder Structure

```text
InsuredNameExtraction/
├── Documents/
├── Fields/
│   ├── fields.json
│   └── fields_loader.py
├── Chunking/
│   ├── document_loader.py
│   └── chunker.py
├── Retriever/
│   ├── indexer.py
│   ├── retriever.py
│   ├── context_builder.py
│   └── llm.py
├── Prompt/
│   └── prompt.py
├── .env.example
├── main.py
└── requirements.txt
```

## Setup

Create and activate a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and fill your keys:

```bash
copy .env.example .env
```

Put your PDFs/DOCX files inside:

```text
Documents/
```

Run:

```bash
python main.py
```

The output will be saved to:

```text
extraction_output.json
```

## Expected Sample Output

```json
{
  "Insured Name": {
    "Value": "Vanguard Foods LP",
    "Chunk_id": "generated-chunk-id",
    "Evidence": "first Named Insured will be Vanguard Foods LP"
  }
}
```
