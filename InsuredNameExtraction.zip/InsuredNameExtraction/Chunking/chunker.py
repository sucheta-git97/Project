import uuid
from typing import Any, Dict, List

from langchain_text_splitters import RecursiveCharacterTextSplitter


def chunk_documents(
    pages: List[Dict[str, Any]],
    chunk_size: int = 1000,
    chunk_overlap: int = 150
) -> List[Dict[str, Any]]:
    """Create overlapping text chunks from loaded document pages."""

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", " ", ""]
    )

    chunks = []

    for page in pages:
        page_text = page.get("text", "")

        if not page_text.strip():
            continue

        splits = splitter.split_text(page_text)

        for split in splits:
            chunks.append({
                "chunk_id": str(uuid.uuid4()),
                "document_id": page["document_id"],
                "source": page["source"],
                "page": page["page"],
                "text": split
            })

    print(f"Total chunks created: {len(chunks)}")
    return chunks
