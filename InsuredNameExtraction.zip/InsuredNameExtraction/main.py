import json
import re
import unicodedata

from Chunking.chunker import chunk_documents
from Chunking.document_loader import process_all_documents
from Fields.fields_loader import load_fields_from_json
from Retriever.context_builder import build_context
from Retriever.indexer import create_faiss_index
from Retriever.llm import run_llm
from Retriever.retriever import retrieve_relevant_chunks


FILE_PATH = "./Documents"
FIELDS_JSON_PATH = "./Fields/fields.json"
OUTPUT_JSON_PATH = "./extraction_output.json"


def normalize_text(value):
    """Normalize whitespace and unicode for clean output."""
    if not isinstance(value, str):
        return value

    value = unicodedata.normalize("NFKC", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def runner():
    final_output = {}

    print("Loading documents...")
    pages = process_all_documents(FILE_PATH)
    print(f"Total pages loaded: {len(pages)}")

    if not pages:
        raise ValueError("No document text was loaded. Add PDF/DOCX files inside the Documents folder.")

    print("Creating chunks...")
    chunks = chunk_documents(pages)
    print(f"Total chunks generated: {len(chunks)}")

    print("Creating FAISS index...")
    vector_store = create_faiss_index(chunks)

    print("Loading fields...")
    fields = load_fields_from_json(FIELDS_JSON_PATH)

    if not fields:
        raise ValueError("No fields found in Fields/fields.json")

    print(f"Fields to extract: {[field['field_name'] for field in fields]}")

    for field in fields:
        field_name = field["field_name"]

        print(f"\nExtracting field: {field_name}")

        retrieved_chunks = retrieve_relevant_chunks(
            vector_store=vector_store,
            field=field,
            k=6
        )

        context = build_context(retrieved_chunks)

        llm_result = run_llm(field, context)

        if isinstance(llm_result.get("Value"), str):
            llm_result["Value"] = normalize_text(llm_result["Value"])

        final_output[field_name] = llm_result

        print(f"Extracted value for {field_name}:")
        print(json.dumps(llm_result, indent=2, ensure_ascii=False))

    with open(OUTPUT_JSON_PATH, "w", encoding="utf-8") as file:
        json.dump(final_output, file, indent=2, ensure_ascii=False)

    print("\nFinal output:")
    print(json.dumps(final_output, indent=2, ensure_ascii=False))
    print(f"\nOutput saved to: {OUTPUT_JSON_PATH}")

    return final_output


if __name__ == "__main__":
    try:
        runner()
    except Exception as e:
        print(f"An error occurred: {e}")
